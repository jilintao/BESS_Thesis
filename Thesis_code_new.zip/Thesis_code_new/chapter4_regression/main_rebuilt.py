"""
Chapter 4.3 rebuilt: Ridge / Lasso / ElasticNet + Random Forest / Gradient Boosting.

Proxy / associational analysis — not causal inference. Spread excluded from estimation;
spread retained only for VIF "before" diagnostics.
"""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

import config
from data_preparation import (
    compute_vif_dataframe,
    prepare_zone_dataframe,
    train_test_split_arrays,
)
from model_comparison import compare_all_models, pick_best_model_name, resolve_estimator
from random_forest_model import TreeBasedModels
from results_tables import (
    save_final_results_csv,
    write_table_final_forest,
    write_table_final_regularized,
    write_table_model_comparison,
    write_table_vif,
)
from ridge_lasso_models import RegularizedRegressionModels
from visualization_new import (
    plot_model_comparison,
    plot_partial_dependence,
    plot_regularization_paths,
    plot_regularized_coefficients,
    plot_residual_analysis,
    plot_rf_importance,
    standardized_beta_table,
)


def _setup_log() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[logging.StreamHandler(sys.stdout)],
    )


def _cols_with_spread() -> list[str]:
    return config.FEATURE_COLS + [config.SPREAD_COL]


def _figure_bundle_path(zone: str) -> Path:
    return config.RESULTS_DIR / f"_figure_bundle_{zone}.joblib"


def _regenerate_figures_from_cache(zone: str) -> None:
    """Redraw Chapter 4.3 figures from a joblib bundle written by a full pipeline run."""
    path = _figure_bundle_path(zone)
    if not path.is_file():
        raise FileNotFoundError(
            f"Missing {path}. Run `python main_rebuilt.py` once for zone {zone} to build the cache, "
            "then use --figures-only."
        )
    b = joblib.load(path)
    reg = b["reg"]
    trees = b["trees"]
    X_tr_s, y_tr = b["X_train_s"], b["y_train"]
    X_tr_df = b["X_train_df"]
    comp = b["comp"]
    best = b["best"]
    y_te, y_pred = b["y_test"], b["y_pred"]
    test_dates = b["test_dates"]
    t_ord = pd.to_datetime(test_dates).map(pd.Timestamp.toordinal).to_numpy()

    plot_regularized_coefficients(
        reg.models,
        config.FEATURE_LABELS,
        config.FIG_DIR / f"fig4_14_regularized_coefficients_{zone}",
    )
    plot_regularization_paths(
        X_tr_s,
        y_tr,
        config.FEATURE_LABELS,
        config.FIG_DIR / f"fig4_15_regularization_paths_{zone}",
    )
    imp = trees.feature_importance_df(config.FEATURE_COLS)
    plot_rf_importance(imp, zone, config.FIG_DIR / f"fig4_16_rf_importance_{zone}")
    plot_partial_dependence(
        trees.models["RandomForest"],
        X_tr_df,
        config.FEATURE_COLS,
        config.FIG_DIR / f"fig4_17_partial_dependence_{zone}",
    )
    plot_model_comparison(comp, zone, config.FIG_DIR / f"fig4_18_model_comparison_{zone}")
    plot_residual_analysis(
        y_te,
        y_pred,
        best,
        zone,
        config.FIG_DIR / f"fig4_19_residual_analysis_{best}_{zone}",
        time_index=t_ord,
    )


def run_pipeline_for_zone(zone: str, skip_plots: bool = False) -> dict:
    log = logging.getLogger("main_rebuilt")
    df = prepare_zone_dataframe(zone)
    df.to_csv(config.RESULTS_DIR / f"daily_panel_{zone}.csv", index=False)

    vif_before = compute_vif_dataframe(df, _cols_with_spread())
    vif_after = compute_vif_dataframe(df, config.FEATURE_COLS)
    write_table_vif(
        vif_before,
        vif_after,
        zone,
        config.TABLES_DIR / f"table4_4_vif_{zone}.tex",
    )
    vif_before.to_csv(config.RESULTS_DIR / f"vif_before_{zone}.csv", index=False)
    vif_after.to_csv(config.RESULTS_DIR / f"vif_after_{zone}.csv", index=False)

    split = train_test_split_arrays(df, config.FEATURE_COLS, config.TARGET_COL)
    X_tr_s, X_te_s = split["X_train_s"], split["X_test_s"]
    X_tr_r, X_te_r = split["X_train_raw"], split["X_test_raw"]
    y_tr, y_te = split["y_train"], split["y_test"]
    test_dates = split["test_dates"]

    reg = RegularizedRegressionModels()
    reg.tune_ridge(X_tr_s, y_tr)
    reg.tune_lasso(X_tr_s, y_tr)
    reg.tune_elasticnet(X_tr_s, y_tr)
    reg_test = reg.evaluate_on_test(X_te_s, y_te)

    trees = TreeBasedModels()
    trees.tune_random_forest(X_tr_r, y_tr)
    trees.tune_gradient_boosting(X_tr_r, y_tr)

    comp = compare_all_models(reg_test, trees.models, X_te_r, y_te)
    comp.to_csv(config.RESULTS_DIR / f"model_comparison_{zone}.csv")
    write_table_model_comparison(comp, zone, config.TABLES_DIR / f"table4_5_model_comparison_{zone}.tex")

    X_tr_df = pd.DataFrame(X_tr_r, columns=config.FEATURE_COLS)

    if not skip_plots:
        plot_regularized_coefficients(
            reg.models,
            config.FEATURE_LABELS,
            config.FIG_DIR / f"fig4_14_regularized_coefficients_{zone}",
        )
        plot_regularization_paths(
            X_tr_s,
            y_tr,
            config.FEATURE_LABELS,
            config.FIG_DIR / f"fig4_15_regularization_paths_{zone}",
        )
        imp = trees.feature_importance_df(config.FEATURE_COLS)
        plot_rf_importance(imp, zone, config.FIG_DIR / f"fig4_16_rf_importance_{zone}")
        plot_partial_dependence(
            trees.models["RandomForest"],
            X_tr_df,
            config.FEATURE_COLS,
            config.FIG_DIR / f"fig4_17_partial_dependence_{zone}",
        )
        plot_model_comparison(comp, zone, config.FIG_DIR / f"fig4_18_model_comparison_{zone}")

    best = pick_best_model_name(comp)
    est, xkind = resolve_estimator(best, reg.models, trees.models)
    if xkind == "scaled":
        y_pred = est.predict(X_te_s)
    else:
        y_pred = est.predict(X_te_r)

    if not skip_plots:
        t_ord = pd.to_datetime(test_dates).map(pd.Timestamp.toordinal).to_numpy()
        plot_residual_analysis(
            y_te,
            y_pred,
            best,
            zone,
            config.FIG_DIR / f"fig4_19_residual_analysis_{best}_{zone}",
            time_index=t_ord,
        )
        joblib.dump(
            {
                "reg": reg,
                "trees": trees,
                "X_train_s": X_tr_s,
                "y_train": y_tr,
                "X_train_df": X_tr_df,
                "comp": comp,
                "best": best,
                "y_test": y_te,
                "y_pred": y_pred,
                "test_dates": test_dates,
            },
            _figure_bundle_path(zone),
        )

    if hasattr(est, "coef_"):
        write_table_final_regularized(
            config.FEATURE_LABELS,
            np.asarray(est.coef_).ravel(),
            float(est.intercept_),
            best,
            zone,
            config.TABLES_DIR / f"table4_6_final_{zone}.tex",
        )
        beta = standardized_beta_table(df, np.asarray(est.coef_).ravel(), config.FEATURE_COLS, config.TARGET_COL)
        beta.to_csv(config.RESULTS_DIR / f"standardized_betas_{zone}.csv", index=False)
    else:
        write_table_final_forest(
            trees.feature_importance_df(config.FEATURE_COLS),
            zone,
            config.TABLES_DIR / f"table4_6_final_{zone}.tex",
        )

    final_df = save_final_results_csv(est, config.FEATURE_COLS)
    final_df["model"] = best
    final_df["zone"] = zone
    final_df.to_csv(config.RESULTS_DIR / f"table4_6_final_results_{zone}.csv", index=False)

    return {
        "zone": zone,
        "n_days": len(df),
        "best_model": best,
        "comparison": comp,
        "vif_after_max": float(vif_after["vif"].max()),
    }


def write_summary(zones_out: list[dict], path: Path) -> None:
    lines = [
        "# Chapter 4.3 — Rebuilt analysis (Ridge/Lasso/EN + trees)",
        "",
        "**Disclaimer:** Associational proxy models for scenario screening — not causal inference.",
        "",
        "## Variable selection",
        "",
        "- **Estimation features:** Volatility, Spike frequency, Ramp rate (spread **excluded** — near-collinear with volatility).",
        "- **Table 4.4** files: `tables/table4_4_vif_SE3.tex`, `tables/table4_4_vif_SE4.tex` compare VIF with vs without `spread_diag`.",
        "",
        "## Outputs",
        "",
        "- Daily panels: `results/daily_panel_SE*.csv`",
        "- Model comparison: `results/model_comparison_SE*.csv` + `tables/table4_5_model_comparison_*.tex`",
        "- Final table: `tables/table4_6_final_*.tex` + `results/table4_6_final_results_*.csv`",
        "- Figures: `figures/fig4_14` … `fig4_19` (suffix `_SE3` / `_SE4`)",
        "",
        "## Best models (test R²)",
        "",
    ]
    for z in zones_out:
        bm = z["best_model"]
        r2 = float(z["comparison"].loc[bm, "R2_Test"])
        lines.append(f"- **{z['zone']}:** {bm}, test $R^2$={r2:.4f}, days={z['n_days']}, max VIF (no spread)={z['vif_after_max']:.2f}")
    lines.extend(
        [
            "",
            "## Multicollinearity (after dropping spread)",
            "",
            "- Max VIF on `volatility`, `spike_freq`, `ramp_rate` can still exceed 5 (see `results/vif_after_*.csv`). Ridge/Lasso shrink coefficients; interpret linear signs cautiously. Random Forest CV R² can exceed test R² — avoid over-claiming out-of-sample performance.",
            "",
            "## Interpretation notes",
            "",
            "- Random train/test split (20%) as specified; for a thesis robustness section, consider time-based split or expanding window CV.",
            "- Tree models use **raw** features; regularized linear models use **standardized** features.",
            "- If test $R^2$ is modest, report honestly: the linear proxy may be weak, which is a substantive finding.",
            "",
        ]
    )
    path.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Chapter 4.3 rebuilt statistical pipeline")
    parser.add_argument("--zone", choices=["SE3", "SE4", "both"], default="both")
    parser.add_argument("--skip-plots", action="store_true", help="Skip figure generation (faster)")
    parser.add_argument(
        "--figures-only",
        action="store_true",
        help="Redraw figures from results/_figure_bundle_<zone>.joblib (no re-estimation). "
        "Run a full pipeline without --skip-plots once per zone to create the cache.",
    )
    args = parser.parse_args()
    _setup_log()
    log = logging.getLogger("main_rebuilt")
    if args.figures_only and args.skip_plots:
        log.error("--figures-only cannot be combined with --skip-plots.")
        sys.exit(1)

    if args.figures_only:
        log.info("Figures-only: regenerating plots from joblib cache")
        zones = ["SE3", "SE4"] if args.zone == "both" else [args.zone]
        for z in zones:
            log.info("=== Zone %s ===", z)
            _regenerate_figures_from_cache(z)
        log.info("Done. Figures updated in %s", config.FIG_DIR)
        return

    log.info("Starting rebuilt Chapter 4.3 pipeline")

    zones = ["SE3", "SE4"] if args.zone == "both" else [args.zone]
    outs = []
    for z in zones:
        log.info("=== Zone %s ===", z)
        outs.append(run_pipeline_for_zone(z, skip_plots=args.skip_plots))

    write_summary(outs, config.ROOT / "CHAPTER4_3_RESULTS_SUMMARY.md")
    log.info("Done. See CHAPTER4_3_RESULTS_SUMMARY.md")


if __name__ == "__main__":
    main()
