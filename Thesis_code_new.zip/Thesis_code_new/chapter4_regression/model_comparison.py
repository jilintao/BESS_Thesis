"""Aggregate test metrics for regularized (scaled X) and tree (raw X) models."""
from __future__ import annotations

import logging
from typing import Any

import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

import config

log = logging.getLogger(__name__)


def compare_all_models(
    reg_results: dict[str, dict],
    tree_models: dict[str, Any],
    X_test_raw: np.ndarray,
    y_test: np.ndarray,
) -> pd.DataFrame:
    """
    reg_results: test metrics from RegularizedRegressionModels.evaluate_on_test.
    tree_models: fitted estimators evaluated on raw (unscaled) features.
    """
    rows = []
    for name, m in reg_results.items():
        rows.append(
            {
                "model": name,
                "type": "Regularized",
                "R2_Test": m["R2"],
                "MAE_Test": m["MAE"],
                "RMSE_Test": m["RMSE"],
            }
        )
    for name, model in tree_models.items():
        pred = model.predict(X_test_raw)
        rows.append(
            {
                "model": name,
                "type": "Tree-based",
                "R2_Test": float(r2_score(y_test, pred)),
                "MAE_Test": float(mean_absolute_error(y_test, pred)),
                "RMSE_Test": float(np.sqrt(mean_squared_error(y_test, pred))),
            }
        )
    df = pd.DataFrame(rows).set_index("model")
    df = df.sort_values("R2_Test", ascending=False)
    log.info("Model comparison (test):\n%s", df.to_string())
    return df


def pick_best_model_name(comparison: pd.DataFrame) -> str:
    return str(comparison["R2_Test"].idxmax())


def resolve_estimator(
    best_name: str,
    reg_models: dict[str, Any],
    tree_models: dict[str, Any],
):
    if best_name in reg_models:
        return reg_models[best_name], "scaled"
    if best_name in tree_models:
        return tree_models[best_name], "raw"
    raise KeyError(best_name)
