"""LaTeX tables: VIF (4.4), model comparison (4.5), final coefficients / importance (4.6)."""
from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


def _esc(s: str) -> str:
    return str(s).replace("_", r"\_")


def write_table_vif(
    vif_before: pd.DataFrame,
    vif_after: pd.DataFrame,
    zone: str,
    path: Path,
) -> None:
    """Table 4.4 style: VIF before (with spread) vs after (estimation set)."""
    lines = [
        r"\caption{VIF diagnostics: before (with spread) and after removing spread (" + zone + r").}",
        r"\begin{tabular}{lrr}",
        r"\toprule",
        r"Feature & VIF (with spread) & VIF (no spread) \\",
        r"\midrule",
    ]
    # align by feature name from union
    feats = sorted(set(vif_before["feature"]) | set(vif_after["feature"]))
    bmap = dict(zip(vif_before["feature"], vif_before["vif"]))
    amap = dict(zip(vif_after["feature"], vif_after["vif"]))
    for f in feats:
        vb = bmap.get(f, float("nan"))
        va = amap.get(f, float("nan"))
        lines.append(
            f"{_esc(f)} & {vb:.2f} & {va:.2f} \\\\"
        )
    lines.extend(
        [
            r"\bottomrule",
            r"\end{tabular}",
        ]
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def write_table_model_comparison(df: pd.DataFrame, zone: str, path: Path) -> None:
    """Table 4.5: test metrics."""
    d = df.reset_index()
    lines = [
        r"\caption{Model comparison: balancing revenue proxy (" + zone + r", test set).}",
        r"\begin{tabular}{lcccc}",
        r"\toprule",
        r"Model & Type & $R^2$ & MAE & RMSE \\",
        r"\midrule",
    ]
    for _, row in d.iterrows():
        lines.append(
            f"{_esc(row['model'])} & {_esc(row['type'])} & {row['R2_Test']:.4f} & "
            f"{row['MAE_Test']:.2f} & {row['RMSE_Test']:.2f} \\\\"
        )
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def write_table_final_regularized(
    feature_labels: list[str],
    coef: np.ndarray,
    intercept: float,
    model_name: str,
    zone: str,
    path: Path,
) -> None:
    """Table 4.6 for linear model: coefficients on standardized X."""
    lines = [
        rf"\caption{{Selected model ({_esc(model_name)}, {zone}): standardized-feature coefficients.}}",
        r"\begin{tabular}{lr}",
        r"\toprule",
        r"Feature & Coefficient \\",
        r"\midrule",
    ]
    for lab, c in zip(feature_labels, np.asarray(coef).ravel()):
        lines.append(f"{_esc(lab)} & {c:.4f} \\\\")
    lines.append(r"\midrule")
    lines.append(f"Intercept & {intercept:.4f} \\\\")
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    path.write_text("\n".join(lines), encoding="utf-8")


def write_table_final_forest(
    importance_df: pd.DataFrame,
    zone: str,
    path: Path,
) -> None:
    """Table 4.6 for tree model."""
    lines = [
        r"\caption{Random Forest feature importance (" + zone + r").}",
        r"\begin{tabular}{lr}",
        r"\toprule",
        r"Feature & Importance \\",
        r"\midrule",
    ]
    for _, row in importance_df.sort_values("importance", ascending=False).iterrows():
        lines.append(f"{_esc(row['feature'])} & {row['importance']:.4f} \\\\")
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    path.write_text("\n".join(lines), encoding="utf-8")


def save_final_results_csv(
    estimator: Any,
    feature_cols: list[str],
) -> pd.DataFrame:
    """Return a small summary DataFrame; caller writes CSV."""
    if hasattr(estimator, "coef_"):
        return pd.DataFrame(
            {
                "feature": feature_cols,
                "value": np.asarray(estimator.coef_).ravel(),
                "type": "coefficient",
            }
        )
    return pd.DataFrame(
        {
            "feature": feature_cols,
            "value": np.asarray(estimator.feature_importances_).ravel(),
            "type": "importance",
        }
    )
