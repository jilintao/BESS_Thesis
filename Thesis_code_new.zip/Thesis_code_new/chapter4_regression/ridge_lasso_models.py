"""Ridge, Lasso, ElasticNet with GridSearchCV (R², 5-fold CV)."""
from __future__ import annotations

import logging
from typing import Any

import numpy as np
from sklearn.linear_model import ElasticNet, Lasso, Ridge
from sklearn.model_selection import GridSearchCV

import config

log = logging.getLogger(__name__)

# sklearn Ridge has no random_state; Lasso/ElasticNet do.
_N_JOBS = 1  # avoid Windows multiprocessing issues


class RegularizedRegressionModels:
    def __init__(self, random_state: int = config.RANDOM_STATE):
        self.random_state = random_state
        self.models: dict[str, Any] = {}
        self.best_params: dict[str, dict] = {}
        self.cv_scores: dict[str, float] = {}

    def tune_ridge(self, X_train: np.ndarray, y_train: np.ndarray):
        param_grid = {"alpha": [0.001, 0.01, 0.1, 1.0, 10.0, 100.0, 1000.0]}
        ridge = Ridge()
        gs = GridSearchCV(
            ridge,
            param_grid,
            cv=5,
            scoring="r2",
            n_jobs=_N_JOBS,
        )
        gs.fit(X_train, y_train)
        self.models["Ridge"] = gs.best_estimator_
        self.best_params["Ridge"] = gs.best_params_
        self.cv_scores["Ridge"] = float(gs.best_score_)
        log.info("Ridge best alpha=%s CV R²=%.4f", gs.best_params_["alpha"], gs.best_score_)
        return gs.best_estimator_

    def tune_lasso(self, X_train: np.ndarray, y_train: np.ndarray):
        param_grid = {"alpha": [0.001, 0.01, 0.1, 1.0, 10.0, 100.0]}
        lasso = Lasso(random_state=self.random_state, max_iter=50_000)
        gs = GridSearchCV(
            lasso,
            param_grid,
            cv=5,
            scoring="r2",
            n_jobs=_N_JOBS,
        )
        gs.fit(X_train, y_train)
        self.models["Lasso"] = gs.best_estimator_
        self.best_params["Lasso"] = gs.best_params_
        self.cv_scores["Lasso"] = float(gs.best_score_)
        coef = gs.best_estimator_.coef_
        n_sel = int(np.sum(np.abs(coef) > 1e-8))
        log.info(
            "Lasso best alpha=%s CV R²=%.4f (non-zero coefs: %s/%s)",
            gs.best_params_["alpha"],
            gs.best_score_,
            n_sel,
            len(coef),
        )
        return gs.best_estimator_

    def tune_elasticnet(self, X_train: np.ndarray, y_train: np.ndarray):
        param_grid = {
            "alpha": [0.01, 0.1, 1.0, 10.0],
            "l1_ratio": [0.1, 0.5, 0.7, 0.9],
        }
        enet = ElasticNet(random_state=self.random_state, max_iter=50_000)
        gs = GridSearchCV(
            enet,
            param_grid,
            cv=5,
            scoring="r2",
            n_jobs=_N_JOBS,
        )
        gs.fit(X_train, y_train)
        self.models["ElasticNet"] = gs.best_estimator_
        self.best_params["ElasticNet"] = gs.best_params_
        self.cv_scores["ElasticNet"] = float(gs.best_score_)
        log.info("ElasticNet best %s CV R²=%.4f", gs.best_params_, gs.best_score_)
        return gs.best_estimator_

    def evaluate_on_test(
        self,
        X_test: np.ndarray,
        y_test: np.ndarray,
    ) -> dict[str, dict]:
        from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

        out: dict[str, dict] = {}
        for name, model in self.models.items():
            pred = model.predict(X_test)
            out[name] = {
                "R2": float(r2_score(y_test, pred)),
                "MAE": float(mean_absolute_error(y_test, pred)),
                "RMSE": float(np.sqrt(mean_squared_error(y_test, pred))),
                "coef": np.asarray(model.coef_).ravel().copy(),
                "intercept": float(model.intercept_),
            }
            log.info(
                "%s test  R²=%.4f  MAE=%.2f  RMSE=%.2f",
                name,
                out[name]["R2"],
                out[name]["MAE"],
                out[name]["RMSE"],
            )
        return out
