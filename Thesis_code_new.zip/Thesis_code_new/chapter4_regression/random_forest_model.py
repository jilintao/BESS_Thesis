"""Random Forest and Gradient Boosting with RandomizedSearchCV."""
from __future__ import annotations

import logging
from typing import Any

import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.model_selection import RandomizedSearchCV

import config

log = logging.getLogger(__name__)

_N_JOBS = 1
_N_ITER_RF = 40
_N_ITER_GB = 20


class TreeBasedModels:
    def __init__(self, random_state: int = config.RANDOM_STATE):
        self.random_state = random_state
        self.models: dict[str, Any] = {}
        self.best_params: dict[str, dict] = {}
        self.cv_scores: dict[str, float] = {}

    def tune_random_forest(
        self,
        X_train: np.ndarray,
        y_train: np.ndarray,
        feature_names: list[str] | None = None,
    ):
        param_dist = {
            "n_estimators": [100, 200, 400],
            "max_depth": [5, 10, 20, None],
            "min_samples_split": [2, 5, 10],
            "min_samples_leaf": [1, 2, 4],
            "max_features": ["sqrt", "log2", 1.0],
        }
        rf = RandomForestRegressor(random_state=self.random_state, n_jobs=_N_JOBS)
        rs = RandomizedSearchCV(
            rf,
            param_distributions=param_dist,
            n_iter=_N_ITER_RF,
            cv=5,
            scoring="r2",
            random_state=self.random_state,
            n_jobs=_N_JOBS,
        )
        rs.fit(X_train, y_train)
        self.models["RandomForest"] = rs.best_estimator_
        self.best_params["RandomForest"] = rs.best_params_
        self.cv_scores["RandomForest"] = float(rs.best_score_)
        log.info("RandomForest best %s CV R²=%.4f", rs.best_params_, rs.best_score_)
        return rs.best_estimator_

    def tune_gradient_boosting(self, X_train: np.ndarray, y_train: np.ndarray):
        param_dist = {
            "n_estimators": [100, 200],
            "max_depth": [3, 5, 7],
            "learning_rate": [0.01, 0.05, 0.1, 0.2],
            "min_samples_split": [2, 5],
            "subsample": [0.8, 0.9, 1.0],
        }
        gb = GradientBoostingRegressor(random_state=self.random_state)
        rs = RandomizedSearchCV(
            gb,
            param_distributions=param_dist,
            n_iter=_N_ITER_GB,
            cv=5,
            scoring="r2",
            random_state=self.random_state,
            n_jobs=_N_JOBS,
        )
        rs.fit(X_train, y_train)
        self.models["GradientBoosting"] = rs.best_estimator_
        self.best_params["GradientBoosting"] = rs.best_params_
        self.cv_scores["GradientBoosting"] = float(rs.best_score_)
        log.info("GradientBoosting best %s CV R²=%.4f", rs.best_params_, rs.best_score_)
        return rs.best_estimator_

    def feature_importance_df(self, feature_names: list[str]) -> pd.DataFrame:
        rf = self.models.get("RandomForest")
        if rf is None:
            raise RuntimeError("Fit RandomForest first.")
        return (
            pd.DataFrame({"feature": feature_names, "importance": rf.feature_importances_})
            .sort_values("importance", ascending=True)
            .reset_index(drop=True)
        )
