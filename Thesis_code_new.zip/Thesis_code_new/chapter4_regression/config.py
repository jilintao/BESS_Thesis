"""Paths and constants for Chapter 4.3 (rebuilt: regularized + tree models)."""
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parent
THESIS_ROOT = ROOT.parent

BAL_DATA = THESIS_ROOT / "chapter4_balancing" / "data"
SPOT_DATA = THESIS_ROOT / "chapter4_spot_arbitrage" / "data"
PROCESSED_PRICES = SPOT_DATA / "processed_prices.parquet"

RESULTS_DIR = ROOT / "results"
FIG_DIR = ROOT / "figures"
TABLES_DIR = ROOT / "tables"

for d in (RESULTS_DIR, FIG_DIR, TABLES_DIR):
    d.mkdir(parents=True, exist_ok=True)

# Model features (Spread excluded — multicollinearity with Volatility)
FEATURE_COLS = ["volatility", "spike_freq", "ramp_rate"]
FEATURE_LABELS = ["Volatility", "Spike frequency", "Ramp rate"]
TARGET_COL = "balancing_profit_eur"

# Diagnostics only (not used in estimation)
SPREAD_COL = "spread_diag"

RANDOM_STATE = 42
TEST_SIZE = 0.2
FIG_DPI = 300

FONT_FAMILY = "sans-serif"
FONT_SANS = ["Arial", "Helvetica", "DejaVu Sans"]
TITLE_FONTSIZE = 14
LABEL_FONTSIZE = 11
TICK_FONTSIZE = 10

COL_REG = "#2196F3"
COL_TREE = "#FF9800"
