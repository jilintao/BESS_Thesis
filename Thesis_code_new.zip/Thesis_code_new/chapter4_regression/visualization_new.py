"""Figures 4.14–4.19 (rebuilt Chapter 4.3)."""
from __future__ import annotations

from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.inspection import PartialDependenceDisplay
from sklearn.linear_model import Ridge, lasso_path

import config


def _style():
    plt.rcParams.update(
        {
            "font.family": config.FONT_FAMILY,
            "font.sans-serif": config.FONT_SANS,
            "font.size": config.TICK_FONTSIZE,
            "axes.titlesize": config.TITLE_FONTSIZE,
            "axes.labelsize": config.LABEL_FONTSIZE,
            "figure.dpi": config.FIG_DPI,
        }
    )


def _strip_figure_titles_only(fig: plt.Figure) -> None:
    """Remove figure suptitle and each axes' title only (not xlabel/ylabel or tick labels)."""
    try:
        fig.suptitle(None)
    except Exception:
        pass
    for ax in fig.get_axes():
        ax.set_title(None)


def _save(fig: plt.Figure, base: Path) -> None:
    base = Path(base)
    base.parent.mkdir(parents=True, exist_ok=True)
    _strip_figure_titles_only(fig)
    fig.savefig(f"{base}.png", dpi=config.FIG_DPI, bbox_inches="tight")
    fig.savefig(f"{base}.pdf", bbox_inches="tight")
    plt.close(fig)


def plot_regularized_coefficients(
    models: dict[str, Any],
    feature_labels: list[str],
    out_base: Path,
) -> None:
    """Figure 4.14: horizontal bar coefficients per regularized model."""
    _style()
    names = list(models.keys())
    n = len(names)
    fig, axes = plt.subplots(1, n, figsize=(4.2 * n, 4.5), layout="constrained")
    if n == 1:
        axes = np.array([axes])
    for ax, mname in zip(axes, names):
        coef = np.asarray(models[mname].coef_).ravel()
        ax.barh(feature_labels, coef, color=config.COL_REG, alpha=0.85)
        ax.axvline(0, color="gray", ls="--", lw=0.9)
        ax.set_xlabel("Coefficient (standardized X)")
    _save(fig, out_base)


def plot_regularization_paths(
    X_train_s: np.ndarray,
    y_train: np.ndarray,
    feature_labels: list[str],
    out_base: Path,
) -> None:
    """Figure 4.15: Ridge and Lasso coefficient paths (training sample, scaled X)."""
    _style()
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5), layout="constrained")
    # sklearn>=1.6 may not expose ridge_path; build path via Ridge fits
    alphas_ridge = np.logspace(-3, 4, 80)
    coefs_ridge = np.column_stack(
        [Ridge(alpha=a).fit(X_train_s, y_train).coef_ for a in alphas_ridge]
    )
    for i, lab in enumerate(feature_labels):
        axes[0].plot(alphas_ridge, coefs_ridge[i], label=lab, lw=1.5)
    axes[0].set_xscale("log")
    axes[0].set_xlabel("Alpha (Ridge)")
    axes[0].set_ylabel("Coefficient")
    axes[0].legend(fontsize=8, loc="best")

    alphas_lasso, coefs_lasso, _ = lasso_path(X_train_s, y_train)
    for i, lab in enumerate(feature_labels):
        axes[1].plot(alphas_lasso, coefs_lasso[i], label=lab, lw=1.5)
    axes[1].set_xscale("log")
    axes[1].set_xlabel("Alpha (Lasso)")
    axes[1].set_ylabel("Coefficient")
    axes[1].legend(fontsize=8, loc="best")
    _save(fig, out_base)


def plot_rf_importance(
    importances: pd.DataFrame,
    zone: str,
    out_base: Path,
) -> None:
    """Figure 4.16: Random Forest feature importance."""
    _style()
    fig, ax = plt.subplots(figsize=(8, 4), layout="constrained")
    ax.barh(importances["feature"], importances["importance"], color=config.COL_TREE, alpha=0.9)
    ax.set_xlabel("Importance")
    _save(fig, out_base)


def plot_partial_dependence(
    rf_model: Any,
    X_train_df: pd.DataFrame,
    feature_cols: list[str],
    out_base: Path,
) -> None:
    """Figure 4.17: PDP for each predictor."""
    _style()
    n = len(feature_cols)
    fig, axes = plt.subplots(1, n, figsize=(4.2 * n, 4), layout="constrained")
    if n == 1:
        axes = np.array([axes])
    PartialDependenceDisplay.from_estimator(
        rf_model,
        X_train_df,
        features=feature_cols,
        ax=axes,
        grid_resolution=25,
    )
    _save(fig, out_base)


def plot_model_comparison(comparison: pd.DataFrame, zone: str, out_base: Path) -> None:
    """Figure 4.18: R², MAE, RMSE bars."""
    _style()
    comp = comparison.reset_index()
    models = comp["model"].values
    colors = [config.COL_REG if t == "Regularized" else config.COL_TREE for t in comp["type"]]
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.2), layout="constrained")
    axes[0].bar(models, comp["R2_Test"], color=colors, alpha=0.9)
    axes[0].set_ylabel(r"$R^2$ (test)")
    axes[0].tick_params(axis="x", rotation=35)
    axes[1].bar(models, comp["MAE_Test"], color=colors, alpha=0.9)
    axes[1].set_ylabel("MAE (EUR/day)")
    axes[1].tick_params(axis="x", rotation=35)
    axes[2].bar(models, comp["RMSE_Test"], color=colors, alpha=0.9)
    axes[2].set_ylabel("RMSE (EUR/day)")
    axes[2].tick_params(axis="x", rotation=35)
    _save(fig, out_base)


def plot_residual_analysis(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    model_name: str,
    zone: str,
    out_base: Path,
    time_index: np.ndarray | None = None,
) -> None:
    """Figure 4.19: residual diagnostics on test set."""
    _style()
    resid = y_true - y_pred
    fig, axes = plt.subplots(2, 2, figsize=(11, 9), layout="constrained")
    axes[0, 0].scatter(y_pred, resid, alpha=0.35, s=12, edgecolors="none")
    axes[0, 0].axhline(0, color="crimson", ls="--", lw=1)
    axes[0, 0].set_xlabel("Fitted (EUR/day)")
    axes[0, 0].set_ylabel("Residual")

    axes[0, 1].hist(resid, bins=40, edgecolor="black", alpha=0.75)
    axes[0, 1].axvline(0, color="crimson", ls="--", lw=1)
    axes[0, 1].set_xlabel("Residual")

    stats.probplot(resid, dist="norm", plot=axes[1, 0])

    if time_index is not None:
        x = time_index
    else:
        x = np.arange(len(resid))
    axes[1, 1].scatter(x, resid, alpha=0.35, s=12, edgecolors="none")
    axes[1, 1].axhline(0, color="crimson", ls="--", lw=1)
    axes[1, 1].set_xlabel("Test observation order")
    axes[1, 1].set_ylabel("Residual")

    _save(fig, out_base)


def standardized_beta_table(
    df: pd.DataFrame,
    coef: np.ndarray,
    feature_cols: list[str],
    target_col: str,
) -> pd.DataFrame:
    """Optional interpretability: beta * sd(x)/sd(y) on full sample."""
    sy = float(df[target_col].std(ddof=0))
    rows = []
    for j, c in enumerate(feature_cols):
        sx = float(df[c].std(ddof=0))
        rows.append(
            {
                "feature": c,
                "coef_scaled_X": float(coef[j]),
                "std_coef": float(coef[j] * sx / sy) if sy > 0 else np.nan,
            }
        )
    return pd.DataFrame(rows)
