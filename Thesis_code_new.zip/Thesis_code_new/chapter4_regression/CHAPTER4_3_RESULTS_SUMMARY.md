# Chapter 4.3 — Rebuilt analysis (Ridge/Lasso/EN + trees)

**Disclaimer:** Associational proxy models for scenario screening — not causal inference.

## Variable selection

- **Estimation features:** Volatility, Spike frequency, Ramp rate (spread **excluded** — near-collinear with volatility).
- **Table 4.4** files: `tables/table4_4_vif_SE3.tex`, `tables/table4_4_vif_SE4.tex` compare VIF with vs without `spread_diag`.

## Outputs

- Daily panels: `results/daily_panel_SE*.csv`
- Model comparison: `results/model_comparison_SE*.csv` + `tables/table4_5_model_comparison_*.tex`
- Final table: `tables/table4_6_final_*.tex` + `results/table4_6_final_results_*.csv`
- Figures: `figures/fig4_14` … `fig4_19` (suffix `_SE3` / `_SE4`)

## Best models (test R²)

- **SE3:** RandomForest, test $R^2$=0.1169, days=2192, max VIF (no spread)=13.76
- **SE4:** RandomForest, test $R^2$=0.1696, days=2192, max VIF (no spread)=10.78

## Multicollinearity (after dropping spread)

- Max VIF on `volatility`, `spike_freq`, `ramp_rate` can still exceed 5 (see `results/vif_after_*.csv`). Ridge/Lasso shrink coefficients; interpret linear signs cautiously. Random Forest CV R² can exceed test R² — avoid over-claiming out-of-sample performance.

## Interpretation notes

- Random train/test split (20%) as specified; for a thesis robustness section, consider time-based split or expanding window CV.
- Tree models use **raw** features; regularized linear models use **standardized** features.
- If test $R^2$ is modest, report honestly: the linear proxy may be weak, which is a substantive finding.
