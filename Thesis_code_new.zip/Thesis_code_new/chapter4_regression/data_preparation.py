"""
Load hourly spot prices and daily balancing profit; build non-redundant indicators.

Correlational / proxy use — not causal inference. Spread is computed only for VIF
diagnostics (before/after variable removal), not for estimation.
"""
from __future__ import annotations

import logging
from typing import Literal

import numpy as np
import pandas as pd

import config

log = logging.getLogger(__name__)

MAX_MISSING_HOURS = 2


def _load_hourly_prices() -> pd.DataFrame:
    """Wide hourly DataFrame: DatetimeIndex (tz-aware), columns SE3, SE4."""
    df = pd.read_parquet(config.PROCESSED_PRICES)
    if not isinstance(df.index, pd.DatetimeIndex):
        if "timestamp" in df.columns:
            df = df.set_index("timestamp")
        else:
            raise ValueError("processed_prices.parquet must have DatetimeIndex or timestamp column")
    for z in ("SE3", "SE4"):
        if z not in df.columns:
            raise ValueError(f"Missing column {z} in processed_prices.parquet")
    df = df.sort_index()
    if len(df) >= 3:
        med = pd.Series(df.index).diff().median()
        if pd.notna(med) and med < pd.Timedelta(minutes=59):
            df = df.resample("1h").mean(numeric_only=True)
    return df


def _global_p95(prices: pd.DataFrame) -> float:
    """Single P95 across all SE3 and SE4 hourly observations (full sample)."""
    v = pd.concat([prices["SE3"].dropna(), prices["SE4"].dropna()], ignore_index=True)
    return float(v.quantile(0.95))


def _stockholm_day(ts: pd.Timestamp) -> pd.Timestamp:
    if ts.tzinfo is None:
        ts = ts.tz_localize("UTC")
    return ts.tz_convert("Europe/Stockholm").normalize()


def _daily_indicators_for_zone(
    hourly: pd.Series,
    p95: float,
) -> pd.DataFrame:
    """
    One row per calendar day (Stockholm): volatility, spike_freq, ramp_rate, spread_diag.
    Skip days with more than MAX_MISSING_HOURS missing after requiring >= 22 observed hours.
    """
    s = hourly.copy()
    if s.empty:
        return pd.DataFrame()

    day_idx = pd.Series([_stockholm_day(t) for t in s.index], index=s.index)
    rows = []
    for day, grp in s.groupby(day_idx):
        vals = grp.sort_index().astype(float)
        if len(vals) < 22:
            continue
        n_miss = int(vals.isna().sum())
        if n_miss > MAX_MISSING_HOURS:
            continue
        prices = vals.interpolate(method="linear", limit=MAX_MISSING_HOURS)
        if prices.isna().any():
            continue
        vol = float(prices.std(ddof=0))
        spike = int((prices > p95).sum())
        ramp = float(prices.diff().abs().max())
        spread = float(prices.max() - prices.min())
        d = pd.Timestamp(day)
        if d.tzinfo is not None:
            out_date = d.tz_convert("UTC").tz_localize(None).normalize()
        else:
            out_date = d.normalize()
        rows.append(
            {
                "date": out_date,
                "volatility": vol,
                "spike_freq": spike,
                "ramp_rate": ramp,
                "spread_diag": spread,
            }
        )
    return pd.DataFrame(rows)


def _normalize_merge_date(series: pd.Series) -> pd.Series:
    dt = pd.to_datetime(series, utc=True)
    return dt.dt.tz_localize(None).dt.normalize()


def load_balancing_daily(zone: Literal["SE3", "SE4"]) -> pd.DataFrame:
    path = config.BAL_DATA / f"daily_balancing_{zone}.csv"
    if not path.is_file():
        raise FileNotFoundError(f"Missing {path}")
    df = pd.read_csv(path, parse_dates=["date"])
    df["date"] = _normalize_merge_date(df["date"])
    return df[["date", config.TARGET_COL]].copy()


def prepare_zone_dataframe(zone: Literal["SE3", "SE4"]) -> pd.DataFrame:
    """Merged daily panel: indicators + balancing_profit_eur."""
    prices = _load_hourly_prices()
    p95 = _global_p95(prices)
    ind = _daily_indicators_for_zone(prices[zone], p95)
    if ind.empty:
        raise RuntimeError(f"No daily indicators for {zone}")

    bal = load_balancing_daily(zone)
    out = ind.merge(bal, on="date", how="inner")
    out = out.dropna(subset=config.FEATURE_COLS + [config.TARGET_COL])
    log.info("%s: %s days after merge (P95=%.2f EUR/MWh)", zone, len(out), p95)
    return out.reset_index(drop=True)


def prepare_all_zones() -> dict[str, pd.DataFrame]:
    return {"SE3": prepare_zone_dataframe("SE3"), "SE4": prepare_zone_dataframe("SE4")}


def compute_vif_dataframe(df: pd.DataFrame, feature_cols: list[str]) -> pd.DataFrame:
    """VIF per feature; VIF > 5 often treated as problematic."""
    from statsmodels.stats.outliers_influence import variance_inflation_factor

    sub = df[feature_cols].astype(float).dropna()
    if len(sub) < len(feature_cols) + 2:
        raise ValueError("Insufficient rows for VIF.")
    X = sub.values
    rows = []
    for i, name in enumerate(feature_cols):
        rows.append({"feature": name, "vif": float(variance_inflation_factor(X, i))})
    return pd.DataFrame(rows)


def train_test_split_arrays(
    df: pd.DataFrame,
    feature_cols: list[str],
    target_col: str,
    test_size: float = config.TEST_SIZE,
    random_state: int = config.RANDOM_STATE,
):
    """
    Random split indices (user spec). Returns scaled X for linear models,
    raw X for tree models, and test indices for dates.
    """
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import StandardScaler

    X = df[feature_cols].to_numpy(dtype=float)
    y = df[target_col].to_numpy(dtype=float)
    idx = np.arange(len(df))
    i_train, i_test = train_test_split(
        idx, test_size=test_size, random_state=random_state, shuffle=True
    )
    scaler = StandardScaler()
    X_train_s = scaler.fit_transform(X[i_train])
    X_test_s = scaler.transform(X[i_test])
    return {
        "X_train_s": X_train_s,
        "X_test_s": X_test_s,
        "X_train_raw": X[i_train],
        "X_test_raw": X[i_test],
        "y_train": y[i_train],
        "y_test": y[i_test],
        "scaler": scaler,
        "train_idx": i_train,
        "test_idx": i_test,
        "test_dates": df.iloc[i_test]["date"].reset_index(drop=True),
    }
