# Thesis replication code (updated) — Swedish electricity markets (Chapters 4.1–4.4)

**`Thesis_code_new`** is the replication package for GitHub: same layout as `Thesis_code`, synced from the active workspace `chapter4_*` folders.

**Large outputs are not shipped** (`*.parquet`, `*.joblib`, figure `*.png`, bulky `*.csv`). Clone the repo, set `ENTSOE_API_KEY`, run `pip install -r requirements.txt`, then `.\RUN_FULL_THESIS_PIPELINE.ps1` (or run each chapter’s `main*.py` as in the old README) to regenerate data and figures.

---

## Layout

| Folder | Role |
|--------|------|
| `chapter4_spot_arbitrage/` | Day-ahead SE3/SE4, HICP, daily PuLP arbitrage (§4.1). |
| `chapter4_balancing/` | A84/A81 streams, preprocessing, upper-bound optimisation (§4.2). |
| `chapter4_regression/` | Daily panel, VIF, linear + tree models, LaTeX tables (§4.3). |
| `chapter4_scenario_analysis/` | Day-ahead scenarios, proxy, sensitivity (§4.4). |

---

## Quick start

```powershell
python -m venv .venv
.\.venv\Scripts\activate
pip install -r requirements.txt
$env:ENTSOE_API_KEY = "<your token>"
.\RUN_FULL_THESIS_PIPELINE.ps1
```

Figures only (after a full run once): `.\REGENERATE_FIGURES_ONLY.ps1`

---

## Sync from your thesis workspace

If you edit `chapter4_*` one level **above** this folder (same parent as `Thesis_code_new`), run from that parent:

`.\SYNC_TO_THESIS_CODE_NEW.ps1`

---

See **`APPENDIX_A_libraries_and_repository.md`** for libraries. Update the GitHub URL there after publishing.
