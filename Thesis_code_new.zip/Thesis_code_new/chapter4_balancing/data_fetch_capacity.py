"""
Contracted reserve (capacity) prices — ENTSO-E process types A51 (aFRR), A47 (mFRR), A52 (FCR).

Returns wide frames indexed in API timezone (UTC); caller localizes and preprocesses.
Columns are typically ``Down`` / ``Up`` (two-sided products) or ``Symmetric`` (FCR).

Uses the same bisection + timeout strategy as activation fetches when the gateway is slow
or returns 504 / pagination errors.
"""
from __future__ import annotations

import logging
import time

import pandas as pd
from entsoe import EntsoePandasClient
from entsoe.exceptions import NoMatchingDataError

import config
from entsoe_fetch_utils import fetch_time_range_with_bisect, make_client

logger = logging.getLogger(__name__)


def fetch_contracted_reserve_prices_chunk(
    client: EntsoePandasClient,
    country_code: str,
    process_type: str,
    start: pd.Timestamp,
    end: pd.Timestamp,
) -> pd.DataFrame:
    """Single logical API window; may bisect internally on gateway errors."""

    def once(s: pd.Timestamp, e: pd.Timestamp):
        try:
            return client.query_contracted_reserve_prices(
                country_code,
                process_type=process_type,
                type_marketagreement_type="A01",
                start=s,
                end=e,
            )
        except NoMatchingDataError:
            logger.info(
                "No contracted-reserve data (process=%s) for %s .. %s",
                process_type,
                s,
                e,
            )
            return pd.DataFrame()

    tag = f"capacity {country_code} {process_type}"
    return fetch_time_range_with_bisect(once, start, end, tag=tag)


def fetch_capacity_wide_year_chunks(
    api_key: str,
    country_code: str,
    process_type: str,
    start_date: str,
    end_date: str,
) -> pd.DataFrame:
    """Calendar chunks; concatenated sorted index, de-duplicated."""
    client = make_client(api_key)
    start = pd.Timestamp(start_date, tz="UTC")
    end = pd.Timestamp(end_date, tz="UTC")
    parts: list[pd.DataFrame] = []
    chunk_months = getattr(config, "API_CHUNK_MONTHS", 1)
    chunk_start = start
    while chunk_start < end:
        chunk_end = min(chunk_start + pd.DateOffset(months=chunk_months), end)
        logger.info(
            "Fetching capacity prices %s process=%s %s .. %s",
            country_code,
            process_type,
            chunk_start,
            chunk_end,
        )
        raw = fetch_contracted_reserve_prices_chunk(client, country_code, process_type, chunk_start, chunk_end)
        if not raw.empty:
            parts.append(raw)
        chunk_start = chunk_end
        time.sleep(0.35)

    if not parts:
        return pd.DataFrame()
    out = pd.concat(parts).sort_index()
    out = out[~out.index.duplicated(keep="last")]
    return out
