"""Figures 4.6–4.9 for balancing market results."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

import config


def _style():
    plt.rcParams.update(
        {
            "font.family": config.FONT_FAMILY,
            "font.sans-serif": config.FONT_SANS,
            "font.size": config.TICK_FONTSIZE,
            "axes.titlesize": config.TITLE_FONTSIZE,
            "axes.labelsize": config.LABEL_FONTSIZE,
            "figure.dpi": config.FIG_DPI,
        }
    )


def _clear_figure_titles(fig: plt.Figure) -> None:
    try:
        fig.suptitle(None)
    except Exception:
        pass
    for ax in fig.get_axes():
        ax.set_title(None)


def _save(fig: plt.Figure, base: Path) -> None:
    base = Path(base)
    base.parent.mkdir(parents=True, exist_ok=True)
    _clear_figure_titles(fig)
    fig.savefig(f"{base}.png", dpi=config.FIG_DPI, bbox_inches="tight")
    fig.savefig(f"{base}.pdf", bbox_inches="tight")
    plt.close(fig)


def plot_balancing_price_overview(
    df_hourly: pd.DataFrame,
    df_native: pd.DataFrame,
    zone: str,
    availability_text: str,
    out_base: Path,
) -> str:
    """Figure 4.6: daily mean hourly price_net + daily std of native-resolution price_net."""
    _style()
    fig, ax1 = plt.subplots(figsize=(12, 5))
    ax2 = ax1.twinx()

    h = df_hourly.copy()
    if h.index.tz is None:
        h.index = h.index.tz_localize(config.LOCAL_TZ)
    else:
        h.index = h.index.tz_convert(config.LOCAL_TZ)
    dmean = h.groupby(h.index.normalize())["price_net"].mean()
    dmean.plot(ax=ax1, color=config.COLORS["net"], lw=1.2, label="Daily mean $p^{net}$ (hourly avg.)")

    if not df_native.empty and "price_net" in df_native.columns:
        n = df_native.copy()
        if n.index.tz is None:
            n.index = n.index.tz_localize(config.LOCAL_TZ)
        else:
            n.index = n.index.tz_convert(config.LOCAL_TZ)
        dstd = n.groupby(n.index.normalize())["price_net"].std()
        dstd.plot(ax=ax2, color="gray", ls="--", lw=0.9, alpha=0.8, label="Daily stdev ($p^{net}$, native)")
    else:
        dstd = h.groupby(h.index.normalize())["price_net"].std()
        dstd.plot(
            ax=ax2,
            color="gray",
            ls="--",
            lw=0.9,
            alpha=0.8,
            label="Daily stdev ($p^{net}$, hourly)",
        )

    # Shade days with strong balancing signal
    hi = h.groupby(h.index.normalize())["price_net"].apply(lambda s: np.max(np.abs(s.dropna())))
    for d0, mx in hi.items():
        if mx > 100:
            d1 = d0 + pd.Timedelta(days=1)
            ax1.axvspan(d0, d1, color=config.COLORS["net"], alpha=0.06)

    ax1.set_ylabel(r"Daily mean $p^{up}-p^{down}$ (EUR/MWh)")
    ax2.set_ylabel(r"Daily stdev (EUR/MWh)")
    ax1.set_xlabel("Date")
    ax1.text(
        0.02,
        0.98,
        availability_text,
        transform=ax1.transAxes,
        fontsize=8,
        va="top",
        ha="left",
        bbox=dict(boxstyle="round", facecolor="wheat", alpha=0.35),
    )
    h1, l1 = ax1.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax1.legend(h1 + h2, l1 + l2, loc="upper left", framealpha=0.9)
    ax1.xaxis.set_major_locator(mdates.YearLocator())
    ax1.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
    fig.autofmt_xdate()
    plt.tight_layout()
    _save(fig, out_base)
    return (
        "aFRR net activation prices (2025 EUR): daily mean of hourly "
        r"$p^{net}=p^{up}-p^{down}$; dashed axis: daily variability at native API resolution where available."
    )


def pick_high_vol_day(
    df_hourly: pd.DataFrame,
    zone: str,
) -> Optional[pd.Timestamp]:
    if df_hourly.empty:
        return None
    s = df_hourly.copy()
    if s.index.tz is None:
        s.index = s.index.tz_localize(config.LOCAL_TZ)
    best_day, best_score = None, -1.0
    for day, block in s.groupby(s.index.normalize()):
        if len(block) < 22:
            continue
        if block[["price_up", "price_down"]].isna().any().any():
            continue
        score = float(np.std(block["price_net"].values))
        if score > best_score:
            best_score = score
            best_day = day
    if best_day is None:
        return None
    d = pd.Timestamp(best_day).normalize()
    if d.tz is None:
        d = d.tz_localize(config.LOCAL_TZ)
    else:
        d = d.tz_convert(config.LOCAL_TZ)
    return d


def plot_balancing_dispatch_example(
    block: pd.DataFrame,
    day: pd.Timestamp,
    profit: float,
    zone: str,
    out_base: Path,
) -> str:
    _style()
    b = block.sort_values("interval") if "interval" in block.columns else block.sort_values("hour")
    if "interval" in b.columns:
        hours = b["interval"].values.astype(int)
        x_label = "Interval index (native resolution)"
        use_xticks = None
    else:
        hours = b["hour"].values
        x_label = "Hour of day"
        use_xticks = range(24)
    fig, axes = plt.subplots(3, 1, figsize=(10, 8), sharex=True)

    ax = axes[0]
    ax.plot(hours, b["price_up"], color=config.COLORS["up"], lw=2, marker="o", ms=3, label=r"$p^{up}$")
    ax.plot(hours, b["price_down"], color=config.COLORS["down"], lw=2, marker="s", ms=3, label=r"$p^{down}$")
    ax.plot(hours, b["price_net"], color=config.COLORS["net"], lw=1.5, ls=":", label=r"$p^{net}$")
    ax.set_ylabel("Price (EUR/MWh)")
    ax.legend(loc="upper right", fontsize=8)

    ax = axes[1]
    ax.plot(hours, b["soc_mwh"], color=config.COLORS["soc"], lw=2)
    ax.axhline(config.BATTERY_PARAMS["SOC_min"], color="k", ls="--", lw=0.8)
    ax.axhline(config.BATTERY_PARAMS["SOC_max"], color="k", ls="--", lw=0.8)
    ax.set_ylabel("SOC (MWh)")

    ax = axes[2]
    w = 0.36 if len(np.unique(hours)) > 24 else 0.4
    ax.bar(hours - w / 2, b["charge_mw"], width=w, color=config.COLORS["down"], label="Charge (down)")
    ax.bar(hours + w / 2, b["discharge_mw"], width=w, color=config.COLORS["up"], label="Discharge (up)")
    ax.set_ylabel("Power (MW)")
    ax.set_xlabel(x_label)
    if use_xticks is not None:
        ax.set_xticks(list(use_xticks))
    ax.legend(loc="upper right")

    bp = config.BATTERY_PARAMS
    txt = (
        f"E_max={bp['E_max']:.0f} MWh, P_max={bp['P_max']:.0f} MW, $\\eta$={bp['eta']}, "
        f"$c_{{deg}}$={bp['c_deg']:.0f} EUR/MWh\n"
        f"Daily stacked profit (all streams): {profit:,.0f} EUR"
    )
    fig.text(0.12, 0.02, txt, fontsize=9, family="monospace")
    plt.tight_layout(rect=(0, 0.06, 1, 1))
    _save(fig, out_base)
    return "High-volatility example day (aFRR activation stream); native timestep if >24 intervals."


def plot_spot_vs_balancing_scatter(
    daily_spot: dict[str, pd.DataFrame],
    daily_bal: dict[str, pd.DataFrame],
    out_base: Path,
) -> str:
    _style()
    fig, axes = plt.subplots(1, 2, figsize=(11, 5), sharey=True)
    season_colors = {1: "#1f77b4", 2: "#2ca02c", 3: "#ff7f0e", 4: "#d62728"}

    for ax, z in zip(axes, ["SE3", "SE4"]):
        if z not in daily_spot or z not in daily_bal:
            ax.text(0.5, 0.5, f"No data {z}", ha="center")
            continue
        a = daily_spot[z][["date", "arbitrage_profit_eur"]].copy()
        b = daily_bal[z][["date", "balancing_profit_eur"]].copy()
        a["d"] = pd.to_datetime(a["date"], utc=True).dt.date
        b["d"] = pd.to_datetime(b["date"], utc=True).dt.date
        ms = pd.merge(
            a.drop(columns=["date"]),
            b.drop(columns=["date"]),
            on="d",
            how="inner",
        )
        if ms.empty:
            ax.text(0.5, 0.5, f"No overlap {z}", ha="center")
            continue
        mo = ms["d"].map(lambda x: x.month if hasattr(x, "month") else pd.Timestamp(x).month)
        ms["quarter"] = ((mo - 1) // 3 + 1).astype(int)
        for q in range(1, 5):
            sub = ms[ms["quarter"] == q]
            ax.scatter(
                sub["arbitrage_profit_eur"],
                sub["balancing_profit_eur"],
                s=12,
                alpha=0.5,
                c=season_colors[q],
                label=f"Q{q}",
            )
        r = float(ms["arbitrage_profit_eur"].corr(ms["balancing_profit_eur"]))
        ax.text(
            0.02,
            0.98,
            f"{z} — Pearson $r={r:.3f}$",
            transform=ax.transAxes,
            fontsize=9,
            va="top",
            ha="left",
        )
        ax.set_xlabel("Daily spot arbitrage profit (EUR)")
        ax.axhline(0, color="#ccc", lw=0.8)
        ax.axvline(0, color="#ccc", lw=0.8)
        ax.legend(loc="upper left", fontsize=7, ncol=2)
    axes[0].set_ylabel("Daily balancing profit (EUR)")
    plt.tight_layout()
    _save(fig, out_base)
    return "Paired daily profits (virtual separate assets); colour by calendar quarter."


def plot_balancing_seasonality(
    daily_by_zone: dict[str, pd.DataFrame],
    out_base: Path,
) -> str:
    _style()
    fig, ax = plt.subplots(figsize=(10, 5))
    months = np.arange(1, 13)
    width = 0.35
    for i, z in enumerate(["SE3", "SE4"]):
        df = daily_by_zone.get(z)
        if df is None or df.empty:
            continue
        g = df.groupby(pd.to_datetime(df["date"]).dt.month)["balancing_profit_eur"]
        mmean = g.mean().reindex(months)
        mstd = g.std(ddof=1).reindex(months)
        offset = (i - 0.5) * width
        ax.bar(
            months + offset,
            mmean,
            width,
            yerr=mstd,
            capsize=2,
            label=z,
            color=config.COLORS.get(z),
            ecolor="#444",
            alpha=0.88,
        )
    ax.set_xticks(months)
    ax.set_xlabel("Month")
    ax.set_ylabel("Mean daily balancing profit (EUR)")
    ax.legend()
    plt.tight_layout()
    _save(fig, out_base)
    return "Mean daily balancing profit by calendar month ±1 std across years."
