"""Table 4.3 style summaries for balancing results."""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd


def compute_balancing_summary(
    daily_by_zone: dict[str, pd.DataFrame],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    zones = list(daily_by_zone.keys())
    if not zones:
        return pd.DataFrame(), pd.DataFrame()

    merged = None
    for z, df in daily_by_zone.items():
        d = df[["date", "balancing_profit_eur"]].copy()
        d = d.rename(columns={"balancing_profit_eur": z})
        merged = d if merged is None else pd.merge(merged, d, on="date", how="outer")
    assert merged is not None
    merged["Combined"] = merged[[c for c in zones if c in merged.columns]].sum(
        axis=1, min_count=1
    )

    col_order = zones + ["Combined"]
    rows: list[dict[str, object]] = []

    def add_row(metric: str, fn):
        row = {"Metric": metric}
        for c in col_order:
            ser = merged[c].dropna()
            row[c] = fn(ser) if len(ser) else np.nan
        rows.append(row)

    add_row("Mean Daily Profit (€)", lambda s: float(s.mean()))
    add_row("Std Daily Profit (€)", lambda s: float(s.std(ddof=1)) if len(s) > 1 else 0.0)
    add_row("Median Daily Profit (€)", lambda s: float(s.median()))
    add_row("Min Daily Profit (€)", lambda s: float(s.min()))
    add_row("Max Daily Profit (€)", lambda s: float(s.max()))

    summary = pd.DataFrame(rows).set_index("Metric")[col_order]
    tot = pd.DataFrame(
        [[float(merged[c].sum()) for c in col_order]],
        columns=col_order,
        index=["Total 6-year Revenue (€)"],
    )
    summary = pd.concat([summary, tot])

    years = sorted(
        pd.unique(pd.concat([df["date"] for df in daily_by_zone.values()]).dt.year.dropna())
    )
    year_rows = []
    for y in years:
        r: dict[str, object] = {"Year": int(y)}
        comb = 0.0
        for z in zones:
            sub = daily_by_zone[z][daily_by_zone[z]["date"].dt.year == y]
            v = float(sub["balancing_profit_eur"].sum()) if len(sub) else 0.0
            r[z] = v
            comb += v
        r["Combined"] = comb
        year_rows.append(r)
    annual = pd.DataFrame(year_rows).set_index("Year")

    return summary, annual


def save_table_tex_csv(
    summary: pd.DataFrame,
    annual: pd.DataFrame,
    out_dir: Path,
    stem: str = "table4_3_balancing_summary",
) -> None:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    summary.to_csv(out_dir / f"{stem}_summary.csv")
    annual.to_csv(out_dir / f"{stem}_annual.csv")

    tex = out_dir / f"{stem}.tex"
    lines = [
        r"\begin{tabular}{l" + "r" * len(summary.columns) + "}",
        r"\hline",
        r"Metric & " + " & ".join(summary.columns) + r" \\",
        r"\hline",
    ]
    for idx, row in summary.iterrows():
        vals = " & ".join(
            f"{v:,.2f}" if isinstance(v, (float, np.floating)) else str(v) for v in row
        )
        lines.append(f"{idx} & {vals} \\\\")
    lines.extend([r"\hline", r"\end{tabular}"])
    tex.write_text("\n".join(lines), encoding="utf-8")
