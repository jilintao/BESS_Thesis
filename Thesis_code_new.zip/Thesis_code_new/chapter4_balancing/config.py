"""
Balancing market (aFRR activated prices) pipeline — paths, battery, style.
API key: set environment variable ENTSOE_API_KEY only (never commit secrets).
"""
from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
FIG_DIR = ROOT / "figures"
LOG_DIR = ROOT / "logs"

for d in (DATA_DIR, FIG_DIR, LOG_DIR):
    d.mkdir(parents=True, exist_ok=True)

ENTSOE_API_KEY = os.environ.get("ENTSOE_API_KEY")
if not ENTSOE_API_KEY:
    pass  # main_bal raises with clear message

BIDDING_ZONES = {"SE3": "SE_3", "SE4": "SE_4"}

START_DATE = "2020-01-01"
END_DATE = "2026-01-01"

# ENTSO-E: prefer small windows; on 504/timeout we bisect further (see entsoe_fetch_utils).
API_CHUNK_MONTHS = 1
API_HTTP_TIMEOUT = 120
API_RETRY_SHORT = 4
API_MIN_SPLIT_DAYS = 3

# ENTSO-E: A84 activated balancing energy prices (processType A16 for SE).
PROCESS_TYPE_ACTIVATION = "A16"
BUSINESS_TYPE_AFRR = "A96"
BUSINESS_TYPE_MFRR = "A97"

# Contracted reserve (capacity) procurement prices — process types
CAPACITY_PROCESS_AFRR = "A51"
CAPACITY_PROCESS_MFRR = "A47"
CAPACITY_PROCESS_FCR = "A52"
# No capacity revenue before these dates (publication / product availability).
CAPACITY_START_AFRR = "2022-01-01"
CAPACITY_START_MFRR_FCR = "2024-01-01"

BATTERY_PARAMS = {
    "E_max": 100.0,
    "P_max": 25.0,
    "eta": 0.90,
    "SOC_min": 10.0,
    "SOC_max": 100.0,
    "SOC_0": 50.0,
    "c_deg": 20.0,
    "C_max": 2.0,
}

LOCAL_TZ = "Europe/Stockholm"
MAX_INTERP_GAP_HOURS = 2
PRICE_CLIP_LOWER = -150.0
PRICE_CLIP_UPPER = 500.0
MISSING_DIRECTION_WARN_FRAC = 0.30

# Optional: align EUR real terms with spot chapter (Eurostat SE HICP)
APPLY_CPI = True
CPI_BASE_YEAR = 2025

# Spot daily results for Figure 4.8 (relative to repo / thesis folder)
SPOT_DAILY_GLOB = Path(__file__).resolve().parents[1] / "chapter4_spot_arbitrage" / "data"

COLORS = {
    "up": "#D32F2F",
    "down": "#1976D2",
    "net": "#7B1FA2",
    "SE3": "#2196F3",
    "SE4": "#FF9800",
    "soc": "#43A047",
}

FONT_FAMILY = "sans-serif"
FONT_SANS = ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"]
TITLE_FONTSIZE = 14
LABEL_FONTSIZE = 11
TICK_FONTSIZE = 10
FIG_DPI = 300

FIG_NAMES = {
    "fig4_6": "fig4_6_balancing_prices",
    "fig4_7": "fig4_7_balancing_dispatch",
    "fig4_8": "fig4_8_spot_vs_balancing_scatter",
    "fig4_9": "fig4_9_balancing_seasonality",
}
