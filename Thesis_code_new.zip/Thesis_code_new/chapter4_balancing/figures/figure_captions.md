# Figure captions (Chapter 4.2 — balancing / aFRR)

## Figure 4.6

Daily mean of hourly net activation price \(p^{net} = p^{up} - p^{down}\) (2025 EUR); dashed line: daily standard deviation of \(p^{net}\) at native API resolution (or hourly if native unavailable). Light shading: days with \(\max_t |p^{net}_t| > 100\) EUR/MWh. Text box: share of hours with non-missing up and down prices.

## Figure 4.7

Representative high-volatility day: hourly up-regulation and down-regulation activation prices, SOC trajectory with bounds, and charge/discharge power (perfect foresight, virtual balancing-only battery).

## Figure 4.8

Scatter of daily spot arbitrage profit (Section 4.1) vs.\ daily balancing profit by calendar quarter; Pearson correlation in panel title. Virtual separate assets per zone.

## Figure 4.9

Mean daily balancing profit by calendar month with ±1 standard deviation across years; SE3 vs SE4.
