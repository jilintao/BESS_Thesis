"""
Fetch activated balancing energy prices (ENTSO-E document A84) for Swedish zones.

aFRR: businessType A96; mFRR: A97. Up/Down appear as separate rows (Direction column).
For Sweden, processType A16 is used with these business types (entsoe-py defaults).

Resilience: small calendar chunks, HTTP timeout on the client, and automatic bisection
of the query window when the gateway returns 504 / timeouts / pagination limits.
"""
from __future__ import annotations

import logging
import time

import pandas as pd
from entsoe import EntsoePandasClient

import config
from entsoe_fetch_utils import fetch_time_range_with_bisect, make_client

logger = logging.getLogger(__name__)


def fetch_afrr_activated_prices_long(
    client: EntsoePandasClient,
    country_code: str,
    start: pd.Timestamp,
    end: pd.Timestamp,
) -> pd.DataFrame:
    """
    Returns long-format DataFrame (index = timestamp, columns Direction, Price, ReserveType).
    """

    def once(s: pd.Timestamp, e: pd.Timestamp):
        return client.query_activated_balancing_energy_prices(
            country_code,
            start=s,
            end=e,
            process_type=config.PROCESS_TYPE_ACTIVATION,
            business_type=config.BUSINESS_TYPE_AFRR,
        )

    tag = f"A84 aFRR {country_code}"
    return fetch_time_range_with_bisect(once, start, end, tag=tag)


def fetch_mfrr_activated_prices_long(
    client: EntsoePandasClient,
    country_code: str,
    start: pd.Timestamp,
    end: pd.Timestamp,
) -> pd.DataFrame:
    """mFRR activated balancing energy prices (A84, businessType A97)."""

    def once(s: pd.Timestamp, e: pd.Timestamp):
        return client.query_activated_balancing_energy_prices(
            country_code,
            start=s,
            end=e,
            process_type=config.PROCESS_TYPE_ACTIVATION,
            business_type=config.BUSINESS_TYPE_MFRR,
        )

    tag = f"A84 mFRR {country_code}"
    return fetch_time_range_with_bisect(once, start, end, tag=tag)


def long_to_wide_prices(df_long: pd.DataFrame, reserve_type: str) -> pd.DataFrame:
    """Pivot Up/Down prices to columns price_up, price_down (€/MWh)."""
    if df_long.empty or "Direction" not in df_long.columns or "Price" not in df_long.columns:
        return pd.DataFrame(columns=["price_up", "price_down"])

    if "ReserveType" in df_long.columns:
        sub = df_long[df_long["ReserveType"] == reserve_type].copy()
    else:
        sub = df_long.copy()
    if sub.empty:
        sub = df_long.copy()

    wide = sub.pivot_table(
        index=sub.index,
        columns="Direction",
        values="Price",
        aggfunc="mean",
    )
    wide.columns = [str(c) for c in wide.columns]
    out = pd.DataFrame(index=wide.index)
    out["price_up"] = wide["Up"] if "Up" in wide.columns else pd.NA
    out["price_down"] = wide["Down"] if "Down" in wide.columns else pd.NA
    out = out.sort_index()
    out = out[~out.index.duplicated(keep="last")]
    return out


def fetch_balancing_wide_year_chunks(
    api_key: str,
    country_code: str,
    start_date: str,
    end_date: str,
) -> pd.DataFrame:
    """Calendar chunks; wide price_up / price_down, native API resolution (aFRR)."""
    client = make_client(api_key)
    start = pd.Timestamp(start_date, tz="UTC")
    end = pd.Timestamp(end_date, tz="UTC")
    parts: list[pd.DataFrame] = []
    chunk_months = getattr(config, "API_CHUNK_MONTHS", 1)
    chunk_start = start
    while chunk_start < end:
        chunk_end = min(chunk_start + pd.DateOffset(months=chunk_months), end)
        logger.info("Fetching A84 aFRR %s %s .. %s", country_code, chunk_start, chunk_end)
        raw = fetch_afrr_activated_prices_long(client, country_code, chunk_start, chunk_end)
        if not raw.empty:
            wide = long_to_wide_prices(raw, "aFRR")
            if not wide.empty:
                parts.append(wide)
        chunk_start = chunk_end
        time.sleep(0.35)

    if not parts:
        return pd.DataFrame(columns=["price_up", "price_down"])
    out = pd.concat(parts).sort_index()
    out = out[~out.index.duplicated(keep="last")]
    return out


def fetch_mfrr_balancing_wide_year_chunks(
    api_key: str,
    country_code: str,
    start_date: str,
    end_date: str,
) -> pd.DataFrame:
    """mFRR activation prices (A84, A97), native API resolution."""
    client = make_client(api_key)
    start = pd.Timestamp(start_date, tz="UTC")
    end = pd.Timestamp(end_date, tz="UTC")
    parts: list[pd.DataFrame] = []
    chunk_months = getattr(config, "API_CHUNK_MONTHS", 1)
    chunk_start = start
    while chunk_start < end:
        chunk_end = min(chunk_start + pd.DateOffset(months=chunk_months), end)
        logger.info("Fetching A84 mFRR %s %s .. %s", country_code, chunk_start, chunk_end)
        raw = fetch_mfrr_activated_prices_long(client, country_code, chunk_start, chunk_end)
        if not raw.empty:
            wide = long_to_wide_prices(raw, "mFRR")
            if not wide.empty:
                parts.append(wide)
        chunk_start = chunk_end
        time.sleep(0.35)

    if not parts:
        return pd.DataFrame(columns=["price_up", "price_down"])
    out = pd.concat(parts).sort_index()
    out = out[~out.index.duplicated(keep="last")]
    return out
