"""
Chapter 4.2 pipeline: fetch aFRR + mFRR activation (A84) and capacity prices (A51/A47/A52),
native-resolution activation LPs, analytical capacity revenues, merge to daily ``balancing_profit_eur``.

Requires: ``export ENTSOE_API_KEY`` before running (never hardcode).
"""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

import pandas as pd

import config
from data_clean_bal import (
    full_balancing_preprocessing,
    full_capacity_preprocessing,
    validate_balancing_data,
)
from data_fetch_bal import fetch_balancing_wide_year_chunks, fetch_mfrr_balancing_wide_year_chunks
from data_fetch_capacity import fetch_capacity_wide_year_chunks
from optimization_bal import build_daily_capacity_revenue, run_daily_balancing_optimization
from results_bal import compute_balancing_summary, save_table_tex_csv
from visualization_bal import (
    pick_high_vol_day,
    plot_balancing_dispatch_example,
    plot_balancing_price_overview,
    plot_balancing_seasonality,
    plot_spot_vs_balancing_scatter,
)


def _setup_logging() -> None:
    config.LOG_DIR.mkdir(parents=True, exist_ok=True)
    fh = logging.FileHandler(config.LOG_DIR / "balancing_preprocessing.log", encoding="utf-8")
    sh = logging.StreamHandler(sys.stdout)
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[sh, fh],
    )


def _load_spot_daily() -> dict[str, pd.DataFrame]:
    out: dict[str, pd.DataFrame] = {}
    for z in ("SE3", "SE4"):
        p = config.SPOT_DAILY_GLOB / f"daily_results_{z}.csv"
        if p.is_file():
            df = pd.read_csv(p, parse_dates=["date"])
            out[z] = df
    return out


def _merge_daily_total(
    act_afrr: pd.DataFrame,
    act_mfrr: pd.DataFrame,
    cap_afrr: pd.DataFrame,
    cap_mfrr: pd.DataFrame,
    cap_fcr: pd.DataFrame,
    zone_label: str,
) -> pd.DataFrame:
    """Outer-merge on ``date``; missing components treated as zero revenue."""

    def _norm(d: pd.DataFrame, col: str) -> pd.DataFrame:
        if d is None or d.empty:
            return pd.DataFrame(columns=["date", col])
        x = d[["date", "balancing_profit_eur"]].copy()
        x = x.rename(columns={"balancing_profit_eur": col})
        return x

    def _norm_cap(d: pd.DataFrame, col: str) -> pd.DataFrame:
        if d is None or d.empty:
            return pd.DataFrame(columns=["date", col])
        return d[["date", "capacity_revenue_eur"]].copy().rename(columns={"capacity_revenue_eur": col})

    parts = [
        _norm(act_afrr, "activation_afrr_eur"),
        _norm(act_mfrr, "activation_mfrr_eur"),
        _norm_cap(cap_afrr, "capacity_afrr_eur"),
        _norm_cap(cap_mfrr, "capacity_mfrr_eur"),
        _norm_cap(cap_fcr, "capacity_fcr_eur"),
    ]
    non_empty = [p for p in parts if not p.empty]
    if not non_empty:
        return pd.DataFrame(
            columns=[
                "date",
                "zone",
                "activation_afrr_eur",
                "activation_mfrr_eur",
                "capacity_afrr_eur",
                "capacity_mfrr_eur",
                "capacity_fcr_eur",
                "balancing_profit_eur",
            ]
        )
    m = non_empty[0]
    for p in non_empty[1:]:
        m = m.merge(p, on="date", how="outer")
    m["zone"] = zone_label
    for c in (
        "activation_afrr_eur",
        "activation_mfrr_eur",
        "capacity_afrr_eur",
        "capacity_mfrr_eur",
        "capacity_fcr_eur",
    ):
        if c not in m.columns:
            m[c] = 0.0
        m[c] = m[c].fillna(0.0).astype(float)
    m["balancing_profit_eur"] = (
        m["activation_afrr_eur"]
        + m["activation_mfrr_eur"]
        + m["capacity_afrr_eur"]
        + m["capacity_mfrr_eur"]
        + m["capacity_fcr_eur"]
    )
    m["date"] = pd.to_datetime(m["date"])
    m = m.sort_values("date").reset_index(drop=True)
    return m


def _run_figures_only(log: logging.Logger) -> None:
    """Regenerate Section 4.2 figures from cached Parquet/CSV (no fetch, no optimisation)."""
    daily_by_zone: dict[str, pd.DataFrame] = {}

    for label in config.BIDDING_ZONES:
        pq_ha = config.DATA_DIR / f"balancing_hourly_afrr_{label}.parquet"
        pq_na = config.DATA_DIR / f"balancing_native_afrr_{label}.parquet"
        daily_path = config.DATA_DIR / f"daily_balancing_{label}.csv"
        if not pq_ha.is_file():
            log.error("Missing %s — run full pipeline once.", pq_ha)
            sys.exit(1)
        if not daily_path.is_file():
            log.error("Missing %s — run full pipeline once.", daily_path)
            sys.exit(1)
        hourly_afrr = pd.read_parquet(pq_ha)
        native_afrr = pd.read_parquet(pq_na) if pq_na.is_file() else pd.DataFrame()
        daily_by_zone[label] = pd.read_csv(daily_path, parse_dates=["date"])
        daily_by_zone[label]["date"] = pd.to_datetime(daily_by_zone[label]["date"], utc=True)

        if len(hourly_afrr):
            both_ok = hourly_afrr["price_up"].notna() & hourly_afrr["price_down"].notna()
            avail = (
                f"aFRR hours with both p_up and p_down: {100.0 * both_ok.mean():.1f}% "
                f"({int(both_ok.sum())} / {len(hourly_afrr)})."
            )
        else:
            avail = "No hourly aFRR data."
        plot_balancing_price_overview(
            hourly_afrr,
            native_afrr,
            label,
            avail,
            config.FIG_DIR / config.FIG_NAMES["fig4_6"],
        )

    h_path = config.DATA_DIR / "hourly_balancing_schedules.parquet"
    h_all = pd.read_parquet(h_path) if h_path.is_file() else pd.DataFrame()
    if h_all.empty:
        log.warning("No hourly_balancing_schedules.parquet — Figure 4.7 may be skipped.")

    plot_balancing_seasonality(daily_by_zone, config.FIG_DIR / config.FIG_NAMES["fig4_9"])

    spot_d = _load_spot_daily()
    if spot_d:
        plot_spot_vs_balancing_scatter(
            spot_d, daily_by_zone, config.FIG_DIR / config.FIG_NAMES["fig4_8"]
        )
    else:
        log.warning("Spot daily CSVs not found — skip Figure 4.8")

    z = "SE3"
    pq_ha_se3 = config.DATA_DIR / "balancing_hourly_afrr_SE3.parquet"
    hourly_afrr_se3 = pd.read_parquet(pq_ha_se3) if pq_ha_se3.is_file() else pd.DataFrame()
    if z in daily_by_zone and len(h_all) and not hourly_afrr_se3.empty:
        day = pick_high_vol_day(hourly_afrr_se3, z)
        if day is not None:
            dday = day.date() if hasattr(day, "date") else pd.Timestamp(day).date()
            block = h_all[(h_all["zone"] == z) & (pd.to_datetime(h_all["date"]).dt.date == dday)]
            if len(block) >= 1:
                subp = daily_by_zone[z][pd.to_datetime(daily_by_zone[z]["date"]).dt.date == dday]
                prof = float(subp["balancing_profit_eur"].iloc[0]) if len(subp) else 0.0
                plot_balancing_dispatch_example(
                    block, day, prof, z, config.FIG_DIR / config.FIG_NAMES["fig4_7"]
                )
            else:
                log.warning("Fig 4.7: block empty for picked day")
        else:
            log.warning("Fig 4.7: could not pick day")
    else:
        log.warning("Skipping Fig 4.7 (missing schedules or SE3 data)")

    log.info("Figures-only done. Figures in %s (RESULTS markdown not refreshed)", config.FIG_DIR)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--quick", action="store_true", help="2024 only")
    parser.add_argument("--skip-fetch", action="store_true", help="Use cached parquet if present")
    parser.add_argument(
        "--figures-only",
        action="store_true",
        help="Regenerate figures from cached balancing parquet/CSV (no ENTSO-E, no optimisation).",
    )
    args = parser.parse_args()
    _setup_logging()
    log = logging.getLogger("main_bal")

    if args.figures_only and args.quick:
        log.error("--figures-only cannot be combined with --quick.")
        sys.exit(1)

    if not args.figures_only and not config.ENTSOE_API_KEY:
        log.error("Set environment variable ENTSOE_API_KEY before running.")
        sys.exit(1)

    if args.figures_only:
        _run_figures_only(log)
        return

    start, end = config.START_DATE, config.END_DATE
    if args.quick:
        start, end = "2024-01-01", "2025-01-01"

    report_lines: list[str] = [
        "Balancing + ancillary capacity (virtual stacked streams)",
        "Activation: ENTSO-E A84 — aFRR (A96), mFRR (A97), processType A16.",
        "Capacity: contracted reserve prices — aFRR A51, mFRR A47, FCR A52 (symmetric).",
        f"Capacity counted from {config.CAPACITY_START_AFRR} (aFRR) and {config.CAPACITY_START_MFRR_FCR} (mFRR/FCR).",
        "",
    ]

    daily_by_zone: dict[str, pd.DataFrame] = {}
    hourly_schedules_afrr: list[pd.DataFrame] = []
    failed_all: list[str] = []

    cutoff_afrr = pd.Timestamp(config.CAPACITY_START_AFRR, tz=config.LOCAL_TZ)
    cutoff_mfrr_fcr = pd.Timestamp(config.CAPACITY_START_MFRR_FCR, tz=config.LOCAL_TZ)

    for label, area in config.BIDDING_ZONES.items():
        pq_na = config.DATA_DIR / f"balancing_native_afrr_{label}.parquet"
        pq_ha = config.DATA_DIR / f"balancing_hourly_afrr_{label}.parquet"
        pq_nm = config.DATA_DIR / f"balancing_native_mfrr_{label}.parquet"
        pq_hm = config.DATA_DIR / f"balancing_hourly_mfrr_{label}.parquet"
        pq_caf = config.DATA_DIR / f"capacity_native_afrr_{label}.parquet"
        pq_cmf = config.DATA_DIR / f"capacity_native_mfrr_{label}.parquet"
        pq_cfcr = config.DATA_DIR / f"capacity_native_fcr_{label}.parquet"

        if args.skip_fetch and pq_ha.is_file() and pq_hm.is_file():
            log.info("Loading cached hourly/native %s", label)
            hourly_afrr = pd.read_parquet(pq_ha)
            hourly_mfrr = pd.read_parquet(pq_hm)
            native_afrr = pd.read_parquet(pq_na) if pq_na.is_file() else pd.DataFrame()
            native_mfrr = pd.read_parquet(pq_nm) if pq_nm.is_file() else pd.DataFrame()
            cap_afrr = pd.read_parquet(pq_caf) if pq_caf.is_file() else pd.DataFrame()
            cap_mfrr = pd.read_parquet(pq_cmf) if pq_cmf.is_file() else pd.DataFrame()
            cap_fcr = pd.read_parquet(pq_cfcr) if pq_cfcr.is_file() else pd.DataFrame()
        else:
            raw_a = fetch_balancing_wide_year_chunks(config.ENTSOE_API_KEY, area, start, end)
            raw_m = fetch_mfrr_balancing_wide_year_chunks(config.ENTSOE_API_KEY, area, start, end)
            native_afrr, hourly_afrr, meta_a = full_balancing_preprocessing(raw_a, f"{label}_aFRR")
            native_mfrr, hourly_mfrr, meta_m = full_balancing_preprocessing(raw_m, f"{label}_mFRR")
            report_lines.append(f"{label} aFRR: native median timestep {meta_a.get('native_freq_median')}")
            report_lines.append(f"{label} mFRR: native median timestep {meta_m.get('native_freq_median')}")

            cap_a0 = max(start, config.CAPACITY_START_AFRR)
            cap_m0 = max(start, config.CAPACITY_START_MFRR_FCR)
            raw_caf = (
                fetch_capacity_wide_year_chunks(
                    config.ENTSOE_API_KEY, area, config.CAPACITY_PROCESS_AFRR, cap_a0, end
                )
                if cap_a0 < end
                else pd.DataFrame()
            )
            raw_cmf = (
                fetch_capacity_wide_year_chunks(
                    config.ENTSOE_API_KEY, area, config.CAPACITY_PROCESS_MFRR, cap_m0, end
                )
                if cap_m0 < end
                else pd.DataFrame()
            )
            raw_cfcr = (
                fetch_capacity_wide_year_chunks(
                    config.ENTSOE_API_KEY, area, config.CAPACITY_PROCESS_FCR, cap_m0, end
                )
                if cap_m0 < end
                else pd.DataFrame()
            )
            cap_afrr, _ = full_capacity_preprocessing(raw_caf, f"{label}_cap_aFRR")
            cap_mfrr, _ = full_capacity_preprocessing(raw_cmf, f"{label}_cap_mFRR")
            cap_fcr, _ = full_capacity_preprocessing(raw_cfcr, f"{label}_cap_FCR")

            hourly_afrr.to_parquet(pq_ha)
            hourly_mfrr.to_parquet(pq_hm)
            if not native_afrr.empty:
                native_afrr.to_parquet(pq_na)
            if not native_mfrr.empty:
                native_mfrr.to_parquet(pq_nm)
            if not cap_afrr.empty:
                cap_afrr.to_parquet(pq_caf)
            if not cap_mfrr.empty:
                cap_mfrr.to_parquet(pq_cmf)
            if not cap_fcr.empty:
                cap_fcr.to_parquet(pq_cfcr)
            log.info("Saved balancing/capacity parquet for %s", label)

        report_lines.extend(validate_balancing_data(hourly_afrr, f"{label} (aFRR hourly)"))
        report_lines.extend(validate_balancing_data(hourly_mfrr, f"{label} (mFRR hourly)"))

        daily_afrr, failed_a, h_afrr = run_daily_balancing_optimization(
            native_afrr,
            battery_params=config.BATTERY_PARAMS,
            rolling_soc=True,
            zone_label=label,
            store_hourly=True,
            price_cols=("price_up", "price_down"),
        )
        daily_mfrr, failed_m, _h_m = run_daily_balancing_optimization(
            native_mfrr,
            battery_params=config.BATTERY_PARAMS,
            rolling_soc=True,
            zone_label=label,
            store_hourly=False,
            price_cols=("price_up", "price_down"),
        )
        failed_all.extend([f"{label} aFRR: {x}" for x in failed_a])
        failed_all.extend([f"{label} mFRR: {x}" for x in failed_m])

        dcap_a = build_daily_capacity_revenue(
            cap_afrr, config.BATTERY_PARAMS["P_max"], cutoff_afrr, symmetric=False
        )
        dcap_m = build_daily_capacity_revenue(
            cap_mfrr, config.BATTERY_PARAMS["P_max"], cutoff_mfrr_fcr, symmetric=False
        )
        dcap_f = build_daily_capacity_revenue(
            cap_fcr, config.BATTERY_PARAMS["P_max"], cutoff_mfrr_fcr, symmetric=True
        )

        daily = _merge_daily_total(daily_afrr, daily_mfrr, dcap_a, dcap_m, dcap_f, label)
        daily_by_zone[label] = daily

        if h_afrr is not None and len(h_afrr):
            h_afrr = h_afrr.copy()
            h_afrr["stream"] = "aFRR_activation"
            hourly_schedules_afrr.append(h_afrr)

        log.info(
            "%s: merged %s days (aFRR act %s, mFRR act %s)",
            label,
            len(daily),
            len(daily_afrr),
            len(daily_mfrr),
        )

        if len(hourly_afrr):
            both_ok = hourly_afrr["price_up"].notna() & hourly_afrr["price_down"].notna()
            avail = (
                f"aFRR hours with both p_up and p_down: {100.0 * both_ok.mean():.1f}% "
                f"({int(both_ok.sum())} / {len(hourly_afrr)})."
            )
        else:
            avail = "No hourly aFRR data."
        plot_balancing_price_overview(
            hourly_afrr,
            native_afrr,
            label,
            avail,
            config.FIG_DIR / config.FIG_NAMES["fig4_6"],
        )

    h_all = (
        pd.concat(hourly_schedules_afrr, ignore_index=True) if hourly_schedules_afrr else pd.DataFrame()
    )
    if len(h_all):
        h_all.to_parquet(config.DATA_DIR / "hourly_balancing_schedules.parquet", index=False)

    for label, df in daily_by_zone.items():
        df.to_csv(config.DATA_DIR / f"daily_balancing_{label}.csv", index=False)

    (config.LOG_DIR / "failed_balancing_days.txt").write_text("\n".join(failed_all), encoding="utf-8")

    summary, annual = compute_balancing_summary(daily_by_zone)
    save_table_tex_csv(summary, annual, config.DATA_DIR)

    plot_balancing_seasonality(daily_by_zone, config.FIG_DIR / config.FIG_NAMES["fig4_9"])

    spot_d = _load_spot_daily()
    if spot_d:
        plot_spot_vs_balancing_scatter(
            spot_d, daily_by_zone, config.FIG_DIR / config.FIG_NAMES["fig4_8"]
        )
    else:
        log.warning("Spot daily CSVs not found — skip Figure 4.8")

    z = "SE3"
    pq_ha_se3 = config.DATA_DIR / "balancing_hourly_afrr_SE3.parquet"
    hourly_afrr_se3 = pd.read_parquet(pq_ha_se3) if pq_ha_se3.is_file() else pd.DataFrame()
    if z in daily_by_zone and len(h_all) and not hourly_afrr_se3.empty:
        day = pick_high_vol_day(hourly_afrr_se3, z)
        if day is not None:
            dday = day.date() if hasattr(day, "date") else pd.Timestamp(day).date()
            block = h_all[(h_all["zone"] == z) & (pd.to_datetime(h_all["date"]).dt.date == dday)]
            if len(block) >= 1:
                subp = daily_by_zone[z][pd.to_datetime(daily_by_zone[z]["date"]).dt.date == dday]
                prof = float(subp["balancing_profit_eur"].iloc[0]) if len(subp) else 0.0
                plot_balancing_dispatch_example(
                    block, day, prof, z, config.FIG_DIR / config.FIG_NAMES["fig4_7"]
                )
            else:
                log.warning("Fig 4.7: block empty for picked day")
        else:
            log.warning("Fig 4.7: could not pick day")
    else:
        log.warning("Skipping Fig 4.7 (missing schedules or SE3 data)")

    report_lines.append("\nFailed / skipped optimisation days logged to logs/failed_balancing_days.txt")
    (config.LOG_DIR / "balancing_data_quality.txt").write_text(
        "\n".join(report_lines), encoding="utf-8"
    )

    md_path = config.ROOT / "RESULTS_SECTION_4_2.md"
    lines = [
        "# Section 4.2 — Balancing + capacity (draft notes)",
        "",
        "Stacked virtual streams: aFRR activation, mFRR activation, aFRR/mFRR/FCR capacity (analytical).",
        "Activation LPs at native ENTSO-E resolution; capacity revenue = "
        r"$P_{\max}\sum \max(0,p)\Delta t$ per direction (symmetric for FCR).",
        "",
        "```",
        summary.to_string(),
        "```",
        "",
        "```",
        annual.to_string(),
        "```",
        "",
    ]
    md_path.write_text("\n".join(lines), encoding="utf-8")
    log.info("Done. Figures in %s", config.FIG_DIR)


if __name__ == "__main__":
    main()
