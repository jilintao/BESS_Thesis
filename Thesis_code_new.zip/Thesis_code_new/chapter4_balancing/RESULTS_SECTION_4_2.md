# Section 4.2 — Balancing + capacity (draft notes)

Stacked virtual streams: aFRR activation, mFRR activation, aFRR/mFRR/FCR capacity (analytical).
Activation LPs at native ENTSO-E resolution; capacity revenue = $P_{\max}\sum \max(0,p)\Delta t$ per direction (symmetric for FCR).

```
                                   SE3           SE4      Combined
Mean Daily Profit (€)     5.405927e+04  6.227007e+04  1.163293e+05
Std Daily Profit (€)      5.422313e+04  6.519347e+04  1.162408e+05
Median Daily Profit (€)   4.124468e+04  4.500615e+04  8.718391e+04
Min Daily Profit (€)      0.000000e+00  0.000000e+00  0.000000e+00
Max Daily Profit (€)      3.395096e+05  6.409010e+05  7.445056e+05
Total 6-year Revenue (€)  1.185520e+08  1.365583e+08  2.551103e+08
```

```
               SE3           SE4      Combined
Year                                          
2020  1.511957e+06  2.411604e+06  3.923561e+06
2021  3.349207e+06  5.170511e+06  8.519719e+06
2022  3.420091e+07  3.563157e+07  6.983249e+07
2023  1.637601e+07  1.765055e+07  3.402656e+07
2024  2.831582e+07  3.654155e+07  6.485736e+07
2025  3.479711e+07  3.915119e+07  7.394829e+07
2026  9.759991e+02  1.297459e+03  2.273458e+03
```
