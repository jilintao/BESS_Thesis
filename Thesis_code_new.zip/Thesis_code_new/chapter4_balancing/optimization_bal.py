"""
Daily deterministic balancing-market LP (PuLP + CBC).

Native API resolution (typically 1 h or 15 min) with uniform timestep per calendar day.
Virtual balancing-only asset; aFRR and mFRR activation streams are solved separately and
summed in ``main_bal`` together with analytical capacity revenues.
"""
from __future__ import annotations

import logging
from typing import Any, Optional

import numpy as np
import pandas as pd
import pulp

import config

logger = logging.getLogger(__name__)


def solve_daily_balancing(
    price_up: np.ndarray,
    price_down: np.ndarray,
    soc_init: float,
    bp: dict[str, float],
    dt_hours: float,
) -> Optional[dict[str, Any]]:
    T = len(price_up)
    if T < 1 or len(price_down) != T or dt_hours <= 0:
        return None
    if np.any(np.isnan(price_up)) or np.any(np.isnan(price_down)):
        return None

    E_max = bp["E_max"]
    P_max = bp["P_max"]
    eta = bp["eta"]
    soc_min = bp["SOC_min"]
    soc_max = bp["SOC_max"]
    c_deg = bp["c_deg"]
    c_max = bp["C_max"]
    cycle_cap = 2.0 * c_max * E_max

    prob = pulp.LpProblem("BalancingArbitrage", pulp.LpMaximize)

    charge = [
        pulp.LpVariable(f"ch_{t}", lowBound=0, upBound=P_max, cat=pulp.LpContinuous)
        for t in range(T)
    ]
    discharge = [
        pulp.LpVariable(f"dis_{t}", lowBound=0, upBound=P_max, cat=pulp.LpContinuous)
        for t in range(T)
    ]
    soc = [
        pulp.LpVariable(
            f"soc_{t}", lowBound=soc_min, upBound=soc_max, cat=pulp.LpContinuous
        )
        for t in range(T)
    ]
    z = [pulp.LpVariable(f"z_{t}", cat=pulp.LpBinary) for t in range(T)]

    revenue = pulp.lpSum(
        float(price_up[t]) * discharge[t] * dt_hours
        - float(price_down[t]) * charge[t] * dt_hours
        for t in range(T)
    )
    degradation = c_deg * pulp.lpSum((charge[t] + discharge[t]) * dt_hours for t in range(T))
    prob += revenue - degradation

    for t in range(T):
        if t == 0:
            prob += soc[t] == soc_init + eta * charge[t] * dt_hours - discharge[t] / eta * dt_hours
        else:
            prob += (
                soc[t]
                == soc[t - 1] + eta * charge[t] * dt_hours - discharge[t] / eta * dt_hours
            )
        prob += charge[t] <= P_max * z[t]
        prob += discharge[t] <= P_max * (1 - z[t])

    prob += pulp.lpSum((charge[t] + discharge[t]) * dt_hours for t in range(T)) <= cycle_cap

    prob.solve(pulp.PULP_CBC_CMD(msg=False))
    if prob.status != pulp.LpStatusOptimal:
        return None

    ch_v = np.array([pulp.value(charge[t]) or 0.0 for t in range(T)])
    dis_v = np.array([pulp.value(discharge[t]) or 0.0 for t in range(T)])
    soc_v = np.array([pulp.value(soc[t]) or 0.0 for t in range(T)])
    obj = pulp.value(prob.objective)
    if obj is None:
        return None

    total_ch = float((ch_v * dt_hours).sum())
    total_dis = float((dis_v * dt_hours).sum())
    return {
        "balancing_profit_eur": float(obj),
        "total_down_charged_mwh": total_ch,
        "total_up_discharged_mwh": total_dis,
        "avg_soc": float(soc_v.mean()),
        "num_cycles": (total_ch + total_dis) / (2.0 * E_max),
        "charge_mw": ch_v,
        "discharge_mw": dis_v,
        "soc_mwh": soc_v,
        "soc_end_mwh": float(soc_v[-1]),
    }


def run_daily_balancing_optimization(
    df_native: pd.DataFrame,
    battery_params: Optional[dict[str, float]] = None,
    rolling_soc: bool = True,
    zone_label: str = "SE3",
    store_hourly: bool = False,
    price_cols: tuple[str, str] = ("price_up", "price_down"),
) -> tuple[pd.DataFrame, list[str], Optional[pd.DataFrame]]:
    """
    One LP per calendar day at native row spacing (uniform ``dt_hours`` within each day).

    Parameters
    ----------
    df_native :
        Local-time index; must contain ``price_cols`` numeric columns.
    """
    bp = battery_params or config.BATTERY_PARAMS
    col_u, col_d = price_cols
    s = df_native.copy()
    if s.index.tz is None:
        s.index = s.index.tz_localize(
            config.LOCAL_TZ, ambiguous="infer", nonexistent="shift_forward"
        )
    else:
        s.index = s.index.tz_convert(config.LOCAL_TZ)

    soc_next = float(bp["SOC_0"])
    rows: list[dict[str, Any]] = []
    failed: list[str] = []
    hourly_records: list[dict[str, Any]] = []

    for day, block in s.groupby(s.index.normalize()):
        block = block.sort_index()
        if len(block) < 1:
            failed.append(f"{day.date()} (empty)")
            continue
        if block[[col_u, col_d]].isna().any().any():
            failed.append(f"{day.date()} (NaN prices)")
            continue
        diffs = pd.Series(block.index).diff().dropna()
        if diffs.empty:
            failed.append(f"{day.date()} (single point)")
            continue
        dt = diffs.median()
        if pd.isna(dt) or dt <= pd.Timedelta(0):
            failed.append(f"{day.date()} (bad timestep)")
            continue
        if (diffs - dt).abs().max() > pd.Timedelta(seconds=90):
            failed.append(f"{day.date()} (non-uniform steps)")
            continue
        dt_hours = float(dt.total_seconds() / 3600.0)
        pu = block[col_u].values.astype(float)
        pd_ = block[col_d].values.astype(float)
        res = solve_daily_balancing(pu, pd_, soc_next, bp, dt_hours)
        if res is None:
            failed.append(f"{day.date()} (infeasible)")
            continue
        rows.append(
            {
                "date": pd.Timestamp(day).normalize(),
                "zone": zone_label,
                "balancing_profit_eur": res["balancing_profit_eur"],
                "total_down_charged_mwh": res["total_down_charged_mwh"],
                "total_up_discharged_mwh": res["total_up_discharged_mwh"],
                "avg_soc": res["avg_soc"],
                "num_cycles": res["num_cycles"],
                "soc_end_mwh": res["soc_end_mwh"],
                "n_intervals": len(block),
                "dt_hours": dt_hours,
            }
        )
        if store_hourly:
            for t, ts in enumerate(block.index):
                hourly_records.append(
                    {
                        "timestamp": ts,
                        "date": pd.Timestamp(day).normalize(),
                        "zone": zone_label,
                        "interval": t,
                        "price_up": float(pu[t]),
                        "price_down": float(pd_[t]),
                        "price_net": float(pu[t] - pd_[t]),
                        "charge_mw": float(res["charge_mw"][t]),
                        "discharge_mw": float(res["discharge_mw"][t]),
                        "soc_mwh": float(res["soc_mwh"][t]),
                    }
                )
        if rolling_soc:
            soc_next = res["soc_end_mwh"]
        else:
            soc_next = float(bp["SOC_0"])

    df_out = pd.DataFrame(rows)
    if not df_out.empty:
        df_out["date"] = pd.to_datetime(df_out["date"])
    hdf = pd.DataFrame.from_records(hourly_records) if hourly_records else None
    return df_out, failed, hdf


def daily_capacity_revenue_eur_block(block: pd.DataFrame, P_max: float, *, symmetric: bool) -> float:
    """
    Analytical upper bound for one delivery day: hold ``P_max`` MW whenever the
    capacity price is positive (independent up/down each to ``P_max``).

    ``symmetric`` True → only ``price_cap_symmetric`` contributes.
    """
    if block.empty or P_max <= 0:
        return 0.0
    b = block.sort_index()
    diffs = pd.Series(b.index).diff().dropna()
    if diffs.empty:
        dt_hours = 1.0
    else:
        med = diffs.median()
        if pd.isna(med) or med <= pd.Timedelta(0):
            return 0.0
        dt_hours = float(med.total_seconds() / 3600.0)
    if dt_hours <= 0:
        return 0.0
    if symmetric:
        if "price_cap_symmetric" not in b.columns:
            return 0.0
        p = b["price_cap_symmetric"].astype(float).fillna(0.0)
        return float(P_max * np.maximum(0.0, p.values).sum() * dt_hours)
    rev = 0.0
    for c in ("price_cap_up", "price_cap_down"):
        if c in b.columns:
            p = b[c].astype(float).fillna(0.0)
            rev += float(P_max * np.maximum(0.0, p.values).sum() * dt_hours)
    return rev


def build_daily_capacity_revenue(
    df_cap: pd.DataFrame,
    P_max: float,
    start_cutoff_local: pd.Timestamp,
    *,
    symmetric: bool,
) -> pd.DataFrame:
    """One row per calendar day (local index) on/after ``start_cutoff_local``."""
    if df_cap.empty:
        return pd.DataFrame(columns=["date", "capacity_revenue_eur"])
    s = df_cap.sort_index()
    s = s[s.index >= start_cutoff_local]
    rows: list[dict[str, Any]] = []
    for day, block in s.groupby(s.index.normalize()):
        rev = daily_capacity_revenue_eur_block(block, P_max, symmetric=symmetric)
        rows.append({"date": pd.Timestamp(day).normalize(), "capacity_revenue_eur": rev})
    return pd.DataFrame(rows)
