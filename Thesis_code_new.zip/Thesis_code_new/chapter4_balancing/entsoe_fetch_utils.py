"""
ENTSO-E fetch helpers: HTTP timeout on the client, short retries, and bisection of the
time window on gateway / timeout / pagination errors so a stuck large request is split
instead of blocking for many minutes.
"""
from __future__ import annotations

import logging
import time
from typing import Callable, TypeVar

import pandas as pd
import requests
from entsoe import EntsoePandasClient
from entsoe.exceptions import PaginationError

import config

logger = logging.getLogger(__name__)

T = TypeVar("T")


def make_client(api_key: str) -> EntsoePandasClient:
    """Pandas client with bounded HTTP wait; fewer built-in retries (we bisect + retry locally)."""
    timeout = getattr(config, "API_HTTP_TIMEOUT", 120)
    return EntsoePandasClient(
        api_key=api_key,
        timeout=int(timeout),
        retry_count=2,
        retry_delay=5,
    )


def is_splittable_error(exc: BaseException) -> bool:
    """Errors where asking for a shorter period may succeed."""
    if isinstance(exc, (requests.Timeout, requests.ConnectionError)):
        return True
    if isinstance(exc, PaginationError):
        return True
    if isinstance(exc, requests.HTTPError) and exc.response is not None:
        return exc.response.status_code in (500, 502, 503, 504)
    if isinstance(exc, requests.RequestException) and not isinstance(exc, requests.HTTPError):
        return True
    return False


def retry_call(
    fn: Callable[[], T],
    max_attempts: int,
    base_delay: float = 2.0,
    backoff: float = 1.65,
) -> T:
    last_err: BaseException | None = None
    delay = base_delay
    for attempt in range(1, max_attempts + 1):
        try:
            return fn()
        except Exception as e:
            last_err = e
            logger.warning("Attempt %s/%s failed: %s", attempt, max_attempts, e)
            if attempt < max_attempts:
                time.sleep(delay)
                delay *= backoff
    assert last_err is not None
    raise last_err


def as_dataframe(x: object) -> pd.DataFrame:
    if x is None:
        return pd.DataFrame()
    if isinstance(x, pd.DataFrame):
        return x
    if isinstance(x, pd.Series):
        return x.to_frame()
    return pd.DataFrame(x)


def fetch_time_range_with_bisect(
    fetch_once: Callable[[pd.Timestamp, pd.Timestamp], object],
    start: pd.Timestamp,
    end: pd.Timestamp,
    *,
    tag: str,
    min_delta: pd.Timedelta | None = None,
) -> pd.DataFrame:
    """
    Try ``fetch_once(start, end)`` with a few retries; on persistent gateway/timeout/pagination
    errors, split the interval in half and recurse until ``min_delta`` is reached.
    """
    mind = min_delta or pd.Timedelta(days=getattr(config, "API_MIN_SPLIT_DAYS", 3))
    max_retry = int(getattr(config, "API_RETRY_SHORT", 4))

    def attempt() -> object:
        return fetch_once(start, end)

    try:
        return as_dataframe(retry_call(attempt, max_attempts=max_retry))
    except Exception as e:
        if (end - start) <= mind:
            logger.error("%s: abandoned window [%s .. %s): %s", tag, start, end, e)
            return pd.DataFrame()
        if not is_splittable_error(e):
            raise
        mid = start + (end - start) / 2
        if mid <= start + pd.Timedelta(hours=1) or mid >= end - pd.Timedelta(hours=1):
            logger.error("%s: cannot bisect [%s .. %s)", tag, start, end)
            return pd.DataFrame()
        logger.warning("%s: bisect [%s .. %s) at %s — %s", tag, start, end, mid, type(e).__name__)
        left = fetch_time_range_with_bisect(fetch_once, start, mid, tag=tag + "/L", min_delta=mind)
        right = fetch_time_range_with_bisect(fetch_once, mid, end, tag=tag + "/R", min_delta=mind)
        if left.empty:
            return right
        if right.empty:
            return left
        out = pd.concat([left, right]).sort_index()
        out = out[~out.index.duplicated(keep="last")]
        return out
