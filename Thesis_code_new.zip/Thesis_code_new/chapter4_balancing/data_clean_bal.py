"""
Preprocessing: timezone, duplicates, outlier capping, short-gap interpolation,
hourly aggregation (arithmetic mean), CPI adjustment, validation.

Arithmetic hourly mean: Document A83 volumes unavailable for volume-weighting (thesis §3.2).
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Optional

import numpy as np
import pandas as pd
import requests

import config

logger = logging.getLogger(__name__)


def fetch_swedish_hicp_monthly() -> pd.Series:
    """Eurostat HICP CP00 Sweden, index 2015=100 (same logic as spot pipeline)."""
    url = "https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/prc_hicp_midx"
    params = {"format": "JSON", "lang": "en", "geo": "SE", "unit": "I15", "coicop": "CP00"}
    try:
        r = requests.get(url, params=params, timeout=120)
        r.raise_for_status()
        js = r.json()
        cat_index = js["dimension"]["time"]["category"]["index"]
        raw_vals = js["value"]
    except Exception as e:
        logger.warning("Eurostat HICP failed (%s); skipping CPI.", e)
        return pd.Series(dtype=float)

    times, vals = [], []
    for period, pos in cat_index.items():
        k = str(pos)
        if k not in raw_vals:
            continue
        times.append(pd.Timestamp(period))
        vals.append(float(raw_vals[k]))
    s = pd.Series(vals, index=pd.DatetimeIndex(times)).sort_index()
    return s[~s.index.duplicated(keep="last")]


def apply_cpi_to_prices(df: pd.DataFrame, price_cols: tuple[str, ...], hicp: pd.Series) -> pd.DataFrame:
    if df.empty or hicp.empty:
        return df
    out = df.copy()
    if out.index.tz is None:
        out.index = out.index.tz_localize(
            config.LOCAL_TZ, ambiguous="infer", nonexistent="shift_forward"
        )
    else:
        out.index = out.index.tz_convert(config.LOCAL_TZ)
    hicp_ym = pd.Series(hicp.values, index=hicp.index.strftime("%Y-%m"))
    ym = out.index.strftime("%Y-%m")
    ref_mask = hicp.index.year == config.CPI_BASE_YEAR
    ref_hicp = float(hicp.loc[ref_mask].mean()) if ref_mask.any() else float(hicp.iloc[-1])
    h = pd.Series(ym.map(hicp_ym), index=out.index).astype(float).ffill().bfill()
    factor = ref_hicp / h
    for c in price_cols:
        if c in out.columns:
            out[c] = out[c] * factor
    return out


def clean_outliers(
    df: pd.DataFrame,
    price_cols: tuple[str, ...] = ("price_up", "price_down"),
    lower: float = config.PRICE_CLIP_LOWER,
    upper: float = config.PRICE_CLIP_UPPER,
) -> tuple[pd.DataFrame, dict[str, int]]:
    """Clip extreme prices; return counts of observations outside bounds (pre-clip)."""
    stats: dict[str, int] = {}
    out = df.copy()
    for col in price_cols:
        if col not in out.columns:
            continue
        s = out[col]
        mask = s.notna() & ((s < lower) | (s > upper))
        stats[col] = int(mask.sum())
        out[col] = s.clip(lower=lower, upper=upper)
    return out, stats


def interpolate_short_gaps(
    df: pd.DataFrame,
    price_cols: tuple[str, ...] = ("price_up", "price_down"),
    max_gap_hours: float = config.MAX_INTERP_GAP_HOURS,
) -> pd.DataFrame:
    """
    Linear interpolation along time index for gaps not exceeding max_gap_hours.
    Inferred timestep from median positive diff; converts max_gap to number of steps.
    """
    if df.empty or len(df) < 2:
        return df
    out = df.copy()
    dt = pd.Series(out.index).diff().median()
    if pd.isna(dt) or dt <= pd.Timedelta(0):
        return out
    max_steps = max(1, int(np.ceil(max_gap_hours * pd.Timedelta(hours=1) / dt)))

    for col in price_cols:
        if col not in out.columns:
            continue
        out[col] = out[col].interpolate(
            method="time",
            limit=max_steps,
            limit_direction="both",
        )
    return out


def ensure_local_tz(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    if out.index.tz is None:
        out.index = out.index.tz_localize("UTC", ambiguous="infer")
    out.index = out.index.tz_convert(config.LOCAL_TZ)
    out = out.sort_index()
    out = out[~out.index.duplicated(keep="first")]
    return out


def aggregate_to_hourly(df: pd.DataFrame) -> pd.DataFrame:
    """Arithmetic mean over each clock hour (4×15min or 1×1h)."""
    if df.empty:
        return df
    h = df.resample("1h").mean(numeric_only=True)
    h["price_net"] = h["price_up"] - h["price_down"]
    return h


def full_balancing_preprocessing(
    df_wide: pd.DataFrame,
    zone_label: str,
    apply_cpi: bool = config.APPLY_CPI,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    """
    Returns
    -------
    df_native : best-effort native resolution (before hourly) for volatility stats
    df_hourly : hourly price_up, price_down, price_net
    meta : quality metrics and flags
    """
    meta: dict[str, Any] = {"zone": zone_label, "capped_counts": {}, "native_freq_median": None}

    if df_wide.empty:
        return pd.DataFrame(), pd.DataFrame(), meta

    df = ensure_local_tz(df_wide)
    if len(df.index) >= 2:
        meta["native_freq_median"] = str(pd.Series(df.index).diff().median())

    df, cap_stats = clean_outliers(df)
    meta["capped_counts"] = cap_stats

    df = interpolate_short_gaps(df)

    df_native = df.copy()
    df_native["price_net"] = df_native["price_up"] - df_native["price_down"]

    df_h = aggregate_to_hourly(df)

    if apply_cpi:
        hicp = fetch_swedish_hicp_monthly()
        if not hicp.empty:
            df_h = apply_cpi_to_prices(df_h, ("price_up", "price_down"), hicp)
            df_h["price_net"] = df_h["price_up"] - df_h["price_down"]
            df_native = apply_cpi_to_prices(df_native, ("price_up", "price_down"), hicp)
            df_native["price_net"] = df_native["price_up"] - df_native["price_down"]

    return df_native, df_h, meta


def normalize_capacity_frame(df: pd.DataFrame) -> pd.DataFrame:
    """Rename ENTSO-E contracted-reserve columns to internal names."""
    out = df.copy()
    ren: dict[str, str] = {}
    if "Up" in out.columns:
        ren["Up"] = "price_cap_up"
    if "Down" in out.columns:
        ren["Down"] = "price_cap_down"
    if "Symmetric" in out.columns:
        ren["Symmetric"] = "price_cap_symmetric"
    return out.rename(columns=ren)


def full_capacity_preprocessing(
    df_wide: pd.DataFrame,
    zone_label: str,
    apply_cpi: bool = config.APPLY_CPI,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """
    Timezone, clipping, short-gap interpolation, optional CPI — native resolution kept.
    """
    meta: dict[str, Any] = {"zone": zone_label, "capped_counts": {}}
    if df_wide.empty:
        return pd.DataFrame(), meta

    df = normalize_capacity_frame(df_wide)
    df = ensure_local_tz(df)
    price_cols = tuple(
        c
        for c in ("price_cap_up", "price_cap_down", "price_cap_symmetric")
        if c in df.columns
    )
    df, cap_stats = clean_outliers(df, price_cols=price_cols)
    meta["capped_counts"] = cap_stats
    df = interpolate_short_gaps(df, price_cols=price_cols)

    if apply_cpi:
        hicp = fetch_swedish_hicp_monthly()
        if not hicp.empty:
            df = apply_cpi_to_prices(df, price_cols, hicp)

    return df, meta


def validate_balancing_data(
    df_hourly: pd.DataFrame,
    zone_label: str,
) -> list[str]:
    """Return log lines for quality report."""
    lines: list[str] = []
    if df_hourly.empty:
        lines.append(f"{zone_label}: EMPTY hourly frame")
        return lines
    n = len(df_hourly)
    mu = df_hourly["price_up"].isna().sum()
    md = df_hourly["price_down"].isna().sum()
    lines.append(f"\n{zone_label} — hourly balancing data quality")
    lines.append(f"  Total hours: {n}")
    lines.append(f"  Missing Up:   {mu} ({100.0 * mu / n:.2f}%)")
    lines.append(f"  Missing Down: {md} ({100.0 * md / n:.2f}%)")
    pu = df_hourly["price_up"].dropna()
    pd_ = df_hourly["price_down"].dropna()
    if len(pu):
        lines.append(f"  Up range (EUR/MWh):   [{pu.min():.2f}, {pu.max():.2f}]")
    if len(pd_):
        lines.append(f"  Down range (EUR/MWh): [{pd_.min():.2f}, {pd_.max():.2f}]")
    if mu / n > config.MISSING_DIRECTION_WARN_FRAC or md / n > config.MISSING_DIRECTION_WARN_FRAC:
        lines.append(
            f"  *** WARNING: missing share > {100*config.MISSING_DIRECTION_WARN_FRAC:.0f}% in at least one direction ***"
        )
    return lines


def save_hourly(df: pd.DataFrame, path: Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.suffix.lower() == ".parquet":
        df.to_parquet(path)
    else:
        df.to_csv(path)


def load_hourly(path: Path) -> pd.DataFrame:
    path = Path(path)
    if path.suffix.lower() == ".parquet":
        return pd.read_parquet(path)
    return pd.read_csv(path, index_col=0, parse_dates=True)
