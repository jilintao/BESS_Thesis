"""
Chapter 4.1 pipeline: fetch DA prices → daily LP arbitrage → tables & figures.

Perfect foresight per calendar delivery day at native DA resolution yields an upper bound on spot arbitrage revenue.
"""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

import pandas as pd

import config
from data_fetch import fetch_spot_prices, load_price_bundle, save_price_bundle
from optimization import run_daily_optimization
from results_analysis import compute_summary_statistics, save_table_csv_tex
from visualization import (
    pick_representative_day,
    plot_cumulative_revenue,
    plot_dispatch_heatmap,
    plot_example_dispatch,
    plot_revenue_distribution_seasonality,
    plot_spot_prices_overview,
)


def _setup_logging(log_dir: Path) -> None:
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "pipeline.log"
    fh = logging.FileHandler(log_file, encoding="utf-8")
    sh = logging.StreamHandler(sys.stdout)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[sh, fh],
    )


def _write_captions(path: Path, captions: dict[str, str]) -> None:
    lines = ["# Figure captions (Chapter 4.1)\n"]
    for k, v in captions.items():
        lines.append(f"## {k}\n\n{v}\n")
    path.write_text("\n".join(lines), encoding="utf-8")


def _write_results_markdown(
    path: Path,
    summary: pd.DataFrame,
    annual: pd.DataFrame,
    n_failed: int,
) -> None:
    """Brief findings for drafting Section 4.1."""
    lines = [
        "# Section 4.1 — Spot market arbitrage (draft notes)",
        "",
        "Prices: ENTSO-E day-ahead, Swedish zones SE3/SE4, localized to "
        f"`{config.LOCAL_TZ}` at **native DA resolution** (1 h before 2025-10-01, 15 min thereafter), "
        f"short gaps (≤{config.MAX_INTERP_GAP_HOURS} h) interpolated, "
        f"nominal EUR deflated to {config.CPI_BASE_YEAR} EUR using Eurostat Swedish HICP (CP00).",
        "",
        "Optimization: deterministic linear program (PuLP/CBC) per calendar delivery day at **native** "
        "day-ahead resolution (1 h before 2025-10-01, 15 min thereafter for SE3/SE4), mutual exclusivity "
        "of charge and discharge, rolling end-of-day SOC carried to the next day (starts at 50 MWh on the "
        "first day). **Perfect foresight** within each day implies revenues are an **upper bound** on "
        "realizable spot arbitrage.",
        "",
        "## Key statistics (see `data/table4_1_summary_summary.csv`)",
        "",
        "```",
        summary.to_string(),
        "```",
        "",
        "## Annual revenue (€)",
        "",
        "```",
        annual.to_string(),
        "```",
        "",
        f"Days skipped or failed (logged): **{n_failed}** (non-uniform timesteps, missing prices, DST-length days, or solver issues).",
        "",
        "## Interpretation prompts",
        "",
        "- Compare SE3 vs SE4 mean daily profit and volatility.",
        "- Link 2022–2023 annual totals to the crisis period in Figure 4.1.",
        "- Discuss degradation cost assumption (€/MWh throughput) sensitivity in discussion chapter.",
        "",
    ]
    path.write_text("\n".join(lines), encoding="utf-8")


def _run_figures_only(log: logging.Logger) -> None:
    """Regenerate Section 4.1 figures from existing Parquet/CSV (no fetch, no LP)."""
    price_path = config.DATA_DIR / "processed_prices.parquet"
    if not price_path.is_file():
        log.error("Missing %s — run full pipeline once.", price_path)
        sys.exit(1)
    prices = load_price_bundle(price_path)

    daily_by_zone: dict[str, pd.DataFrame] = {}
    for z in config.BIDDING_ZONES:
        p = config.DATA_DIR / f"daily_results_{z}.csv"
        if not p.is_file():
            log.error("Missing %s — run full pipeline once.", p)
            sys.exit(1)
        daily_by_zone[z] = pd.read_csv(p, parse_dates=["date"])
        daily_by_zone[z]["date"] = pd.to_datetime(daily_by_zone[z]["date"], utc=True)

    hp = config.DATA_DIR / "hourly_schedules.parquet"
    hourly_df = pd.read_parquet(hp) if hp.is_file() else pd.DataFrame()
    if hourly_df.empty:
        log.warning("No hourly_schedules.parquet — Figures 4.2 and 4.4 will be skipped.")

    captions: dict[str, str] = {}
    captions["Figure 4.1"] = plot_spot_prices_overview(
        prices, config.FIG_DIR / config.FIG_NAMES["fig4_1"]
    )

    fail_path = config.LOG_DIR / "failed_days.txt"
    failed_all = fail_path.read_text(encoding="utf-8").splitlines() if fail_path.is_file() else []

    summary, annual = compute_summary_statistics(daily_by_zone)

    captions["Figure 4.3"] = plot_revenue_distribution_seasonality(
        daily_by_zone, config.FIG_DIR / config.FIG_NAMES["fig4_3"]
    )
    if len(hourly_df):
        captions["Figure 4.4"] = plot_dispatch_heatmap(
            hourly_df, config.FIG_DIR / config.FIG_NAMES["fig4_4"]
        )
    else:
        log.warning("Skipping Figure 4.4 (no hourly schedules).")

    captions["Figure 4.5"] = plot_cumulative_revenue(
        daily_by_zone, config.FIG_DIR / config.FIG_NAMES["fig4_5"]
    )

    z = "SE3"
    if z in daily_by_zone and len(hourly_df):
        day = pick_representative_day(daily_by_zone[z], hourly_df, z)
        if day is not None:
            dday = day.date()
            block = hourly_df[
                (hourly_df["zone"] == z)
                & (pd.to_datetime(hourly_df["date"]).dt.date == dday)
            ].sort_values("interval")
            if len(block) >= 1:
                pr = block["price_eur_mwh"].values.astype(float)
                ch = block["charge_mw"].values.astype(float)
                dis = block["discharge_mw"].values.astype(float)
                soc = block["soc_mwh"].values.astype(float)
                prof_row = daily_by_zone[z][
                    pd.to_datetime(daily_by_zone[z]["date"]).dt.date == dday
                ]
                prof = float(prof_row["arbitrage_profit_eur"].iloc[0]) if len(prof_row) else 0.0
                captions["Figure 4.2"] = plot_example_dispatch(
                    pr, ch, dis, soc, day, prof, config.FIG_DIR / config.FIG_NAMES["fig4_2"], zone=z
                )
            else:
                log.warning("Example day block empty, skipping Fig 4.2")
        else:
            log.warning("Could not pick representative day for Fig 4.2")
    else:
        log.warning("Skipping Fig 4.2 (missing hourly data)")

    _write_captions(config.FIG_DIR / "figure_captions.md", captions)
    _write_results_markdown(
        config.ROOT / "RESULTS_SECTION_4_1.md", summary, annual, len(failed_all)
    )
    log.info("Figures-only done. Figures in %s", config.FIG_DIR)


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    parser = argparse.ArgumentParser(description="Chapter 4.1 spot arbitrage pipeline")
    parser.add_argument(
        "--quick",
        action="store_true",
        help="Use 2024-01-01 .. 2025-01-01 only for faster dry runs",
    )
    parser.add_argument(
        "--skip-fetch",
        action="store_true",
        help="Load cached Parquet from data/processed_prices.parquet if present",
    )
    parser.add_argument(
        "--figures-only",
        action="store_true",
        help="Regenerate figures from existing data/processed_prices.parquet, daily_results_*.csv, "
        "hourly_schedules.parquet (no ENTSO-E fetch, no optimisation).",
    )
    args = parser.parse_args()

    if args.figures_only and args.quick:
        print("ERROR: --figures-only cannot be combined with --quick.", file=sys.stderr)
        sys.exit(1)

    if not args.figures_only and not args.skip_fetch and not config.ENTSOE_API_KEY:
        print("ERROR: Set environment variable ENTSOE_API_KEY before fetching.", file=sys.stderr)
        sys.exit(1)

    _setup_logging(config.LOG_DIR)
    log = logging.getLogger("main")

    if args.figures_only:
        _run_figures_only(log)
        return

    start = "2020-01-01"
    end = "2026-01-01"
    if args.quick:
        start = "2024-01-01"
        end = "2025-01-01"
        log.info("Quick mode: %s .. %s", start, end)

    price_path = config.DATA_DIR / "processed_prices.parquet"
    if args.skip_fetch and price_path.is_file():
        log.info("Loading cached prices from %s", price_path)
        prices = load_price_bundle(price_path)
    else:
        prices = fetch_spot_prices(
            config.ENTSOE_API_KEY,
            config.BIDDING_ZONES,
            start,
            end,
            apply_cpi=True,
        )
        save_price_bundle(prices, price_path)
        log.info("Saved processed prices to %s", price_path)

    captions: dict[str, str] = {}
    captions["Figure 4.1"] = plot_spot_prices_overview(
        prices, config.FIG_DIR / config.FIG_NAMES["fig4_1"]
    )

    daily_by_zone: dict[str, pd.DataFrame] = {}
    hourly_parts: list[pd.DataFrame] = []
    failed_all: list[str] = []

    for label, ser in prices.items():
        ser = ser.copy()
        ser.name = label
        daily, failed, hourly = run_daily_optimization(
            ser,
            battery_params=config.BATTERY_PARAMS,
            rolling_soc=True,
            zone_label=label,
            store_hourly=True,
        )
        daily_by_zone[label] = daily
        failed_all.extend([f"{label}: {x}" for x in failed])
        if hourly is not None and len(hourly):
            hourly_parts.append(hourly)
        log.info("%s: solved %s days, failed %s", label, len(daily), len(failed))

    hourly_df = (
        pd.concat(hourly_parts, ignore_index=True) if hourly_parts else pd.DataFrame()
    )

    for label, df in daily_by_zone.items():
        p = config.DATA_DIR / f"daily_results_{label}.csv"
        df.to_csv(p, index=False)
        log.info("Wrote %s", p)
    if len(hourly_df):
        hp = config.DATA_DIR / "hourly_schedules.parquet"
        hourly_df.to_parquet(hp, index=False)
        log.info("Wrote %s", hp)

    fail_path = config.LOG_DIR / "failed_days.txt"
    fail_path.write_text("\n".join(failed_all), encoding="utf-8")

    summary, annual = compute_summary_statistics(daily_by_zone)
    save_table_csv_tex(summary, annual, config.DATA_DIR)

    captions["Figure 4.3"] = plot_revenue_distribution_seasonality(
        daily_by_zone, config.FIG_DIR / config.FIG_NAMES["fig4_3"]
    )
    captions["Figure 4.4"] = plot_dispatch_heatmap(
        hourly_df, config.FIG_DIR / config.FIG_NAMES["fig4_4"]
    )
    captions["Figure 4.5"] = plot_cumulative_revenue(
        daily_by_zone, config.FIG_DIR / config.FIG_NAMES["fig4_5"]
    )

    # Figure 4.2: example day (SE3)
    z = "SE3"
    if z in daily_by_zone and len(hourly_df):
        day = pick_representative_day(daily_by_zone[z], hourly_df, z)
        if day is not None:
            dday = day.date()
            block = hourly_df[
                (hourly_df["zone"] == z)
                & (pd.to_datetime(hourly_df["date"]).dt.date == dday)
            ].sort_values("interval")
            if len(block) >= 1:
                pr = block["price_eur_mwh"].values.astype(float)
                ch = block["charge_mw"].values.astype(float)
                dis = block["discharge_mw"].values.astype(float)
                soc = block["soc_mwh"].values.astype(float)
                prof_row = daily_by_zone[z][
                    pd.to_datetime(daily_by_zone[z]["date"]).dt.date == dday
                ]
                prof = float(prof_row["arbitrage_profit_eur"].iloc[0]) if len(prof_row) else 0.0
                captions["Figure 4.2"] = plot_example_dispatch(
                    pr, ch, dis, soc, day, prof, config.FIG_DIR / config.FIG_NAMES["fig4_2"], zone=z
                )
            else:
                log.warning("Example day block empty, skipping Fig 4.2")
        else:
            log.warning("Could not pick representative day for Fig 4.2")
    else:
        log.warning("Skipping Fig 4.2 (missing data)")

    _write_captions(config.FIG_DIR / "figure_captions.md", captions)
    _write_results_markdown(
        config.ROOT / "RESULTS_SECTION_4_1.md", summary, annual, len(failed_all)
    )
    log.info("Done. Figures in %s", config.FIG_DIR)


if __name__ == "__main__":
    main()
