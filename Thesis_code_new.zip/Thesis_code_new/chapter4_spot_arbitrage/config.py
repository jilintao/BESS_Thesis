"""
Central configuration: battery parameters, ENTSO-E zones, paths, plotting style.
Prefer ENTSOE_API_KEY in the environment over a hard-coded default.
"""
from __future__ import annotations

import os
from pathlib import Path

# --- Paths (project root = directory containing this file) ---
ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
FIG_DIR = ROOT / "figures"
LOG_DIR = ROOT / "logs"

for d in (DATA_DIR, FIG_DIR, LOG_DIR):
    d.mkdir(parents=True, exist_ok=True)

# --- API ---
# Set ENTSOE_API_KEY in your environment for sharing/public repos.
ENTSOE_API_KEY = os.environ.get("ENTSOE_API_KEY")

# entsoe-py bidding zone codes (underscore form)
BIDDING_ZONES = {
    "SE3": "SE_3",
    "SE4": "SE_4",
}

START_DATE = "2020-01-01"
END_DATE = "2026-01-01"  # exclusive upper bound for ENTSO-E queries

# --- Battery (Section 3.3.1) ---
BATTERY_PARAMS = {
    "E_max": 100.0,  # MWh
    "P_max": 25.0,  # MW
    "eta": 0.90,  # round-trip (applied symmetrically as in thesis)
    "SOC_min": 10.0,  # MWh
    "SOC_max": 100.0,  # MWh
    "SOC_0": 50.0,  # MWh initial SOC (first day / reset)
    "c_deg": 20.0,  # EUR per MWh (charge + discharge energy)
    "C_max": 2.0,  # max full cycles per day (constraint uses 2 * C_max * E_max)
}

# --- Data processing ---
LOCAL_TZ = "Europe/Stockholm"
MAX_INTERP_GAP_HOURS = 2
CPI_BASE_YEAR = 2025  # express all prices in “end-2025 EUR” using monthly index

# --- Thesis figure style ---
COLORS = {
    "SE3": "#2196F3",
    "SE4": "#FF9800",
    "charge": "#2196F3",
    "discharge": "#E53935",
    "soc": "#43A047",
}

FONT_FAMILY = "sans-serif"
FONT_SANS = ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"]
TITLE_FONTSIZE = 14
LABEL_FONTSIZE = 11
TICK_FONTSIZE = 10
FIG_DPI = 300

FIG_NAMES = {
    "fig4_1": "fig4_1_spot_prices_timeseries",
    "fig4_2": "fig4_2_example_dispatch",
    "fig4_3": "fig4_3_revenue_distribution",
    "fig4_4": "fig4_4_dispatch_heatmap",
    "fig4_5": "fig4_5_cumulative_revenue",
}
