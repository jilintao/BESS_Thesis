# Section 4.1 — Spot market arbitrage (draft notes)

Prices: ENTSO-E day-ahead, Swedish zones SE3/SE4, localized to `Europe/Stockholm` at **native DA resolution** (1 h before 2025-10-01, 15 min thereafter), short gaps (≤2 h) interpolated, nominal EUR deflated to 2025 EUR using Eurostat Swedish HICP (CP00).

Optimization: deterministic linear program (PuLP/CBC) per calendar delivery day at **native** day-ahead resolution (1 h before 2025-10-01, 15 min thereafter for SE3/SE4), mutual exclusivity of charge and discharge, rolling end-of-day SOC carried to the next day (starts at 50 MWh on the first day). **Perfect foresight** within each day implies revenues are an **upper bound** on realizable spot arbitrage.

## Key statistics (see `data/table4_1_summary_summary.csv`)

```
                                   SE3           SE4      Combined
Metric                                                            
Mean Daily Profit (€)     2.984751e+03  3.880414e+03  6.865165e+03
Std Daily Profit (€)      6.418020e+03  7.061853e+03  1.281919e+04
Min Daily Profit (€)      0.000000e+00  0.000000e+00  0.000000e+00
Max Daily Profit (€)      6.394028e+04  6.700392e+04  1.278806e+05
Median Daily Profit (€)   3.911644e+01  8.988656e+02  1.598752e+03
Total 6-year Revenue (€)  6.545559e+06  8.509747e+06  1.505531e+07
```

## Annual revenue (€)

```
               SE3           SE4      Combined
Year                                          
2019  6.388460e+02  6.388460e+02  1.277692e+03
2020  1.628997e+05  1.671773e+05  3.300771e+05
2021  9.218743e+05  1.094298e+06  2.016172e+06
2022  3.813168e+06  4.093189e+06  7.906357e+06
2023  5.684750e+05  9.298578e+05  1.498333e+06
2024  3.726635e+05  1.050022e+06  1.422686e+06
2025  7.058391e+05  1.174565e+06  1.880404e+06
```

Days skipped or failed (logged): **0** (non-uniform timesteps, missing prices, DST-length days, or solver issues).

## Interpretation prompts

- Compare SE3 vs SE4 mean daily profit and volatility.
- Link 2022–2023 annual totals to the crisis period in Figure 4.1.
- Discuss degradation cost assumption (€/MWh throughput) sensitivity in discussion chapter.
