"""
Fetch Day-Ahead spot prices from ENTSO-E (entsoe-py), localize to Swedish time,
interpolate short gaps, and deflate to reference-year EUR using Swedish HICP.
"""
from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Callable, Optional

import numpy as np
import pandas as pd
import requests
from entsoe import EntsoePandasClient

import config

logger = logging.getLogger(__name__)

# Fallback annual index (2020 = 1.0) if Eurostat is unavailable
_FALLBACK_YEARLY_INDEX = {
    2020: 1.000,
    2021: 1.025,
    2022: 1.055,
    2023: 1.095,
    2024: 1.125,
    2025: 1.145,
}


def _retry_call(
    fn: Callable,
    max_attempts: int = 8,
    base_delay: float = 3.0,
    backoff: float = 1.8,
) -> object:
    last_err: Optional[Exception] = None
    delay = base_delay
    for attempt in range(1, max_attempts + 1):
        try:
            return fn()
        except Exception as e:
            last_err = e
            logger.warning("Attempt %s/%s failed: %s", attempt, max_attempts, e)
            if attempt < max_attempts:
                time.sleep(delay)
                delay *= backoff
    raise last_err  # type: ignore[misc]


def fetch_swedish_hicp_monthly() -> pd.Series:
    """
    Monthly all-items HICP for Sweden (index 2015=100), Eurostat prc_hicp_midx.
    Index: month-start timestamps (UTC-naive is fine; only Y-M matters).
    """
    url = (
        "https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/"
        "prc_hicp_midx"
    )
    params = {"format": "JSON", "lang": "en", "geo": "SE", "unit": "I15", "coicop": "CP00"}
    try:
        r = requests.get(url, params=params, timeout=120)
        r.raise_for_status()
        js = r.json()
    except Exception as e:
        logger.warning("Eurostat HICP request failed (%s); using yearly fallback.", e)
        return pd.Series(dtype=float)

    try:
        cat_index = js["dimension"]["time"]["category"]["index"]
        raw_vals = js["value"]
    except (KeyError, TypeError) as e:
        logger.warning("Unexpected Eurostat JSON (%s); using yearly fallback.", e)
        return pd.Series(dtype=float)

    times: list[pd.Timestamp] = []
    vals: list[float] = []
    for period, pos in cat_index.items():
        k = str(pos)
        if k not in raw_vals:
            continue
        # period like "2020-01"
        ts = pd.Timestamp(period)
        times.append(ts)
        vals.append(float(raw_vals[k]))
    s = pd.Series(vals, index=pd.DatetimeIndex(times)).sort_index()
    s = s[~s.index.duplicated(keep="last")]
    return s


def _yearly_fallback_series(index: pd.DatetimeIndex) -> pd.Series:
    years = index.year
    mult = np.array([_FALLBACK_YEARLY_INDEX.get(int(y), np.nan) for y in years])
    return pd.Series(mult, index=index)


def apply_cpi_adjustment(
    prices: pd.Series,
    hicp_monthly: pd.Series,
    base_year: int = config.CPI_BASE_YEAR,
) -> pd.Series:
    """
    Real EUR/MWh: multiply nominal prices by HICP_ref / HICP_month(t).
    HICP_ref = mean of monthly indices in `base_year` (Eurostat series).
    """
    if prices.empty:
        return prices
    p = prices.copy()
    if p.index.tz is None:
        p.index = p.index.tz_localize(
            config.LOCAL_TZ, ambiguous="infer", nonexistent="shift_forward"
        )
    else:
        p.index = p.index.tz_convert(config.LOCAL_TZ)

    if hicp_monthly.empty:
        logger.warning("No monthly HICP; applying rough yearly factors.")
        yb = _FALLBACK_YEARLY_INDEX.get(base_year, 1.0)
        return p / _yearly_fallback_series(p.index) * yb

    hicp_ym = pd.Series(hicp_monthly.values, index=hicp_monthly.index.strftime("%Y-%m"))
    ym = p.index.strftime("%Y-%m")
    h = ym.map(hicp_ym)
    h = pd.Series(h.values, index=p.index)
    h = h.astype(float).ffill().bfill()

    ref_mask = hicp_monthly.index.year == base_year
    if not ref_mask.any():
        ref_hicp = float(hicp_monthly.iloc[-1])
    else:
        ref_hicp = float(hicp_monthly.loc[ref_mask].mean())

    return p * (ref_hicp / h)


def localize_and_clean_hourly(
    s: pd.Series,
    max_interp_hours: int = config.MAX_INTERP_GAP_HOURS,
) -> pd.Series:
    """UTC → Europe/Stockholm, dedupe DST, reindex hourly, interpolate short gaps."""
    if s.empty:
        return s
    s = s.sort_index()
    if s.index.tz is None:
        s = s.tz_localize("UTC", ambiguous="infer")
    s = s.tz_convert(config.LOCAL_TZ)
    s = s[~s.index.duplicated(keep="last")]

    full_range = pd.date_range(s.index.min(), s.index.max(), freq="h", tz=config.LOCAL_TZ)
    s = s.reindex(full_range)
    return s.interpolate(method="time", limit=max_interp_hours, limit_direction="both")


def localize_and_clean_spot_native(
    s: pd.Series,
    max_interp_hours: int = config.MAX_INTERP_GAP_HOURS,
) -> pd.Series:
    """
    UTC → Europe/Stockholm, dedupe, align to native ENTSO-E MTU (1 h before Oct 2025,
    15 min from Oct 2025 for Swedish DA), interpolate short gaps in *step count*.
    """
    if s.empty:
        return s
    s = s.sort_index()
    if s.index.tz is None:
        s = s.tz_localize("UTC", ambiguous="infer")
    s = s.tz_convert(config.LOCAL_TZ)
    s = s[~s.index.duplicated(keep="last")]

    split = pd.Timestamp("2025-10-01", tz=config.LOCAL_TZ)
    parts: list[pd.Series] = []
    for freq, mask in (
        ("h", s.index < split),
        ("15min", s.index >= split),
    ):
        seg = s.loc[mask]
        if seg.empty:
            continue
        idx = pd.date_range(seg.index.min(), seg.index.max(), freq=freq, tz=config.LOCAL_TZ)
        seg = seg.reindex(idx)
        max_steps = max(1, int(np.ceil(max_interp_hours / (0.25 if freq == "15min" else 1.0))))
        seg = seg.interpolate(method="time", limit=max_steps, limit_direction="both")
        parts.append(seg)
    if not parts:
        return s
    out = pd.concat(parts).sort_index()
    out = out[~out.index.duplicated(keep="last")]
    return out


def fetch_spot_prices(
    api_key: str,
    country_codes: dict[str, str],
    start_date: str,
    end_date: str,
    apply_cpi: bool = True,
) -> dict[str, pd.Series]:
    """
    Fetch and preprocess Day-Ahead spot prices (EUR/MWh, hourly, local TZ).

    End date is exclusive (pandas / ENTSO-E convention).
    """
    client = EntsoePandasClient(api_key=api_key)
    start = pd.Timestamp(start_date, tz="UTC")
    end = pd.Timestamp(end_date, tz="UTC")
    hicp = fetch_swedish_hicp_monthly() if apply_cpi else pd.Series(dtype=float)

    out: dict[str, pd.Series] = {}
    for label, area in country_codes.items():
        logger.info("Fetching DA prices %s (%s) …", label, area)
        # Yearly chunks reduce load on ENTSO-E and avoid long single calls (fewer 503s).
        parts: list[pd.Series] = []
        chunk_start = start
        while chunk_start < end:
            chunk_end = min(chunk_start + pd.DateOffset(years=1), end)

            def _q(cs=chunk_start, ce=chunk_end):
                return client.query_day_ahead_prices(area, start=cs, end=ce)

            raw = _retry_call(_q)
            if not isinstance(raw, pd.Series):
                raw = pd.Series(raw)
            if len(raw):
                parts.append(raw)
            chunk_start = chunk_end
            time.sleep(0.4)

        raw = pd.concat(parts).sort_index() if parts else pd.Series(dtype=float)
        raw = raw[~raw.index.duplicated(keep="last")]

        clean = localize_and_clean_spot_native(raw)
        if apply_cpi:
            clean = apply_cpi_adjustment(clean, hicp)
        clean.name = f"price_eur_mwh_{label}"
        out[label] = clean
        med = pd.Series(clean.index).diff().median()
        logger.info("%s: %s native points (non-NaN: %s), median step %s", label, len(clean), clean.notna().sum(), med)

    return out


def save_price_bundle(prices: dict[str, pd.Series], path: Path) -> None:
    df = pd.concat(prices.values(), axis=1)
    df.columns = list(prices.keys())
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.suffix.lower() == ".parquet":
        df.to_parquet(path)
    else:
        df.to_csv(path)


def load_price_bundle(path: Path) -> dict[str, pd.Series]:
    path = Path(path)
    if path.suffix.lower() == ".parquet":
        df = pd.read_parquet(path)
    else:
        df = pd.read_csv(path, index_col=0, parse_dates=True)
    if getattr(df.index, "tz", None) is None:
        df.index = df.index.tz_localize(
            config.LOCAL_TZ, ambiguous="infer", nonexistent="shift_forward"
        )
    return {c: df[c] for c in df.columns}
