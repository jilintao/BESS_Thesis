"""
Publication-style figures for Chapter 4.1 (matplotlib).
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

import config


def _apply_style():
    plt.rcParams.update(
        {
            "font.family": config.FONT_FAMILY,
            "font.sans-serif": config.FONT_SANS,
            "font.size": config.TICK_FONTSIZE,
            "axes.titlesize": config.TITLE_FONTSIZE,
            "axes.labelsize": config.LABEL_FONTSIZE,
            "figure.dpi": config.FIG_DPI,
        }
    )


def _clear_figure_titles(fig: plt.Figure) -> None:
    """Remove figure/subplot titles (including defaults from e.g. scipy.stats.probplot)."""
    try:
        fig.suptitle(None)
    except Exception:
        pass
    for ax in fig.get_axes():
        ax.set_title(None)


def _save_both(fig: plt.Figure, base_path: Path) -> None:
    base_path = Path(base_path)
    base_path.parent.mkdir(parents=True, exist_ok=True)
    _clear_figure_titles(fig)
    fig.savefig(f"{base_path}.png", dpi=config.FIG_DPI, bbox_inches="tight")
    fig.savefig(f"{base_path}.pdf", bbox_inches="tight")
    plt.close(fig)


def plot_spot_prices_overview(
    prices: dict[str, pd.Series],
    out_base: Path,
) -> str:
    """
    Figure 4.1: daily mean price (SE3/SE4), shaded crisis window, secondary axis daily std.
    """
    _apply_style()
    fig, ax1 = plt.subplots(figsize=(12, 5))
    ax2 = ax1.twinx()

    daily_stats: dict[str, tuple[pd.Series, pd.Series]] = {}
    for z, s in prices.items():
        s = s.dropna()
        dmean = s.groupby(s.index.normalize()).mean()
        dstd = s.groupby(s.index.normalize()).std()
        daily_stats[z] = (dmean, dstd)
        c = config.COLORS.get(z, "#333333")
        (dmean.plot(ax=ax1, color=c, lw=1.2, label=f"{z} daily mean", alpha=0.9))
        dstd.plot(ax=ax2, color=c, ls="--", lw=0.8, alpha=0.5)

    # High-volatility shading (2022 energy crisis window)
    crisis_start = pd.Timestamp("2021-06-01", tz=config.LOCAL_TZ)
    crisis_end = pd.Timestamp("2022-12-31", tz=config.LOCAL_TZ)
    ax1.axvspan(crisis_start, crisis_end, color="gray", alpha=0.12, label="High-volatility period")

    # Extreme annotations (pool SE3 & SE4)
    all_s = pd.concat(prices.values()).dropna()
    dly = all_s.groupby(all_s.index.normalize())
    daily_min = dly.min().min()
    daily_max = dly.max().max()
    if daily_min < 0:
        ax1.annotate(
            "Negative DA prices",
            xy=(0.02, 0.05),
            xycoords="axes fraction",
            fontsize=9,
            color="#666",
        )
    spike_days = dly.max()
    hi = spike_days[spike_days > 300]
    if len(hi):
        t0 = hi.index[0]
        ax1.axvline(t0, color="red", ls=":", lw=1, alpha=0.7)
        ax1.annotate(
            f">300 €/MWh\n({t0.date()})",
            xy=(mdates.date2num(t0), ax1.get_ylim()[1] * 0.85),
            fontsize=8,
            color="red",
        )

    ax1.set_ylabel("Daily mean DA price (€/MWh)")
    ax2.set_ylabel("Daily stdev (€/MWh)")
    ax1.set_xlabel("Date")
    h1, l1 = ax1.get_legend_handles_labels()
    ax1.legend(h1, l1, loc="upper left", framealpha=0.9)
    ax1.xaxis.set_major_locator(mdates.YearLocator())
    ax1.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
    fig.autofmt_xdate()
    _save_both(fig, out_base)
    return (
        "Caption: Day-ahead spot prices (hourly, inflation-adjusted to 2025 EUR) averaged to daily "
        "means for SE3 (blue) and SE4 (orange); dashed lines on the secondary axis show daily "
        "standard deviation. Shaded band highlights elevated volatility during the 2021–2022 period."
    )


def plot_example_dispatch(
    prices: np.ndarray,
    charge_mw: np.ndarray,
    discharge_mw: np.ndarray,
    soc_mwh: np.ndarray,
    day: pd.Timestamp,
    profit_eur: float,
    out_base: Path,
    zone: str = "SE3",
) -> str:
    """Figure 4.2: 3-panel example day (24 hourly or 96 quarter-hourly slots)."""
    _apply_style()
    T = len(prices)
    slots = np.arange(T)
    bp = config.BATTERY_PARAMS
    fig, axes = plt.subplots(3, 1, figsize=(10, 8), sharex=True)

    ax = axes[0]
    ax.plot(slots, prices, color="#333", lw=2, marker="o", ms=3)
    ch_win = charge_mw > 1e-3
    dis_win = discharge_mw > 1e-3
    for h in slots[ch_win]:
        ax.axvspan(h - 0.45, h + 0.45, color=config.COLORS["charge"], alpha=0.2)
    for h in slots[dis_win]:
        ax.axvspan(h - 0.45, h + 0.45, color=config.COLORS["discharge"], alpha=0.2)
    ax.set_ylabel("Price (€/MWh)")

    ax = axes[1]
    ax.plot(slots, soc_mwh, color=config.COLORS["soc"], lw=2)
    ax.axhline(bp["SOC_min"], color="k", ls="--", lw=0.8)
    ax.axhline(bp["SOC_max"], color="k", ls="--", lw=0.8)
    ax.set_ylabel("SOC (MWh)")

    ax = axes[2]
    ax.bar(
        slots - 0.2,
        charge_mw,
        width=0.4,
        color=config.COLORS["charge"],
        label="Charge",
    )
    ax.bar(
        slots + 0.2,
        discharge_mw,
        width=0.4,
        color=config.COLORS["discharge"],
        label="Discharge",
    )
    ax.set_ylabel("Power (MW)")
    ax.set_xlabel("Interval index (native DA resolution)")
    ax.set_xticks(slots if T <= 24 else slots[:: max(1, T // 24)])
    ax.legend(loc="upper right")

    txt = (
        f"E_max={bp['E_max']:.0f} MWh, P_max={bp['P_max']:.0f} MW, η={bp['eta']}, "
        f"c_deg={bp['c_deg']:.0f} €/MWh\nDaily profit (net deg.): {profit_eur:,.0f} €"
    )
    fig.text(0.12, 0.02, txt, fontsize=9, va="bottom", ha="left", family="monospace")

    plt.tight_layout(rect=(0, 0.06, 1, 1))
    _save_both(fig, out_base)
    return (
        f"Caption: Representative perfect-foresight arbitrage schedule for {zone} at native DA "
        "resolution: prices with charge (blue tint) and discharge (red tint) intervals, SOC "
        "trajectory with bounds, and interval charge/discharge power."
    )


def plot_revenue_distribution_seasonality(
    daily_by_zone: dict[str, pd.DataFrame],
    out_base: Path,
) -> str:
    """Figure 4.3: histogram + monthly mean revenue with error bars."""
    _apply_style()
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

    for z, df in daily_by_zone.items():
        if df.empty:
            continue
        prof = df["arbitrage_profit_eur"].clip(lower=1e-6)
        sns.histplot(
            prof,
            bins=50,
            stat="density",
            element="step",
            fill=True,
            alpha=0.35,
            label=z,
            color=config.COLORS.get(z, None),
            ax=ax1,
        )
    ax1.set_xscale("log")
    ax1.set_xlabel("Daily arbitrage profit (€, log scale)")
    ax1.set_ylabel("Density")
    ax1.legend()

    months = range(1, 13)
    x = np.array(months)
    width = 0.35
    for i, z in enumerate(daily_by_zone):
        df = daily_by_zone[z]
        if df.empty:
            continue
        g = df.groupby(df["date"].dt.month)["arbitrage_profit_eur"]
        mmean = g.mean().reindex(months)
        mstd = g.std(ddof=1).reindex(months)
        offset = (i - 0.5 * (len(daily_by_zone) - 1)) * width
        ax2.bar(
            x + offset,
            mmean,
            width,
            yerr=mstd,
            capsize=3,
            label=z,
            color=config.COLORS.get(z, None),
            ecolor="#555",
            alpha=0.85,
        )
    ax2.set_xticks(x)
    ax2.set_xlabel("Month")
    ax2.set_ylabel("Mean daily profit (€)")
    ax2.legend()
    plt.tight_layout()
    _save_both(fig, out_base)
    return (
        "Caption: Left: distribution of daily net arbitrage profits (log-scaled x-axis). "
        "Right: average daily profit by calendar month with ±1 standard deviation across years."
    )


def plot_dispatch_heatmap(
    hourly_df: pd.DataFrame,
    out_base: Path,
    zones: tuple[str, ...] = ("SE3", "SE4"),
) -> str:
    """Figure 4.4: 24 × 12 heatmaps (SE3 & SE4) of mean net power (discharge − charge)."""
    _apply_style()
    fig, axes = plt.subplots(1, len(zones), figsize=(14, 5), sharey=True)
    if len(zones) == 1:
        axes = [axes]

    global_vmax = 1.0
    pivots: list[pd.DataFrame] = []
    for z in zones:
        sub = hourly_df[hourly_df["zone"] == z].copy()
        if sub.empty:
            pivots.append(pd.DataFrame())
            continue
        sub["month"] = pd.to_datetime(sub["date"]).dt.month
        sub["net_mw"] = sub["discharge_mw"] - sub["charge_mw"]
        ts = pd.to_datetime(sub["timestamp"], utc=True).dt.tz_convert(config.LOCAL_TZ)
        sub["hour"] = ts.dt.hour
        pivot = sub.groupby(["month", "hour"])["net_mw"].mean().unstack("hour")
        pivot = pivot.reindex(index=range(1, 13), columns=range(24))
        pivots.append(pivot)
        vm = np.nanmax(np.abs(pivot.values))
        if np.isfinite(vm) and vm > 0:
            global_vmax = max(global_vmax, vm)

    for ax, z, pivot in zip(axes, zones, pivots):
        if pivot.empty:
            ax.text(0.5, 0.5, "No data", ha="center", va="center")
            continue
        sns.heatmap(
            pivot,
            cmap="RdBu_r",
            center=0,
            vmin=-global_vmax,
            vmax=global_vmax,
            ax=ax,
            cbar_kws={},
            linewidths=0,
        )
        ax.set_xlabel("Hour of day")
        ax.set_ylabel("Month")

    plt.tight_layout()
    _save_both(fig, out_base)
    return (
        "Caption: Mean hourly net power (discharge minus charge) by calendar month and hour for "
        "SE3 (left) and SE4 (right); red indicates net discharging, blue net charging."
    )


def plot_cumulative_revenue(
    daily_by_zone: dict[str, pd.DataFrame],
    out_base: Path,
) -> str:
    """Figure 4.5: cumulative revenue with year boundaries."""
    _apply_style()
    fig, ax = plt.subplots(figsize=(11, 5))

    for z, df in daily_by_zone.items():
        if df.empty:
            continue
        d = df.sort_values("date").copy()
        d["cum"] = d["arbitrage_profit_eur"].cumsum()
        d = d.set_index("date")["cum"]
        d.plot(ax=ax, label=z, color=config.COLORS.get(z, None), lw=2)

    xlim = ax.get_xlim()
    for y in range(2020, 2027):
        t0 = pd.Timestamp(f"{y}-01-01", tz=config.LOCAL_TZ)
        tn = mdates.date2num(t0)
        if xlim[0] <= tn <= xlim[1]:
            ax.axvline(t0, color="#bbb", ls="--", lw=0.8)
            ytot = 0.0
            for df in daily_by_zone.values():
                if df.empty:
                    continue
                sub = df[df["date"].dt.year == y]
                if len(sub):
                    ytot += float(sub["arbitrage_profit_eur"].sum())
            if ytot > 0:
                ax.annotate(
                    f"{y}\n{ytot/1e3:.0f} k€",
                    xy=(tn, ax.get_ylim()[1]),
                    xytext=(0, -4),
                    textcoords="offset points",
                    fontsize=8,
                    color="#444",
                    ha="center",
                    va="top",
                )

    ax.set_ylabel("Cumulative revenue (€)")
    ax.set_xlabel("Date")
    ax.legend(loc="upper left")
    ax.xaxis.set_major_locator(mdates.YearLocator())
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
    fig.autofmt_xdate()
    plt.tight_layout()
    _save_both(fig, out_base)
    return (
        "Caption: Cumulative net arbitrage profit under perfect foresight per day, "
        "with vertical lines at year starts; virtual 100 MWh / 25 MW asset per bidding zone."
    )


def pick_representative_day(
    daily_df: pd.DataFrame,
    hourly_df: Optional[pd.DataFrame],
    zone: str,
) -> Optional[pd.Timestamp]:
    """Pick a day close to median daily profit that has hourly schedule data."""
    if daily_df.empty:
        return None
    med = daily_df["arbitrage_profit_eur"].median()
    order = (daily_df["arbitrage_profit_eur"] - med).abs().sort_values()
    dates_h: Optional[set] = None
    if hourly_df is not None and len(hourly_df):
        h = hourly_df[hourly_df["zone"] == zone]
        dates_h = set(pd.to_datetime(h["date"]).dt.date)
    for idx in order.index:
        d_date = pd.to_datetime(daily_df.loc[idx, "date"]).date()
        if dates_h is None or d_date in dates_h:
            return pd.Timestamp(d_date, tz=config.LOCAL_TZ)
    d0 = pd.to_datetime(daily_df.iloc[order.index[0]]["date"]).date()
    return pd.Timestamp(d0, tz=config.LOCAL_TZ)
