"""
Aggregate daily optimization results: Table 4.1 style summaries, CSV/TeX export.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd


def compute_summary_statistics(
    daily_by_zone: dict[str, pd.DataFrame],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Build wide summary (metrics × zones + Combined) and per-year revenue table.

    Combined = sum of daily profits for SE3 and SE4 (two independent identical batteries).
    """
    zones = list(daily_by_zone.keys())
    if not zones:
        return pd.DataFrame(), pd.DataFrame()

    # Align on date for combined
    merged = None
    for z, df in daily_by_zone.items():
        d = df[["date", "arbitrage_profit_eur"]].copy()
        d = d.rename(columns={"arbitrage_profit_eur": z})
        merged = d if merged is None else pd.merge(merged, d, on="date", how="outer")
    assert merged is not None
    merged["Combined"] = merged[[c for c in zones if c in merged.columns]].sum(axis=1, min_count=1)

    rows: list[dict[str, object]] = []
    col_order = zones + ["Combined"]

    def add_row(metric: str, fn):
        row = {"Metric": metric}
        for c in col_order:
            if c not in merged.columns and c != "Combined":
                row[c] = np.nan
                continue
            ser = merged[c].dropna()
            row[c] = fn(ser) if len(ser) else np.nan
        rows.append(row)

    add_row("Mean Daily Profit (€)", lambda s: float(s.mean()))
    add_row("Std Daily Profit (€)", lambda s: float(s.std(ddof=1)) if len(s) > 1 else 0.0)
    add_row("Min Daily Profit (€)", lambda s: float(s.min()))
    add_row("Max Daily Profit (€)", lambda s: float(s.max()))
    add_row("Median Daily Profit (€)", lambda s: float(s.median()))

    summary = pd.DataFrame(rows).set_index("Metric")[col_order]

    # Annual totals per zone + combined
    year_rows: list[dict[str, object]] = []
    years = sorted(
        pd.unique(
            pd.concat([df["date"] for df in daily_by_zone.values()]).dt.year.dropna()
        )
    )
    for y in years:
        r: dict[str, object] = {"Year": int(y)}
        combined_sum = 0.0
        for z in zones:
            df = daily_by_zone[z]
            sub = df[df["date"].dt.year == y]
            val = float(sub["arbitrage_profit_eur"].sum()) if len(sub) else 0.0
            r[z] = val
            combined_sum += val
        r["Combined"] = combined_sum
        year_rows.append(r)
    annual = pd.DataFrame(year_rows).set_index("Year")

    total_row = {"Metric": "Total 6-year Revenue (€)"}
    for c in col_order:
        if c == "Combined":
            total_row[c] = float(merged["Combined"].sum())
        elif c in merged.columns:
            total_row[c] = float(merged[c].sum())
        else:
            total_row[c] = np.nan
    summary.loc["Total 6-year Revenue (€)"] = [total_row[c] for c in col_order]

    return summary, annual


def save_table_csv_tex(
    summary: pd.DataFrame,
    annual: pd.DataFrame,
    out_dir: Path,
    stem: str = "table4_1_summary",
) -> None:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    summary.to_csv(out_dir / f"{stem}_summary.csv")
    annual.to_csv(out_dir / f"{stem}_annual.csv")

    tex_path = out_dir / f"{stem}.tex"
    lines = [
        r"\begin{tabular}{l" + "r" * len(summary.columns) + "}",
        r"\hline",
        r"Metric & " + " & ".join(summary.columns) + r" \\",
        r"\hline",
    ]
    for idx, row in summary.iterrows():
        vals = " & ".join(f"{v:,.2f}" if isinstance(v, (float, np.floating)) else str(v) for v in row)
        lines.append(f"{idx} & {vals} \\\\")
    lines.extend([r"\hline", r"\end{tabular}"])
    tex_path.write_text("\n".join(lines), encoding="utf-8")
