"""
Daily deterministic spot arbitrage LP (PuLP + CBC).

Perfect foresight within each delivery day at native Day-Ahead resolution (1 h or 15 min).
Virtual asset: no grid fees, no balancing (see thesis Section 3.3).
"""
from __future__ import annotations

import logging
from typing import Any, Optional

import numpy as np
import pandas as pd
import pulp

import config

logger = logging.getLogger(__name__)


def _solve_one_day(
    prices: np.ndarray,
    soc_init: float,
    bp: dict[str, float],
    dt_hours: float,
) -> Optional[dict[str, Any]]:
    """
    LP with mutual exclusivity (binary per interval). `dt_hours` is length of each step (e.g. 1.0 or 0.25).
    Energy: MWh change per step = MW * dt_hours.
    """
    T = len(prices)
    if T < 1 or dt_hours <= 0:
        return None

    E_max = bp["E_max"]
    P_max = bp["P_max"]
    eta = bp["eta"]
    soc_min = bp["SOC_min"]
    soc_max = bp["SOC_max"]
    c_deg = bp["c_deg"]
    c_max = bp["C_max"]
    cycle_cap = 2.0 * c_max * E_max

    prob = pulp.LpProblem("SpotArbitrage", pulp.LpMaximize)

    charge = [
        pulp.LpVariable(f"ch_{t}", lowBound=0, upBound=P_max, cat=pulp.LpContinuous)
        for t in range(T)
    ]
    discharge = [
        pulp.LpVariable(f"dis_{t}", lowBound=0, upBound=P_max, cat=pulp.LpContinuous)
        for t in range(T)
    ]
    soc = [
        pulp.LpVariable(
            f"soc_{t}", lowBound=soc_min, upBound=soc_max, cat=pulp.LpContinuous
        )
        for t in range(T)
    ]
    # z[t] = 1 → allow charge only; z[t] = 0 → allow discharge only (idle allowed)
    z = [pulp.LpVariable(f"z_{t}", cat=pulp.LpBinary) for t in range(T)]

    revenue = pulp.lpSum(
        float(prices[t]) * (discharge[t] - charge[t]) * dt_hours for t in range(T)
    )
    degradation = c_deg * pulp.lpSum(
        (charge[t] + discharge[t]) * dt_hours for t in range(T)
    )
    prob += revenue - degradation

    for t in range(T):
        if t == 0:
            prob += soc[t] == soc_init + eta * charge[t] * dt_hours - discharge[t] / eta * dt_hours
        else:
            prob += (
                soc[t]
                == soc[t - 1] + eta * charge[t] * dt_hours - discharge[t] / eta * dt_hours
            )
        prob += charge[t] <= P_max * z[t]
        prob += discharge[t] <= P_max * (1 - z[t])

    prob += pulp.lpSum((charge[t] + discharge[t]) * dt_hours for t in range(T)) <= cycle_cap

    prob.solve(pulp.PULP_CBC_CMD(msg=False))
    if prob.status != pulp.LpStatusOptimal:
        return None

    ch_v = np.array([pulp.value(charge[t]) or 0.0 for t in range(T)])
    dis_v = np.array([pulp.value(discharge[t]) or 0.0 for t in range(T)])
    soc_v = np.array([pulp.value(soc[t]) or 0.0 for t in range(T)])
    obj = pulp.value(prob.objective)
    if obj is None:
        return None

    total_ch = float((ch_v * dt_hours).sum())
    total_dis = float((dis_v * dt_hours).sum())
    avg_soc = float(soc_v.mean())
    num_cycles = (total_ch + total_dis) / (2.0 * E_max)

    return {
        "arbitrage_profit_eur": float(obj),
        "total_charged_mwh": total_ch,
        "total_discharged_mwh": total_dis,
        "avg_soc": avg_soc,
        "num_cycles": num_cycles,
        "charge_mw": ch_v,
        "discharge_mw": dis_v,
        "soc_mwh": soc_v,
        "soc_end_mwh": float(soc_v[-1]),
    }


def build_arbitrage_model(
    prices_hourly: np.ndarray,
    battery_params: dict[str, float],
    soc_init: float,
    dt_hours: float = 1.0,
) -> Optional[dict[str, Any]]:
    """Build and solve the daily LP; wrapper for tests."""
    return _solve_one_day(
        np.asarray(prices_hourly, dtype=float), soc_init, battery_params, dt_hours
    )


def run_daily_optimization(
    price_series: pd.Series,
    battery_params: Optional[dict[str, float]] = None,
    rolling_soc: bool = True,
    zone_label: str = "zone",
    store_hourly: bool = False,
) -> tuple[pd.DataFrame, list[str], Optional[pd.DataFrame]]:
    """
    Loop over calendar days in local time at native resolution (uniform step per day).
    Skips days with NaN prices or non-uniform intervals.

    Returns
    -------
    daily_df, failed_days, hourly_df_or_none
    """
    bp = battery_params or config.BATTERY_PARAMS
    s = price_series.dropna().sort_index()
    if s.index.tz is None:
        s.index = s.index.tz_localize(
            config.LOCAL_TZ, ambiguous="infer", nonexistent="shift_forward"
        )
    else:
        s = s.tz_convert(config.LOCAL_TZ)

    soc_next = float(bp["SOC_0"])
    rows: list[dict[str, Any]] = []
    failed: list[str] = []
    hourly_records: list[dict[str, Any]] = []

    for day, block in s.groupby(s.index.normalize()):
        block = block.sort_index()
        if len(block) < 1:
            failed.append(f"{day.date()} (empty)")
            continue
        if block.isna().any():
            failed.append(f"{day.date()} (NaN)")
            continue
        diffs = pd.Series(block.index).diff().dropna()
        if diffs.empty:
            failed.append(f"{day.date()} (single point)")
            continue
        dt = diffs.median()
        if pd.isna(dt) or dt <= pd.Timedelta(0):
            failed.append(f"{day.date()} (bad timestep)")
            continue
        if (diffs - dt).abs().max() > pd.Timedelta(seconds=90):
            failed.append(f"{day.date()} (non-uniform steps)")
            continue
        dt_hours = float(dt.total_seconds() / 3600.0)
        prices = block.values.astype(float)
        res = _solve_one_day(prices, soc_next, bp, dt_hours)
        if res is None:
            failed.append(f"{day.date()} (infeasible)")
            continue
        row = {
            "date": pd.Timestamp(day).normalize(),
            "zone": zone_label,
            "arbitrage_profit_eur": res["arbitrage_profit_eur"],
            "total_charged_mwh": res["total_charged_mwh"],
            "total_discharged_mwh": res["total_discharged_mwh"],
            "avg_soc": res["avg_soc"],
            "num_cycles": res["num_cycles"],
            "soc_end_mwh": res["soc_end_mwh"],
            "n_intervals": len(block),
            "dt_hours": dt_hours,
        }
        rows.append(row)
        if store_hourly:
            for t, ts in enumerate(block.index):
                hourly_records.append(
                    {
                        "timestamp": ts,
                        "date": pd.Timestamp(day).normalize(),
                        "zone": zone_label,
                        "interval": t,
                        "price_eur_mwh": float(prices[t]),
                        "charge_mw": float(res["charge_mw"][t]),
                        "discharge_mw": float(res["discharge_mw"][t]),
                        "soc_mwh": float(res["soc_mwh"][t]),
                    }
                )
        if rolling_soc:
            soc_next = res["soc_end_mwh"]
        else:
            soc_next = float(bp["SOC_0"])

    df = pd.DataFrame(rows)
    if not df.empty:
        df["date"] = pd.to_datetime(df["date"])
    hourly_df = (
        pd.DataFrame.from_records(hourly_records) if hourly_records else None
    )
    return df, failed, hourly_df


def export_hourly_schedules(
    price_series: pd.Series,
    battery_params: Optional[dict[str, float]] = None,
    rolling_soc: bool = True,
    zone_label: str = "zone",
) -> pd.DataFrame:
    """Hourly schedules (re-runs optimization; prefer run_daily_optimization(..., store_hourly=True))."""
    _, _, h = run_daily_optimization(
        price_series,
        battery_params=battery_params,
        rolling_soc=rolling_soc,
        zone_label=zone_label,
        store_hourly=True,
    )
    return h if h is not None else pd.DataFrame()
