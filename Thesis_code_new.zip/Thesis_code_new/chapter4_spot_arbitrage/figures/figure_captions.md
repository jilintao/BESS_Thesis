# Figure captions (Chapter 4.1)

## Figure 4.1

Caption: Day-ahead spot prices (hourly, inflation-adjusted to 2025 EUR) averaged to daily means for SE3 (blue) and SE4 (orange); dashed lines on the secondary axis show daily standard deviation. Shaded band highlights elevated volatility during the 2021–2022 period.

## Figure 4.3

Caption: Left: distribution of daily net arbitrage profits (log-scaled x-axis). Right: average daily profit by calendar month with ±1 standard deviation across years.

## Figure 4.4

Caption: Mean hourly net power (discharge minus charge) by calendar month and hour for SE3 (left) and SE4 (right); red indicates net discharging, blue net charging.

## Figure 4.5

Caption: Cumulative net arbitrage profit under perfect foresight per day, with vertical lines at year starts; virtual 100 MWh / 25 MW asset per bidding zone.

## Figure 4.2

Caption: Representative perfect-foresight arbitrage schedule for SE3 at native DA resolution: prices with charge (blue tint) and discharge (red tint) intervals, SOC trajectory with bounds, and interval charge/discharge power.
