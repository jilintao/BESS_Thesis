# Full thesis empirical pipeline (Windows). Repo root = folder containing this script.
#   $env:ENTSOE_API_KEY = "<token>"
#   .\RUN_FULL_THESIS_PIPELINE.ps1

$ErrorActionPreference = "Stop"
$Root = $PSScriptRoot
if (-not $env:ENTSOE_API_KEY) { Write-Error "Set ENTSOE_API_KEY first." }

Set-Location (Join-Path $Root "chapter4_spot_arbitrage")
if (Test-Path ".\data\processed_prices.parquet") { python main.py --skip-fetch } else { python main.py }

Set-Location (Join-Path $Root "chapter4_balancing")
python main_bal.py

Set-Location (Join-Path $Root "chapter4_regression")
python main_rebuilt.py

Set-Location (Join-Path $Root "chapter4_scenario_analysis")
python main_scenario.py --skip-tornado

Set-Location $Root
Write-Host "Done." -ForegroundColor Green
