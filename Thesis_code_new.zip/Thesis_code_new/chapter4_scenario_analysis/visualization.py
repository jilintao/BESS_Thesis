"""Figures 4.20--4.24 (scenario analysis)."""
from __future__ import annotations

import logging
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import config

log = logging.getLogger(__name__)


def _style():
    plt.rcParams.update(
        {
            "font.family": config.FONT_FAMILY,
            "font.sans-serif": config.FONT_SANS,
            "font.size": config.TICK_FONTSIZE,
            "axes.titlesize": config.TITLE_FONTSIZE,
            "axes.labelsize": config.LABEL_FONTSIZE,
            "figure.dpi": config.FIG_DPI,
        }
    )


def _save(fig: plt.Figure, base: Path) -> None:
    base = Path(base)
    base.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(f"{base}.png", dpi=config.FIG_DPI, bbox_inches="tight")
    fig.savefig(f"{base}.pdf", bbox_inches="tight")
    plt.close(fig)


def plot_scenario_price_profiles(
    scenario_wide: pd.DataFrame,
    example_date: pd.Timestamp | None,
    zone: str,
    out_base: Path,
) -> None:
    """Figure 4.20: 24h prices on one calendar day for all scenarios."""
    _style()
    sw = scenario_wide.sort_index()
    loc = sw.index.tz_convert(config.LOCAL_TZ)
    day_key = loc.normalize()
    sub = None
    chosen = None
    if example_date is not None:
        t = pd.Timestamp(example_date)
        if t.tzinfo is None:
            t = t.tz_localize(config.LOCAL_TZ)
        else:
            t = t.tz_convert(config.LOCAL_TZ)
        want = t.normalize()
        sel = day_key == want
        if sel.sum() == 24:
            sub = sw.loc[sel]
            chosen = want
    if sub is None:
        for dk in sorted(day_key.unique()):
            sel = day_key == dk
            if sel.sum() == 24:
                sub = sw.loc[sel]
                chosen = dk
                break
    if sub is None or len(sub) != 24:
        log.error("Fig 4.20: could not find a 24-hour local day")
        return

    hours = np.arange(24)
    fig, ax = plt.subplots(figsize=(10, 4.5), layout="constrained")
    styles = {
        "baseline": (config.COL_BASELINE, "-"),
        "high_vol": (config.COL_HIGH_VOL, "--"),
        "low_vol": (config.COL_LOW_VOL, ":"),
        "high_renewable": (config.COL_RENEW, "-."),
    }
    for sc in config.SCENARIOS:
        c, ls = styles[sc]
        ax.plot(hours, sub[sc].values, color=c, ls=ls, lw=1.8, label=sc.replace("_", " "))
    ax.axhline(config.PRICE_FLOOR, color="gray", ls="--", lw=0.8, alpha=0.7, label="Floor $-150$")
    ax.set_xticks(range(0, 24, 2))
    ax.set_xlabel("Hour (local)")
    ax.set_ylabel("Price (EUR/MWh)")
    ax.legend(loc="best", fontsize=8)
    _save(fig, out_base)


def plot_annual_revenue_comparison(
    results: dict[str, dict[str, pd.DataFrame]],
    out_base: Path,
) -> None:
    """Figure 4.21: grouped bars — mean annual total revenue by scenario; error = std across years."""
    _style()
    import results_aggregation as ra

    rows = []
    for zone, sd in results.items():
        for scen, df in sd.items():
            if df.empty:
                continue
            y = ra.daily_to_annual_totals(df)
            rows.append(
                {"zone": zone, "scenario": scen, "annual_mean": y.mean(), "annual_std": y.std(ddof=0)}
            )
    dfp = pd.DataFrame(rows)
    if dfp.empty:
        return

    scenarios = list(config.SCENARIOS)
    x = np.arange(len(scenarios))
    w = 0.35
    fig, ax = plt.subplots(figsize=(9, 4.5), layout="constrained")
    for i, zone in enumerate(["SE3", "SE4"]):
        sub = dfp[dfp["zone"] == zone].set_index("scenario").reindex(scenarios)
        means = sub["annual_mean"].values / 1e6
        stds = sub["annual_std"].values / 1e6
        offset = (i - 0.5) * w
        bars = ax.bar(
            x + offset,
            means,
            w,
            yerr=stds,
            capsize=3,
            label=zone,
            color=config.COL_SE3 if zone == "SE3" else config.COL_SE4,
            alpha=0.88,
        )
        baseline_mean = sub.loc["baseline", "annual_mean"] if "baseline" in sub.index else np.nan
        for j, scen in enumerate(scenarios):
            if scen == "baseline" or not np.isfinite(baseline_mean) or baseline_mean == 0:
                continue
            ch = 100 * (sub.loc[scen, "annual_mean"] - baseline_mean) / baseline_mean
            ax.text(
                x[j] + offset,
                means[j] + stds[j] + 0.05,
                f"{ch:+.0f}%",
                ha="center",
                va="bottom",
                fontsize=7,
            )
    ax.set_xticks(x)
    ax.set_xticklabels([s.replace("_", " ") for s in scenarios], rotation=15, ha="right")
    ax.set_ylabel("Mean annual revenue (M EUR)")
    ax.legend()
    _save(fig, out_base)


def plot_revenue_composition(
    results: dict[str, dict[str, pd.DataFrame]],
    out_base: Path,
) -> None:
    """Figure 4.22: stacked bars — spot vs proxy balancing share of cumulative total (6-yr)."""
    _style()
    scenarios = list(config.SCENARIOS)
    zones = ["SE3", "SE4"]
    spot_v = np.zeros((len(zones), len(scenarios)))
    bal_v = np.zeros((len(zones), len(scenarios)))
    for zi, zone in enumerate(zones):
        for sj, scen in enumerate(scenarios):
            df = results[zone].get(scen)
            if df is None or df.empty:
                continue
            spot_v[zi, sj] = df["spot_eur"].sum()
            bal_v[zi, sj] = df["balancing_est_eur"].sum()

    fig, axes = plt.subplots(1, 2, figsize=(11, 4), layout="constrained", sharey=True)
    x = np.arange(len(scenarios))
    w = 0.35
    for zi, (ax, zone) in enumerate(zip(axes, zones)):
        offset = w * (zi - 0.5)
        ax.bar(
            x + offset,
            spot_v[zi] / 1e6,
            w,
            label="Spot",
            color=config.COL_SPOT,
            alpha=0.9,
        )
        ax.bar(
            x + offset,
            bal_v[zi] / 1e6,
            w,
            bottom=spot_v[zi] / 1e6,
            label="Balancing (proxy)",
            color=config.COL_BAL,
            alpha=0.9,
        )
        ax.set_xticks(x)
        ax.set_xticklabels([s.replace("_", "\n") for s in scenarios], fontsize=8)
        ax.set_ylabel("Cumulative revenue (M EUR)")
        ax.text(0.02, 0.98, zone, transform=ax.transAxes, fontsize=10, va="top", ha="left")
    axes[0].legend(loc="upper left", fontsize=8)
    _save(fig, out_base)


def plot_cumulative_revenue_paths(
    results: dict[str, dict[str, pd.DataFrame]],
    out_base: Path,
) -> None:
    """Figure 4.23: cumulative total_eur over time, one line per scenario, SE3/SE4 subplots."""
    _style()
    styles = {
        "baseline": (config.COL_BASELINE, "-"),
        "high_vol": (config.COL_HIGH_VOL, "--"),
        "low_vol": (config.COL_LOW_VOL, ":"),
        "high_renewable": (config.COL_RENEW, "-."),
    }
    fig, axes = plt.subplots(2, 1, figsize=(10, 7), layout="constrained", sharex=True)
    for ax, zone in zip(axes, ["SE3", "SE4"]):
        for sc in config.SCENARIOS:
            df = results[zone].get(sc)
            if df is None or df.empty:
                continue
            d = df.sort_values("date")
            csum = d["total_eur"].cumsum() / 1e6
            t = pd.to_datetime(d["date"])
            c, ls = styles[sc]
            ax.plot(t, csum, color=c, ls=ls, lw=1.6, label=sc.replace("_", " "))
        for y in range(2020, 2027):
            ax.axvline(pd.Timestamp(f"{y}-01-01"), color="gray", ls=":", lw=0.6, alpha=0.5)
        ax.set_ylabel("Cumulative (M EUR)")
        ax.text(0.02, 0.98, zone, transform=ax.transAxes, fontsize=10, va="top", ha="left")
        ax.legend(loc="upper left", fontsize=7, ncol=2)
    axes[-1].set_xlabel("Date")
    _save(fig, out_base)


def plot_sensitivity_tornado(
    oat_pct: dict[str, float],
    out_base: Path,
) -> None:
    """
    Figure 4.24: horizontal bars — % change in total 6-yr revenue vs baseline (SE3), one-at-a-time shocks.
    oat_pct keys: human-readable parameter labels.
    """
    _style()
    labels = list(oat_pct.keys())
    vals = [oat_pct[k] for k in labels]
    y = np.arange(len(labels))
    colors = [config.COL_HIGH_VOL if v > 0 else config.COL_LOW_VOL for v in vals]
    fig, ax = plt.subplots(figsize=(8, 4.5), layout="constrained")
    ax.barh(y, vals, color=colors, alpha=0.85)
    ax.set_yticks(y)
    ax.set_yticklabels(labels, fontsize=9)
    ax.axvline(0, color="black", lw=0.8)
    ax.set_xlabel(r"% change vs.\ baseline (total 6-yr revenue, SE3)")
    _save(fig, out_base)
