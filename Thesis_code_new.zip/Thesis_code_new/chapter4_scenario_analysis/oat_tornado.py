"""Generate Fig. 4.24 only (run after main scenario outputs exist)."""
from __future__ import annotations

import pandas as pd

import config
import visualization as vis
from revenue_estimation import estimate_total_revenues, fit_proxy_lasso_full_sample
from scenario_generation import (
    baseline_pooled_p95,
    decompose_price_series,
    generate_oat_prices,
    load_zone_hourly_series,
)


def main() -> None:
    p95 = baseline_pooled_p95()
    proxy = fit_proxy_lasso_full_sample("SE3")
    mu, eps = decompose_price_series(load_zone_hourly_series("SE3"))
    df = pd.read_csv(config.DATA_DIR / "scenario_revenues_all.csv")
    base = float(df[(df.zone == "SE3") & (df.scenario == "baseline")]["total_eur"].sum())
    oat_labels = [
        ("k_hv", r"$k_{\mathrm{HV}}=1.5$ (volatility scale)"),
        ("k_lv", r"$k_{\mathrm{LV}}=0.6$ (volatility scale)"),
        ("k_re_eps", r"$k_{\mathrm{RE}}=1.2$ on $\varepsilon$ only"),
        ("mid_shift", "Midday $-25$ EUR/MWh only"),
        ("eve_shift", "Evening $+35$ EUR/MWh only"),
    ]
    oat_pct: dict[str, float] = {}
    for key, lab in oat_labels:
        pser = generate_oat_prices(mu, eps, key)
        dfp = estimate_total_revenues(pser, "SE3", proxy, p95)
        tot = float(dfp["total_eur"].sum()) if len(dfp) else 0.0
        oat_pct[lab] = 100.0 * (tot - base) / base if base else 0.0
    vis.plot_sensitivity_tornado(oat_pct, config.FIG_DIR / "fig4_24_sensitivity_tornado")
    print("Wrote fig4_24; deltas % vs baseline SE3 total:", oat_pct)


if __name__ == "__main__":
    main()
