"""Chapter 4.4 scenario analysis — paths, battery, scenario parameters."""
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parent
THESIS_ROOT = ROOT.parent  # thesis project root (folder containing chapter folders)

SPOT_DIR = THESIS_ROOT / "chapter4_spot_arbitrage"
REG_DIR = THESIS_ROOT / "chapter4_regression"

PROCESSED_PRICES = SPOT_DIR / "data" / "processed_prices.parquet"

DATA_DIR = ROOT / "data"
FIG_DIR = ROOT / "figures"
TABLES_DIR = ROOT / "tables"

for d in (DATA_DIR, FIG_DIR, TABLES_DIR):
    d.mkdir(parents=True, exist_ok=True)

LOCAL_TZ = "Europe/Stockholm"

# Scenario scaling (Section 3.5.3 style)
K_HIGH_VOL = 1.5
K_LOW_VOL = 0.6
K_RENEWABLE_VOL = 1.2
DELTA_MIDDAY = -25.0  # EUR/MWh, hours 11–15 local
DELTA_EVENING = 35.0  # EUR/MWh, hours 18–22 local
PRICE_FLOOR = -150.0  # EUR/MWh

SCENARIOS = ("baseline", "high_vol", "low_vol", "high_renewable")

# Plot style
FIG_DPI = 300
FONT_FAMILY = "sans-serif"
FONT_SANS = ["Arial", "Helvetica", "DejaVu Sans"]
TITLE_FONTSIZE = 14
LABEL_FONTSIZE = 11
TICK_FONTSIZE = 10

COL_BASELINE = "black"
COL_HIGH_VOL = "#E53935"
COL_LOW_VOL = "#1E88E5"
COL_RENEW = "#43A047"
COL_SE3 = "#2196F3"
COL_SE4 = "#FF9800"
COL_SPOT = "#2196F3"
COL_BAL = "#FF9800"
