"""
Decompose baseline spot prices into structural (month×hour mean) μ and residual ε;
construct scenario hourly series. Not forecasting — sensitivity shocks only.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Literal

import numpy as np
import pandas as pd

import config

log = logging.getLogger(__name__)

ScenarioName = Literal["baseline", "high_vol", "low_vol", "high_renewable"]


def load_zone_hourly_series(zone: str) -> pd.Series:
    """Hourly prices for one zone; tz-aware index as stored in parquet."""
    df = pd.read_parquet(config.PROCESSED_PRICES)
    if not isinstance(df.index, pd.DatetimeIndex):
        raise TypeError("processed_prices.parquet must use DatetimeIndex")
    if zone not in df.columns:
        raise KeyError(zone)
    s = df[zone].sort_index()
    if s.index.tz is None:
        s.index = s.index.tz_localize("UTC").tz_convert(config.LOCAL_TZ)
    else:
        s = s.tz_convert(config.LOCAL_TZ)
    return s


def baseline_pooled_p95() -> float:
    """Same rule as Chapter 4.3: P95 over all SE3 and SE4 hourly observations."""
    df = pd.read_parquet(config.PROCESSED_PRICES)
    v = pd.concat([df["SE3"].dropna(), df["SE4"].dropna()], ignore_index=True)
    return float(v.quantile(0.95))


def decompose_price_series(prices_hourly: pd.Series) -> tuple[pd.Series, pd.Series]:
    """
    μ_t = mean price for (calendar month, local hour) over the sample;
    ε_t = p_t - μ_t. Index preserved (Stockholm local wall-clock for grouping).
    """
    s = prices_hourly.dropna().sort_index()
    idx = s.index
    loc = idx.tz_convert(config.LOCAL_TZ)
    tmp = pd.DataFrame({"price": s.values, "month": loc.month, "hour": loc.hour}, index=s.index)
    mu = tmp.groupby(["month", "hour"])["price"].transform("mean")
    mu = pd.Series(mu.values, index=s.index, name="mu")
    eps = pd.Series(tmp["price"].values - mu.values, index=s.index, name="epsilon")
    return mu, eps


def _apply_floor(s: pd.Series, floor: float = config.PRICE_FLOOR) -> pd.Series:
    arr = s.to_numpy(dtype=float, copy=True)
    n_clip = int(np.sum(arr < floor))
    if n_clip > 0:
        log.warning(
            "Clipped %s hourly prices to floor %.1f EUR/MWh (scenario sensitivity)",
            n_clip,
            floor,
        )
    out = np.maximum(arr, floor)
    return pd.Series(out, index=s.index, name=s.name)


def generate_scenario_prices(
    mu_t: pd.Series,
    epsilon_t: pd.Series,
    scenario: ScenarioName,
) -> pd.Series:
    """p = μ + k·ε with scenario-specific k and RE structural shifts; then price floor."""
    if not mu_t.index.equals(epsilon_t.index):
        raise ValueError("mu and epsilon indices must match")

    if scenario == "baseline":
        p = mu_t + epsilon_t
    elif scenario == "high_vol":
        p = mu_t + config.K_HIGH_VOL * epsilon_t
    elif scenario == "low_vol":
        p = mu_t + config.K_LOW_VOL * epsilon_t
    elif scenario == "high_renewable":
        p = mu_t + config.K_RENEWABLE_VOL * epsilon_t
        loc_hour = p.index.tz_convert(config.LOCAL_TZ).hour
        h = pd.Series(loc_hour, index=p.index)
        p = p.copy()
        p.loc[h.isin([11, 12, 13, 14, 15])] += config.DELTA_MIDDAY
        p.loc[h.isin([18, 19, 20, 21, 22])] += config.DELTA_EVENING
    else:
        raise ValueError(scenario)

    p.name = f"price_{scenario}"
    return _apply_floor(p, config.PRICE_FLOOR)


def generate_all_scenarios(mu_t: pd.Series, epsilon_t: pd.Series) -> pd.DataFrame:
    """Wide hourly DataFrame: one column per scenario."""
    cols = {}
    for sc in config.SCENARIOS:
        cols[sc] = generate_scenario_prices(mu_t, epsilon_t, sc)  # type: ignore[arg-type]
    return pd.DataFrame(cols)


def generate_oat_prices(mu_t: pd.Series, epsilon_t: pd.Series, kind: str) -> pd.Series:
    """
    One-at-a-time shocks vs baseline p = mu + eps (for tornado / sensitivity).
    kinds: k_hv, k_lv, k_re_eps, mid_shift, eve_shift
    """
    if not mu_t.index.equals(epsilon_t.index):
        raise ValueError("index mismatch")
    base = mu_t + epsilon_t
    if kind == "k_hv":
        p = mu_t + config.K_HIGH_VOL * epsilon_t
    elif kind == "k_lv":
        p = mu_t + config.K_LOW_VOL * epsilon_t
    elif kind == "k_re_eps":
        p = mu_t + config.K_RENEWABLE_VOL * epsilon_t
    elif kind == "mid_shift":
        p = base.copy()
        h = pd.Series(p.index.tz_convert(config.LOCAL_TZ).hour, index=p.index)
        p.loc[h.isin([11, 12, 13, 14, 15])] += config.DELTA_MIDDAY
    elif kind == "eve_shift":
        p = base.copy()
        h = pd.Series(p.index.tz_convert(config.LOCAL_TZ).hour, index=p.index)
        p.loc[h.isin([18, 19, 20, 21, 22])] += config.DELTA_EVENING
    else:
        raise ValueError(kind)
    p.name = f"oat_{kind}"
    return _apply_floor(p, config.PRICE_FLOOR)


def save_scenario_parquet(df: pd.DataFrame, zone: str) -> Path:
    path = config.DATA_DIR / f"scenario_prices_{zone}.parquet"
    df.to_parquet(path)
    log.info("Wrote %s", path)
    return path
