"""
Spot arbitrage LP (Chapter 4.1) + Lasso proxy (Chapter 4.3) on scenario prices.

Proxy is re-fitted on the full historical daily panel (same specification as rebuilt 4.3)
so scenario days receive out-of-sample X only (structural-stability assumption).
"""
from __future__ import annotations

import importlib.util
import logging
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

import config

log = logging.getLogger(__name__)

MAX_MISSING_HOURS = 2
REG_DIR = Path(__file__).resolve().parent.parent / "chapter4_regression"
SPOT_DIR = Path(__file__).resolve().parent.parent / "chapter4_spot_arbitrage"


def _load_spot_optimization():
    """Load spot optimization with spot `config` (battery params) in isolation."""
    spec_c = importlib.util.spec_from_file_location("_spot_cfg_mod", SPOT_DIR / "config.py")
    scfg = importlib.util.module_from_spec(spec_c)
    assert spec_c.loader
    spec_c.loader.exec_module(scfg)
    old = sys.modules.get("config")
    sys.modules["config"] = scfg
    try:
        spec_o = importlib.util.spec_from_file_location("_spot_opt_mod", SPOT_DIR / "optimization.py")
        opt = importlib.util.module_from_spec(spec_o)
        assert spec_o.loader
        spec_o.loader.exec_module(opt)
        return opt, scfg
    finally:
        if old is not None:
            sys.modules["config"] = old
        elif "config" in sys.modules:
            del sys.modules["config"]


def _load_regression_training():
    """Load regression `config`, `data_preparation`, `ridge_lasso_models`."""
    spec_c = importlib.util.spec_from_file_location("_reg_cfg_mod", REG_DIR / "config.py")
    rcfg = importlib.util.module_from_spec(spec_c)
    assert spec_c.loader
    spec_c.loader.exec_module(rcfg)
    old = sys.modules.get("config")
    sys.modules["config"] = rcfg
    try:
        spec_dp = importlib.util.spec_from_file_location("_reg_dp_mod", REG_DIR / "data_preparation.py")
        dp = importlib.util.module_from_spec(spec_dp)
        assert spec_dp.loader
        spec_dp.loader.exec_module(dp)
        spec_rlm = importlib.util.spec_from_file_location("_reg_rlm_mod", REG_DIR / "ridge_lasso_models.py")
        rlm = importlib.util.module_from_spec(spec_rlm)
        assert spec_rlm.loader
        spec_rlm.loader.exec_module(rlm)
        return rcfg, dp, rlm
    finally:
        if old is not None:
            sys.modules["config"] = old
        elif "config" in sys.modules:
            del sys.modules["config"]


def _stockholm_day(ts: pd.Timestamp) -> pd.Timestamp:
    if ts.tzinfo is None:
        ts = ts.tz_localize("UTC")
    return ts.tz_convert(config.LOCAL_TZ).normalize()


def daily_indicators_from_hourly(hourly: pd.Series, p95: float) -> pd.DataFrame:
    """Same rules as Chapter 4.3 (volatility, spike_freq, ramp_rate); date naive UTC merge key."""
    s = hourly.copy()
    if s.empty:
        return pd.DataFrame()

    day_idx = pd.Series([_stockholm_day(t) for t in s.index], index=s.index)
    rows: list[dict[str, Any]] = []
    for day, grp in s.groupby(day_idx):
        vals = grp.sort_index().astype(float)
        if len(vals) < 22:
            continue
        if int(vals.isna().sum()) > MAX_MISSING_HOURS:
            continue
        prices = vals.interpolate(method="linear", limit=MAX_MISSING_HOURS)
        if prices.isna().any():
            continue
        d = pd.Timestamp(day)
        out_date = (
            d.tz_convert("UTC").tz_localize(None).normalize()
            if d.tzinfo
            else d.normalize()
        )
        rows.append(
            {
                "date": out_date,
                "volatility": float(prices.std(ddof=0)),
                "spike_freq": int((prices > p95).sum()),
                "ramp_rate": float(prices.diff().abs().max()),
            }
        )
    return pd.DataFrame(rows)


def fit_proxy_lasso_full_sample(zone: str) -> dict[str, Any]:
    """
    Lasso tuned by 5-fold CV on the full historical panel (Chapter 4.3 spec).
    Returns scaler (fitted on full X), estimator, feature list, regression config module.
    """
    rcfg, dp, rlm = _load_regression_training()
    df = dp.prepare_zone_dataframe(zone)  # type: ignore[attr-defined]
    feats = list(rcfg.FEATURE_COLS)
    X = df[feats].to_numpy(dtype=float)
    y = df[rcfg.TARGET_COL].to_numpy(dtype=float)
    from sklearn.preprocessing import StandardScaler

    scaler = StandardScaler()
    Xs = scaler.fit_transform(X)
    reg = rlm.RegularizedRegressionModels()
    reg.tune_lasso(Xs, y)
    model = reg.models["Lasso"]
    log.info("%s Lasso proxy fitted (full sample, CV); alpha=%s", zone, reg.best_params.get("Lasso"))
    return {
        "scaler": scaler,
        "model": model,
        "feature_cols": feats,
        "rcfg": rcfg,
        "historical_df": df,
    }


def run_spot_arbitrage_series(price_series: pd.Series, zone: str) -> pd.DataFrame:
    """Daily spot arbitrage profits (EUR/day) for a scenario hourly series."""
    opt, scfg = _load_spot_optimization()
    df, failed, _ = opt.run_daily_optimization(
        price_series,
        battery_params=scfg.BATTERY_PARAMS,
        rolling_soc=True,
        zone_label=zone,
        store_hourly=False,
    )
    if failed:
        log.debug("Spot opt skipped/failed days (%s): %s ...", len(failed), failed[:5])
    return df


def estimate_total_revenues(
    prices_scenario: pd.Series,
    zone: str,
    proxy: dict[str, Any],
    p95_baseline: float,
) -> pd.DataFrame:
    """
    Inner-join days: spot arbitrage + proxy balancing estimate.
    Columns: date, spot_eur, balancing_est_eur, total_eur
    """
    spot_df = run_spot_arbitrage_series(prices_scenario, zone)
    if spot_df.empty:
        log.error("No spot results for zone %s scenario %s", zone, prices_scenario.name)
        return pd.DataFrame()

    ind = daily_indicators_from_hourly(prices_scenario, p95_baseline)
    if ind.empty:
        return pd.DataFrame()

    spot_df = spot_df.copy()
    spot_df["date"] = pd.to_datetime(spot_df["date"])
    if spot_df["date"].dt.tz is not None:
        spot_df["date"] = spot_df["date"].dt.tz_convert("UTC").dt.tz_localize(None)
    spot_df["date"] = spot_df["date"].dt.normalize()
    ind["date"] = pd.to_datetime(ind["date"]).dt.normalize()

    feats = proxy["feature_cols"]
    X = ind[feats].to_numpy(dtype=float)
    Xs = proxy["scaler"].transform(X)
    ind = ind.assign(balancing_est_eur=proxy["model"].predict(Xs))

    merged = spot_df.merge(ind, on="date", how="inner")
    merged["spot_eur"] = merged["arbitrage_profit_eur"]
    merged["total_eur"] = merged["spot_eur"] + merged["balancing_est_eur"]
    out = merged[
        ["date", "spot_eur", "balancing_est_eur", "total_eur"]
    ].sort_values("date")
    return out.reset_index(drop=True)
