"""
Chapter 4.4: scenario generation + spot LP + balancing proxy → tables & figures.

Sensitivity analysis only — not forecasting.
"""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

import pandas as pd

import config
import results_aggregation as ra
import visualization as vis
from revenue_estimation import (
    estimate_total_revenues,
    fit_proxy_lasso_full_sample,
)
from scenario_generation import (
    baseline_pooled_p95,
    decompose_price_series,
    generate_all_scenarios,
    load_zone_hourly_series,
    save_scenario_parquet,
)


def _setup_log() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[logging.StreamHandler(sys.stdout)],
    )


def _load_scenario_results_from_disk() -> dict[str, dict[str, pd.DataFrame]]:
    """Rebuild results[zone][scenario] from scenario_revenues_<zone>.csv."""
    results: dict[str, dict[str, pd.DataFrame]] = {"SE3": {}, "SE4": {}}
    for zone in ("SE3", "SE4"):
        p = config.DATA_DIR / f"scenario_revenues_{zone}.csv"
        if not p.is_file():
            raise FileNotFoundError(f"Missing {p}")
        df = pd.read_csv(p, parse_dates=["date"])
        for sc in config.SCENARIOS:
            sub = df[df["scenario"] == sc].drop(columns=["scenario", "zone"], errors="ignore")
            results[zone][sc] = sub.reset_index(drop=True)
    return results


def _run_figures_only(args: argparse.Namespace, log: logging.Logger) -> None:
    """Regenerate Section 4.4 figures from scenario Parquet/CSV (no LP, no proxy refit)."""
    scenario_tables: dict[str, pd.DataFrame] = {}
    for zone in ("SE3", "SE4"):
        pq = config.DATA_DIR / f"scenario_prices_{zone}.parquet"
        if not pq.is_file():
            log.error("Missing %s — run full scenario pipeline once.", pq)
            sys.exit(1)
        scenario_tables[zone] = pd.read_parquet(pq)

    results = _load_scenario_results_from_disk()
    summary: dict[str, dict[str, dict[str, float]]] = {"SE3": {}, "SE4": {}}
    for zone in ("SE3", "SE4"):
        for sc in config.SCENARIOS:
            summary[zone][sc] = ra.summarize_scenario_daily(results[zone].get(sc, pd.DataFrame()))

    ex = pd.Timestamp(args.example_day)
    vis.plot_scenario_price_profiles(
        scenario_tables["SE3"],
        ex,
        "SE3",
        config.FIG_DIR / "fig4_20_scenario_price_profiles",
    )
    vis.plot_annual_revenue_comparison(
        results,
        config.FIG_DIR / "fig4_21_annual_revenue_comparison",
    )
    vis.plot_revenue_composition(
        results,
        config.FIG_DIR / "fig4_22_revenue_composition",
    )
    vis.plot_cumulative_revenue_paths(
        results,
        config.FIG_DIR / "fig4_23_cumulative_revenue_paths",
    )

    if not args.skip_tornado:
        all_csv = config.DATA_DIR / "scenario_revenues_all.csv"
        if not all_csv.is_file():
            log.warning("Missing %s — skip Fig.~4.24 (tornado).", all_csv)
        else:
            log.info("Tornado (SE3) — Fig.~4.24")
            import oat_tornado

            oat_tornado.main()

    lines = [
        "# Section 4.4 — Scenario analysis (draft)",
        "",
        "**Purpose:** Sensitivity of estimated **spot + proxy balancing** revenue to stylised price shocks (Section~3.5.3-style), not forecasts.",
        "",
        "**Methods:** $\\mu$ = month$\\times$hour mean of baseline DA prices; $\\varepsilon = p-\\mu$. Scenarios scale $\\varepsilon$ and/or add intraday shifts (high renewable). Floor at $-150$ EUR/MWh with logged clipping.",
        "",
        "**Balancing:** Lasso proxy re-fitted on the **full** historical daily panel (Chapter~4.3 specification), applied to indicators computed from **scenario** prices; **P95 spike threshold** fixed to the **historical baseline** pooled P95 for comparability.",
        "",
        "## Total revenue (6-yr sum, M EUR)",
        "",
    ]
    for zone in ("SE3", "SE4"):
        lines.append(f"### {zone}")
        lines.append("")
        lines.append("| Scenario | Total (M EUR) | Spot share | Bal. proxy share |")
        lines.append("|---|---|---|---|")
        for sc in config.SCENARIOS:
            m = summary[zone][sc]
            if not m:
                continue
            tot = m["total_period"] / 1e6
            lines.append(
                f"| {sc} | {tot:.2f} | {100*m['spot_share']:.1f}% | {100*m['bal_share']:.1f}% |"
            )
        lines.append("")

    lines.extend(
        [
            "## Files",
            "",
            "- `data/scenario_prices_SE3.parquet`, `scenario_prices_SE4.parquet`",
            "- `data/scenario_revenues_SE3.csv`, `scenario_revenues_SE4.csv`, `scenario_revenues_all.csv`",
            "- `tables/table4_7_scenario_summary.tex`",
            "- Figures `figures/fig4_20` … `fig4_24`",
            "",
        ]
    )
    (config.ROOT / "RESULTS_SECTION_4_4.md").write_text("\n".join(lines), encoding="utf-8")
    log.info("Figures-only done. See RESULTS_SECTION_4_4.md (LaTeX table not refreshed).")


def main() -> None:
    parser = argparse.ArgumentParser(description="Chapter 4.4 scenario analysis")
    parser.add_argument(
        "--example-day",
        default="2022-07-15",
        help="Date for Figure 4.20 (YYYY-MM-DD); must be a valid 24h Stockholm day",
    )
    parser.add_argument(
        "--skip-tornado",
        action="store_true",
        help="Skip Fig.~4.24 (saves ~10--15~min of spot re-optimisation on SE3)",
    )
    parser.add_argument(
        "--figures-only",
        action="store_true",
        help="Regenerate figures from data/scenario_prices_*.parquet and scenario_revenues_*.csv "
        "(no scenario LPs, no proxy refit). Fig.~4.24 still re-runs spot LPs unless --skip-tornado.",
    )
    args = parser.parse_args()
    _setup_log()
    log = logging.getLogger("main_scenario")

    if args.figures_only:
        _run_figures_only(args, log)
        return

    p95 = baseline_pooled_p95()
    log.info("Baseline pooled P95 (spike threshold) = %.2f EUR/MWh", p95)

    scenario_tables: dict[str, pd.DataFrame] = {}
    results: dict[str, dict[str, pd.DataFrame]] = {"SE3": {}, "SE4": {}}
    proxies = {
        "SE3": fit_proxy_lasso_full_sample("SE3"),
        "SE4": fit_proxy_lasso_full_sample("SE4"),
    }

    for zone in ("SE3", "SE4"):
        log.info("=== Zone %s: scenario prices ===", zone)
        base_ser = load_zone_hourly_series(zone)
        mu, eps = decompose_price_series(base_ser)
        wide = generate_all_scenarios(mu, eps)
        scenario_tables[zone] = wide
        save_scenario_parquet(wide, zone)

        for sc in config.SCENARIOS:
            log.info("  scenario %s / %s", zone, sc)
            prices = wide[sc]
            results[zone][sc] = estimate_total_revenues(
                prices, zone, proxies[zone], p95
            )
            n = len(results[zone][sc])
            log.info("    merged days: %s", n)

    # Long-format CSV per zone
    for zone in ("SE3", "SE4"):
        rows = []
        for sc, df in results[zone].items():
            if df.empty:
                continue
            d = df.copy()
            d["scenario"] = sc
            d["zone"] = zone
            rows.append(d)
        if rows:
            pd.concat(rows, ignore_index=True).to_csv(
                config.DATA_DIR / f"scenario_revenues_{zone}.csv", index=False
            )

    # Summary for Table 4.7
    summary: dict[str, dict[str, dict[str, float]]] = {"SE3": {}, "SE4": {}}
    for zone in ("SE3", "SE4"):
        for sc in config.SCENARIOS:
            summary[zone][sc] = ra.summarize_scenario_daily(results[zone][sc])

    ra.build_table4_7_tex(summary, config.TABLES_DIR / "table4_7_scenario_summary.tex")

    ra.flatten_results_to_csv_rows(results).to_csv(
        config.DATA_DIR / "scenario_revenues_all.csv", index=False
    )
    ra.annual_stats_by_scenario(results).to_csv(
        config.DATA_DIR / "scenario_annual_stats.csv", index=False
    )

    # Figures
    ex = pd.Timestamp(args.example_day)
    vis.plot_scenario_price_profiles(
        scenario_tables["SE3"],
        ex,
        "SE3",
        config.FIG_DIR / "fig4_20_scenario_price_profiles",
    )
    vis.plot_annual_revenue_comparison(
        results,
        config.FIG_DIR / "fig4_21_annual_revenue_comparison",
    )
    vis.plot_revenue_composition(
        results,
        config.FIG_DIR / "fig4_22_revenue_composition",
    )
    vis.plot_cumulative_revenue_paths(
        results,
        config.FIG_DIR / "fig4_23_cumulative_revenue_paths",
    )

    if not args.skip_tornado:
        log.info("Tornado (SE3) — Fig.~4.24")
        import oat_tornado

        oat_tornado.main()

    # Markdown summary
    lines = [
        "# Section 4.4 — Scenario analysis (draft)",
        "",
        "**Purpose:** Sensitivity of estimated **spot + proxy balancing** revenue to stylised price shocks (Section~3.5.3-style), not forecasts.",
        "",
        "**Methods:** $\\mu$ = month$\\times$hour mean of baseline DA prices; $\\varepsilon = p-\\mu$. Scenarios scale $\\varepsilon$ and/or add intraday shifts (high renewable). Floor at $-150$ EUR/MWh with logged clipping.",
        "",
        "**Balancing:** Lasso proxy re-fitted on the **full** historical daily panel (Chapter~4.3 specification), applied to indicators computed from **scenario** prices; **P95 spike threshold** fixed to the **historical baseline** pooled P95 for comparability.",
        "",
        "## Total revenue (6-yr sum, M EUR)",
        "",
    ]
    for zone in ("SE3", "SE4"):
        lines.append(f"### {zone}")
        lines.append("")
        lines.append("| Scenario | Total (M EUR) | Spot share | Bal. proxy share |")
        lines.append("|---|---|---|---|")
        for sc in config.SCENARIOS:
            m = summary[zone][sc]
            if not m:
                continue
            tot = m["total_period"] / 1e6
            lines.append(
                f"| {sc} | {tot:.2f} | {100*m['spot_share']:.1f}% | {100*m['bal_share']:.1f}% |"
            )
        lines.append("")

    lines.extend(
        [
            "## Files",
            "",
            "- `data/scenario_prices_SE3.parquet`, `scenario_prices_SE4.parquet`",
            "- `data/scenario_revenues_SE3.csv`, `scenario_revenues_SE4.csv`, `scenario_revenues_all.csv`",
            "- `tables/table4_7_scenario_summary.tex`",
            "- Figures `figures/fig4_20` … `fig4_24`",
            "",
        ]
    )
    (config.ROOT / "RESULTS_SECTION_4_4.md").write_text("\n".join(lines), encoding="utf-8")
    log.info("Done. See RESULTS_SECTION_4_4.md and tables/table4_7_scenario_summary.tex")


if __name__ == "__main__":
    main()
