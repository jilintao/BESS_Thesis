# Section 4.4 — Scenario analysis (draft)

**Purpose:** Sensitivity of estimated **spot + proxy balancing** revenue to stylised price shocks (Section~3.5.3-style), not forecasts.

**Methods:** $\mu$ = month$\times$hour mean of baseline DA prices; $\varepsilon = p-\mu$. Scenarios scale $\varepsilon$ and/or add intraday shifts (high renewable). Floor at $-150$ EUR/MWh with logged clipping.

**Balancing:** Lasso proxy re-fitted on the **full** historical daily panel (Chapter~4.3 specification), applied to indicators computed from **scenario** prices; **P95 spike threshold** fixed to the **historical baseline** pooled P95 for comparability.

## Total revenue (6-yr sum, M EUR)

### SE3

| Scenario | Total (M EUR) | Spot share | Bal. proxy share |
|---|---|---|---|
| baseline | 195.55 | 3.3% | 96.7% |
| high_vol | 219.53 | 4.9% | 95.1% |
| low_vol | 180.59 | 2.2% | 97.8% |
| high_renewable | 231.69 | 5.5% | 94.5% |

### SE4

| Scenario | Total (M EUR) | Spot share | Bal. proxy share |
|---|---|---|---|
| baseline | 247.70 | 3.4% | 96.6% |
| high_vol | 287.65 | 4.7% | 95.3% |
| low_vol | 229.70 | 2.3% | 97.7% |
| high_renewable | 305.06 | 5.2% | 94.8% |

## Files

- `data/scenario_prices_SE3.parquet`, `scenario_prices_SE4.parquet`
- `data/scenario_revenues_SE3.csv`, `scenario_revenues_SE4.csv`, `scenario_revenues_all.csv`
- `tables/table4_7_scenario_summary.tex`
- Figures `figures/fig4_20` … `fig4_24`
