"""Summary statistics, Table 4.7 LaTeX, scenario revenue CSV export."""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

import config

log = logging.getLogger(__name__)


def daily_to_annual_totals(daily: pd.DataFrame) -> pd.Series:
    """Sum total_eur by calendar year (date column)."""
    d = daily.copy()
    d["year"] = pd.to_datetime(d["date"]).dt.year
    return d.groupby("year")["total_eur"].sum()


def summarize_scenario_daily(daily: pd.DataFrame) -> dict[str, float]:
    if daily.empty:
        return {}
    t = daily["total_eur"]
    return {
        "mean_daily": float(t.mean()),
        "std_daily": float(t.std(ddof=0)),
        "median_daily": float(t.median()),
        "min_daily": float(t.min()),
        "max_daily": float(t.max()),
        "total_period": float(t.sum()),
        "spot_share": float(daily["spot_eur"].sum() / t.sum()) if t.sum() else 0.0,
        "bal_share": float(daily["balancing_est_eur"].sum() / t.sum()) if t.sum() else 0.0,
    }


def pct_change(v: float, base: float) -> str:
    if base == 0:
        return "---"
    p = 100.0 * (v - base) / base
    sign = "+" if p >= 0 else ""
    return f"{sign}{p:.1f}\\%"


def fmt_eur_mil(x: float) -> str:
    return f"{x / 1e6:.2f}\\,M"


def fmt_eur_int(x: float) -> str:
    return f"{x:,.0f}".replace(",", "{,}")


def build_table4_7_tex(
    summary: dict[str, dict[str, dict[str, float]]],
    path: Path,
) -> None:
    """
    summary[zone][scenario] = metrics dict with mean_daily, total_period, ...
    scenarios must include 'baseline'.
    """
    lines = [
        r"% Requires: \usepackage{multirow}",
        r"\caption{Scenario analysis: estimated total revenue (spot arbitrage + proxy balancing) under alternative market structures (2025 EUR). \textit{Note:} spot block inherits perfect intra-day foresight; balancing uses the Section~4.3 Lasso proxy applied to scenario indicators (structural stability assumed).}",
        r"\begin{tabular}{lcccc}",
        r"\toprule",
        r"\multirow{2}{*}{Scenario} & \multicolumn{2}{c}{SE3} & \multicolumn{2}{c}{SE4} \\",
        r"\cmidrule(lr){2-3} \cmidrule(lr){4-5}",
        r" & Mean daily (EUR) & Total 6-yr (EUR) & Mean daily (EUR) & Total 6-yr (EUR) \\",
        r"\midrule",
    ]
    zones = ("SE3", "SE4")
    base_tot = {z: summary[z]["baseline"]["total_period"] for z in zones}
    base_mean = {z: summary[z]["baseline"]["mean_daily"] for z in zones}

    scen_labels = {
        "baseline": "Baseline",
        "high_vol": "High volatility",
        "low_vol": "Low volatility",
        "high_renewable": "High renewable",
    }

    for sc in config.SCENARIOS:
        lab = scen_labels.get(sc, sc)
        cells = []
        for z in zones:
            m = summary[z][sc]
            tot = m["total_period"]
            mean = m["mean_daily"]
            if sc == "baseline":
                cells.append(fmt_eur_int(mean))
                cells.append(fmt_eur_mil(tot))
            else:
                cells.append(
                    f"{fmt_eur_int(mean)} ({pct_change(mean, base_mean[z])})"
                )
                cells.append(
                    f"{fmt_eur_mil(tot)} ({pct_change(tot, base_tot[z])})"
                )
        lines.append(f"{lab} & {' & '.join(cells)} \\\\")

    lines.extend([r"\bottomrule", r"\end{tabular}"])
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")
    log.info("Wrote %s", path)


def flatten_results_to_csv_rows(
    results: dict[str, dict[str, pd.DataFrame]],
) -> pd.DataFrame:
    rows = []
    for zone, scen_dict in results.items():
        for scen, df in scen_dict.items():
            if df.empty:
                continue
            for _, r in df.iterrows():
                rows.append(
                    {
                        "zone": zone,
                        "scenario": scen,
                        "date": r["date"],
                        "spot_eur": r["spot_eur"],
                        "balancing_est_eur": r["balancing_est_eur"],
                        "total_eur": r["total_eur"],
                    }
                )
    return pd.DataFrame(rows)


def annual_stats_by_scenario(
    results: dict[str, dict[str, pd.DataFrame]],
) -> pd.DataFrame:
    """Per zone, scenario: yearly totals + std across years."""
    rows = []
    for zone, scen_dict in results.items():
        for scen, df in scen_dict.items():
            if df.empty:
                continue
            y = daily_to_annual_totals(df)
            rows.append(
                {
                    "zone": zone,
                    "scenario": scen,
                    "annual_mean": float(y.mean()),
                    "annual_std": float(y.std(ddof=0)),
                    "years": len(y),
                }
            )
    return pd.DataFrame(rows)
