# Appendix A — List of Included Libraries and GitHub Codebase

The replication code for the empirical chapters (day-ahead spot arbitrage, aFRR balancing, regression / tree models, and scenario analysis) is published as a public repository. **Replace the URL below with your actual GitHub link after the repository is created.**

**Code repository:** `https://github.com/jilintao/BESS_Thesis/tree/main`

---

## Python libraries

The following packages are used by the pipelines in `chapter4_spot_arbitrage`, `chapter4_balancing`, `chapter4_regression`, and `chapter4_scenario_analysis`. Versions below are **pinned for reproducibility** (aligned with current PyPI and Python 3.10+). The repository root `requirements.txt` lists **minimum** versions (`>=`); for examination rules that require an exact environment, run `pip install -r requirements.txt` (optionally after replacing `>=` with the pins below) and archive `pip freeze` as `requirements-lock.txt`.

```
entsoe-py==0.7.11
numpy==2.1.3
pandas==2.2.3
scipy==1.14.1
scikit-learn==1.5.2
statsmodels==0.14.4
pulp==3.3.0
matplotlib==3.8.3
seaborn==0.13.2
requests==2.32.3
pyarrow==17.0.0
```

**Notes**

- **`entsoe-py`** — programmatic access to ENTSO-E Transparency data (day-ahead prices; activated balancing energy prices, document A84; contracted reserve prices for capacity). The balancing pipeline uses **`entsoe_fetch_utils.py`**: bounded HTTP **timeouts** on `EntsoePandasClient`, **short retries**, and automatic **bisection** of the requested time window when the API returns gateway errors (e.g. 504), read timeouts, or pagination limits—so a failing large window is split into shorter sub-windows instead of blocking indefinitely. If the service is persistently unavailable, use **`--skip-fetch`** in `main_bal.py` to rebuild figures from cached Parquet files only.
- **`pulp`** — mixed-integer linear programs for daily battery dispatch (spot and balancing chapters). The implementation calls the bundled **CBC** solver via `pulp.PULP_CBC_CMD`.
- **`statsmodels`** — variance inflation factors (VIF) and related diagnostics in the regression chapter.
- **`pyarrow`** — reading and writing **Parquet** caches (`processed_prices.parquet`, `balancing_hourly_*.parquet`, etc.).

---

## Numerical solver

Linear optimisation is implemented in **PuLP**. By default, the code uses the **COIN-OR CBC** solver shipped with PuLP (`PULP_CBC_CMD`). No separate solver installation is required on most systems if CBC is available through the PuLP bundle.

If CBC is unavailable or you prefer another backend, consult the [PuLP documentation](https://coin-or.github.io/pulp/) for configuring alternatives (e.g. **GLPK**, **COIN**, or commercial solvers). Ensure the chosen solver is installed for your operating system and that PuLP is pointed to the correct executable.

---

## Not used in this codebase

The following appear in some other theses’ appendices but are **not** dependencies of this replication package:

- `tslearn`, `Pyomo`, `oemof.solph` / `oemof.network` / `oemof.tools` — not imported in this repository.

---

*You may paste this appendix into the thesis Word/LaTeX file and adjust the repository URL, version pins, or solver paragraph to match your examination office’s requirements.*
