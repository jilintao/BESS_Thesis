param([switch]$SkipScenarioTornado)
$ErrorActionPreference = "Stop"
$Root = $PSScriptRoot

Set-Location (Join-Path $Root "chapter4_spot_arbitrage"); python main.py --figures-only
Set-Location (Join-Path $Root "chapter4_balancing"); python main_bal.py --figures-only
Set-Location (Join-Path $Root "chapter4_regression")
$b3 = Join-Path (Get-Location) "results\_figure_bundle_SE3.joblib"
$b4 = Join-Path (Get-Location) "results\_figure_bundle_SE4.joblib"
if (-not (Test-Path $b3) -or -not (Test-Path $b4)) {
    Write-Warning "Missing joblib bundles; run main_rebuilt.py once with full data."
} else { python main_rebuilt.py --figures-only }

Set-Location (Join-Path $Root "chapter4_scenario_analysis")
if ($SkipScenarioTornado) { python main_scenario.py --figures-only --skip-tornado }
else { python main_scenario.py --figures-only }

Set-Location $Root
Write-Host "Figures-only done." -ForegroundColor Green
